package com.jarvis.android.data

import com.jarvis.android.domain.ConnectionState
import com.jarvis.android.domain.JarvisError
import kotlinx.coroutines.test.runTest
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.SocketPolicy
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Exercises JarvisHttpClient against a real local HTTP server (not
 * just mocked interfaces), matching the project's existing preference
 * for testing providers against genuine servers rather than
 * unreachable-address-only tests (see JARVIS Core's
 * tests/test_providers.py for the same pattern on the Python side).
 */
class JarvisHttpClientTest {

    private lateinit var server: MockWebServer
    private lateinit var client: JarvisHttpClient

    @Before
    fun setUp() {
        server = MockWebServer()
        server.start()
        client = JarvisHttpClient(
            baseUrl = server.url("/").toString().trimEnd('/'),
            connectTimeoutSeconds = 1,
            readTimeoutSeconds = 1,
        )
    }

    @After
    fun tearDown() {
        server.shutdown()
    }

    @Test
    fun `successful response parses reply and conversation id`() = runTest {
        server.enqueue(
            MockResponse().setBody(
                """{"response":"Hello there.","conversation_id":"abc","metadata":{}}"""
            ).setHeader("Content-Type", "application/json"),
        )

        val result = client.sendMessage("abc", "hi")

        assertTrue(result.isSuccess)
        assertEquals("Hello there.", result.getOrNull())
    }

    @Test
    fun `request body sends message and conversation id`() = runTest {
        server.enqueue(
            MockResponse().setBody(
                """{"response":"ok","conversation_id":"conv-1","metadata":{}}"""
            ),
        )

        client.sendMessage("conv-1", "hello jarvis")

        val recorded = server.takeRequest()
        assertEquals("/message", recorded.path)
        assertTrue(recorded.body.readUtf8().contains("\"conversation_id\":\"conv-1\""))
    }

    @Test
    fun `server error surfaces detail message`() = runTest {
        server.enqueue(
            MockResponse().setResponseCode(400).setBody("""{"error":"Field 'message' is required."}"""),
        )

        val result = client.sendMessage("abc", "hi")

        assertTrue(result.isFailure)
        val error = result.jarvisErrorOrNull()
        assertTrue(error is JarvisError.ServerError)
        assertEquals("Field 'message' is required.", (error as JarvisError.ServerError).detail)
    }

    @Test
    fun `malformed json response is reported as malformed`() = runTest {
        server.enqueue(MockResponse().setBody("not json at all"))

        val result = client.sendMessage("abc", "hi")

        assertTrue(result.isFailure)
        assertTrue(result.jarvisErrorOrNull() is JarvisError.MalformedResponse)
    }

    @Test
    fun `empty body is reported as empty response`() = runTest {
        server.enqueue(MockResponse().setBody(""))

        val result = client.sendMessage("abc", "hi")

        assertTrue(result.isFailure)
        assertTrue(result.jarvisErrorOrNull() is JarvisError.EmptyResponse)
    }

    @Test
    fun `blank response field is reported as empty response`() = runTest {
        server.enqueue(
            MockResponse().setBody("""{"response":"   ","conversation_id":"abc","metadata":{}}"""),
        )

        val result = client.sendMessage("abc", "hi")

        assertTrue(result.isFailure)
        assertTrue(result.jarvisErrorOrNull() is JarvisError.EmptyResponse)
    }

    @Test
    fun `connection failure after server shutdown reports core unavailable`() = runTest {
        server.shutdown()

        val result = client.sendMessage("abc", "hi")

        assertTrue(result.isFailure)
        val error = result.jarvisErrorOrNull()
        assertTrue(error is JarvisError.NetworkFailure || error is JarvisError.CoreUnavailable)
    }

    @Test
    fun `timeout is reported distinctly from other network failures`() = runTest {
        server.enqueue(
            MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE),
        )

        val result = client.sendMessage("abc", "hi")

        assertTrue(result.isFailure)
        assertTrue(result.jarvisErrorOrNull() is JarvisError.Timeout)
    }

    @Test
    fun `checkHealth updates connectionState to connected on success`() = runTest {
        server.enqueue(
            MockResponse().setBody("""{"status":"ok","jarvis_name":"JARVIS","active_conversations":0}"""),
        )

        val result = client.checkHealth()

        assertTrue(result.isSuccess)
        assertEquals(ConnectionState.Connected, client.connectionState.value)
    }

    @Test
    fun `checkHealth updates connectionState to disconnected when unreachable`() = runTest {
        server.shutdown()

        client.checkHealth()

        assertTrue(client.connectionState.value is ConnectionState.Disconnected)
    }
}
