package com.jarvis.android.ui.chat

import com.jarvis.android.data.JarvisClient
import com.jarvis.android.data.JarvisClientException
import com.jarvis.android.domain.ConnectionState
import com.jarvis.android.domain.JarvisError
import com.jarvis.android.domain.Sender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

private class FakeJarvisClient : JarvisClient {
    override val connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Connected)
    var nextResult: Result<String> = Result.success("ok")
    var lastConversationId: String? = null
    var lastMessage: String? = null

    override suspend fun sendMessage(conversationId: String, message: String): Result<String> {
        lastConversationId = conversationId
        lastMessage = message
        return nextResult
    }

    override suspend fun checkHealth(): Result<Unit> = Result.success(Unit)
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModelTest {

    private val dispatcher = StandardTestDispatcher()
    private lateinit var fakeClient: FakeJarvisClient
    private lateinit var viewModel: ChatViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(dispatcher)
        fakeClient = FakeJarvisClient()
        viewModel = ChatViewModel(fakeClient)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `sending a message adds user message immediately then jarvis reply`() = runTest {
        fakeClient.nextResult = Result.success("Hi there.")
        viewModel.onInputChanged("hello")

        viewModel.sendMessage()
        dispatcher.scheduler.advanceUntilIdle()

        val messages = viewModel.uiState.value.messages
        assertEquals(2, messages.size)
        assertEquals(Sender.USER, messages[0].sender)
        assertEquals("hello", messages[0].text)
        assertEquals(Sender.JARVIS, messages[1].sender)
        assertEquals("Hi there.", messages[1].text)
    }

    @Test
    fun `input is cleared after sending`() = runTest {
        viewModel.onInputChanged("hello")
        viewModel.sendMessage()
        assertEquals("", viewModel.uiState.value.inputText)
    }

    @Test
    fun `blank input does not send`() = runTest {
        viewModel.onInputChanged("   ")
        viewModel.sendMessage()
        dispatcher.scheduler.advanceUntilIdle()
        assertTrue(viewModel.uiState.value.messages.isEmpty())
    }

    @Test
    fun `failed send surfaces error message as a jarvis message`() = runTest {
        fakeClient.nextResult = Result.failure(JarvisClientException(JarvisError.CoreUnavailable))
        viewModel.onInputChanged("hello")

        viewModel.sendMessage()
        dispatcher.scheduler.advanceUntilIdle()

        val reply = viewModel.uiState.value.messages.last()
        assertEquals(Sender.JARVIS, reply.sender)
        assertTrue(reply.isError)
        assertEquals(JarvisError.CoreUnavailable.userMessage, reply.text)
    }

    @Test
    fun `same conversation id is reused across multiple messages`() = runTest {
        viewModel.onInputChanged("first")
        viewModel.sendMessage()
        dispatcher.scheduler.advanceUntilIdle()
        val firstConvId = fakeClient.lastConversationId

        viewModel.onInputChanged("second")
        viewModel.sendMessage()
        dispatcher.scheduler.advanceUntilIdle()

        assertEquals(firstConvId, fakeClient.lastConversationId)
    }

    @Test
    fun `is waiting for reply true while send is in flight`() = runTest {
        viewModel.onInputChanged("hello")
        viewModel.sendMessage()
        assertTrue(viewModel.uiState.value.isWaitingForReply)
        dispatcher.scheduler.advanceUntilIdle()
        assertTrue(!viewModel.uiState.value.isWaitingForReply)
    }
}
