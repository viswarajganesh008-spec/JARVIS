package com.jarvis.android

import android.app.Application

/**
 * No global initialization needed yet - ServiceLocator is lazy. This
 * class exists as the documented extension point for future
 * app-wide setup (e.g. crash reporting, voice-service registration)
 * rather than being added ad hoc to MainActivity later.
 */
class JarvisApplication : Application()
