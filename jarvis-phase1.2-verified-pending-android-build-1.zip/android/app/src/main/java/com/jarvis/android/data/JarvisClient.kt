package com.jarvis.android.data

import com.jarvis.android.domain.ConnectionState
import com.jarvis.android.domain.JarvisError
import kotlinx.coroutines.flow.StateFlow

/**
 * The Android app's single point of contact with JARVIS Core.
 *
 *     ChatViewModel -> JarvisClient -> (HTTP) -> api/server.py -> JarvisCore
 *
 * This is intentionally a small, transport-agnostic interface - today
 * JarvisHttpClient implements it over the REST dev bridge, but nothing
 * above this interface (ViewModel, UI) needs to know that. A future
 * transport (e.g. a bundled local process, gRPC, or a different
 * framing) could implement the same interface without any UI changes.
 *
 * No method here takes a tool name, a file path, or a command - only
 * free-text messages, matching JarvisCore.process(text) exactly. This
 * is what keeps the Android app from becoming a second place that
 * could bypass JARVIS's safety/orchestration layer.
 */
interface JarvisClient {

    /** Current best-known reachability of JARVIS Core. */
    val connectionState: StateFlow<ConnectionState>

    /**
     * Send one user message as part of [conversationId] and get
     * JARVIS's reply. Never throws - all failure modes are represented
     * in the returned Result's failure case as a [JarvisError].
     */
    suspend fun sendMessage(conversationId: String, message: String): Result<String>

    /** Explicit reachability probe, e.g. on app start or pull-to-refresh. */
    suspend fun checkHealth(): Result<Unit>
}

/** Convenience so call sites can pattern-match without an extra cast. */
fun Result<String>.jarvisErrorOrNull(): JarvisError? =
    exceptionOrNull()?.let { (it as? JarvisClientException)?.error }

/** Wraps a [JarvisError] so it can travel through a Kotlin [Result]. */
class JarvisClientException(val error: JarvisError) : Exception(error.userMessage)
