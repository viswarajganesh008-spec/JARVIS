package com.jarvis.android.domain

/**
 * Every way a call to JARVIS Core can fail, as required by the
 * "error handling" objective: Core unavailable, network failure,
 * timeout, malformed response, server error, empty response. Kept as
 * a closed sealed class (rather than throwing raw exceptions up to
 * the UI) so ChatScreen can render a specific, useful message for
 * each case instead of a generic "something went wrong".
 */
sealed class JarvisError(val userMessage: String) {
    data object CoreUnavailable : JarvisError(
        "Can't reach JARVIS Core. Is it running?"
    )

    data object NetworkFailure : JarvisError(
        "Network error. Check your connection and try again."
    )

    data object Timeout : JarvisError(
        "JARVIS Core took too long to respond."
    )

    data class ServerError(val statusCode: Int, val detail: String?) : JarvisError(
        detail ?: "JARVIS Core reported an error (HTTP $statusCode)."
    )

    data object MalformedResponse : JarvisError(
        "Got an unexpected response from JARVIS Core."
    )

    data object EmptyResponse : JarvisError(
        "JARVIS Core returned an empty response."
    )

    data class Unknown(val cause: String?) : JarvisError(
        cause ?: "Something went wrong talking to JARVIS Core."
    )
}
