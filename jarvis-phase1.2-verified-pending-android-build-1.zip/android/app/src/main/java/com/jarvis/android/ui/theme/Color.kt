package com.jarvis.android.ui.theme

import androidx.compose.ui.graphics.Color

val JarvisBackground = Color(0xFF0B0F14)
val JarvisSurface = Color(0xFF121821)
val JarvisAccent = Color(0xFF4FD1E5)
val JarvisAccentDim = Color(0xFF2E6E78)
val JarvisTextPrimary = Color(0xFFE6F1F5)
val JarvisTextSecondary = Color(0xFF8FA3AD)
val JarvisError = Color(0xFFE5735C)
val JarvisUserBubble = Color(0xFF1B2530)
