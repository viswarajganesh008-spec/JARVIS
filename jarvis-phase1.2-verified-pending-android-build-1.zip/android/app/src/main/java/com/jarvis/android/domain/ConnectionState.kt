package com.jarvis.android.domain

/**
 * Whether the app currently believes it can reach JARVIS Core.
 * Driven by JarvisClient.checkHealth() and by the outcome of each
 * sendMessage() call - see ChatViewModel.
 */
sealed interface ConnectionState {
    data object Unknown : ConnectionState
    data object Connecting : ConnectionState
    data object Connected : ConnectionState
    data class Disconnected(val reason: String) : ConnectionState
}
