package com.jarvis.android.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.android.data.JarvisClient
import com.jarvis.android.data.jarvisErrorOrNull
import com.jarvis.android.domain.ChatMessage
import com.jarvis.android.domain.ConnectionState
import com.jarvis.android.domain.Sender
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val isWaitingForReply: Boolean = false,
)

/**
 * Owns one conversation with JARVIS Core. The conversation_id is
 * generated once per ViewModel instance (i.e. per app session) and
 * reused for every message, so follow-up questions ("explain it
 * simpler") reach the same JarvisCore context server-side - see
 * api/sessions.py.
 */
class ChatViewModel(private val client: JarvisClient) : ViewModel() {

    private val conversationId: String = UUID.randomUUID().toString()

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    val connectionState: StateFlow<ConnectionState> = client.connectionState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = ConnectionState.Unknown,
    )

    init {
        viewModelScope.launch { client.checkHealth() }
    }

    fun onInputChanged(text: String) {
        _uiState.value = _uiState.value.copy(inputText = text)
    }

    fun sendMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isEmpty() || _uiState.value.isWaitingForReply) return

        val userMessage = ChatMessage(sender = Sender.USER, text = text)
        _uiState.value = _uiState.value.copy(
            messages = _uiState.value.messages + userMessage,
            inputText = "",
            isWaitingForReply = true,
        )

        viewModelScope.launch {
            val result = client.sendMessage(conversationId, text)
            val reply = result.fold(
                onSuccess = { responseText ->
                    ChatMessage(sender = Sender.JARVIS, text = responseText)
                },
                onFailure = { throwable ->
                    val error = result.jarvisErrorOrNull()
                    ChatMessage(
                        sender = Sender.JARVIS,
                        text = error?.userMessage ?: (throwable.message ?: "Unknown error."),
                        isError = true,
                    )
                },
            )
            _uiState.value = _uiState.value.copy(
                messages = _uiState.value.messages + reply,
                isWaitingForReply = false,
            )
        }
    }

    fun retryConnection() {
        viewModelScope.launch { client.checkHealth() }
    }
}
