package com.jarvis.android.data

import com.jarvis.android.domain.ConnectionState
import com.jarvis.android.domain.JarvisError
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response

private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

/**
 * Talks to the JARVIS Core dev bridge (`api/server.py`) over plain
 * HTTP. See JarvisClient's kdoc for why nothing above this class knows
 * that.
 *
 * [baseUrl] should NOT include a trailing slash, e.g.
 * "http://10.0.2.2:8765" for the emulator talking to a host machine
 * running `python run_api.py`, or "http://192.168.x.x:8765" for a
 * physical device on the same LAN (start the bridge with
 * JARVIS_API_HOST=0.0.0.0 in that case - see run_api.py).
 */
class JarvisHttpClient(
    private val baseUrl: String,
    connectTimeoutSeconds: Long = 5,
    readTimeoutSeconds: Long = 30,
) : JarvisClient {

    private val json = Json { ignoreUnknownKeys = true }

    private val http = OkHttpClient.Builder()
        .connectTimeout(connectTimeoutSeconds, TimeUnit.SECONDS)
        .readTimeout(readTimeoutSeconds, TimeUnit.SECONDS)
        .build()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Unknown)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    override suspend fun sendMessage(conversationId: String, message: String): Result<String> =
        withContext(Dispatchers.IO) {
            val requestBody = try {
                json.encodeToString(
                    MessageRequest.serializer(),
                    MessageRequest(message = message, conversation_id = conversationId),
                )
            } catch (e: SerializationException) {
                return@withContext failure(JarvisError.Unknown("Could not build request: ${e.message}"))
            }

            val request = Request.Builder()
                .url("$baseUrl/message")
                .post(requestBody.toRequestBody(JSON_MEDIA_TYPE))
                .build()

            executeAndParse(request)
        }

    override suspend fun checkHealth(): Result<Unit> = withContext(Dispatchers.IO) {
        _connectionState.value = ConnectionState.Connecting
        val request = Request.Builder().url("$baseUrl/health").get().build()
        try {
            http.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    _connectionState.value = ConnectionState.Connected
                    Result.success(Unit)
                } else {
                    val error = JarvisError.ServerError(response.code, null)
                    _connectionState.value = ConnectionState.Disconnected(error.userMessage)
                    failure(error)
                }
            }
        } catch (e: java.net.SocketTimeoutException) {
            _connectionState.value = ConnectionState.Disconnected(JarvisError.Timeout.userMessage)
            failure(JarvisError.Timeout)
        } catch (e: IOException) {
            _connectionState.value = ConnectionState.Disconnected(JarvisError.CoreUnavailable.userMessage)
            failure(JarvisError.CoreUnavailable)
        }
    }

    private fun executeAndParse(request: Request): Result<String> {
        val response: Response = try {
            http.newCall(request).execute()
        } catch (e: java.net.SocketTimeoutException) {
            _connectionState.value = ConnectionState.Disconnected(JarvisError.Timeout.userMessage)
            return failure(JarvisError.Timeout)
        } catch (e: IOException) {
            // Covers "connection refused" (Core not running), DNS
            // failure, and every other transport-level network error.
            _connectionState.value = ConnectionState.Disconnected(JarvisError.CoreUnavailable.userMessage)
            return failure(JarvisError.NetworkFailure)
        }

        response.use {
            val bodyString = try {
                it.body?.string()
            } catch (e: IOException) {
                return failure(JarvisError.NetworkFailure)
            }

            if (!it.isSuccessful) {
                val detail = bodyString?.let { raw ->
                    runCatching { json.decodeFromString(ApiErrorBody.serializer(), raw).error }
                        .getOrNull()
                }
                _connectionState.value = ConnectionState.Connected // server reachable, just rejected the request
                return failure(JarvisError.ServerError(it.code, detail))
            }

            if (bodyString.isNullOrBlank()) {
                return failure(JarvisError.EmptyResponse)
            }

            val parsed = try {
                json.decodeFromString(MessageResponse.serializer(), bodyString)
            } catch (e: SerializationException) {
                return failure(JarvisError.MalformedResponse)
            }

            if (parsed.response.isBlank()) {
                return failure(JarvisError.EmptyResponse)
            }

            _connectionState.value = ConnectionState.Connected
            return Result.success(parsed.response)
        }
    }

    private fun <T> failure(error: JarvisError): Result<T> =
        Result.failure(JarvisClientException(error))
}
