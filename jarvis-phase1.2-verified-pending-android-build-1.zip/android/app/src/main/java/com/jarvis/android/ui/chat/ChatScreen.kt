package com.jarvis.android.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.jarvis.android.domain.ChatMessage
import com.jarvis.android.domain.ConnectionState
import com.jarvis.android.domain.Sender
import com.jarvis.android.ui.theme.JarvisAccent
import com.jarvis.android.ui.theme.JarvisError
import com.jarvis.android.ui.theme.JarvisSurface
import com.jarvis.android.ui.theme.JarvisTextSecondary
import com.jarvis.android.ui.theme.JarvisUserBubble

@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.lastIndex)
        }
    }

    Scaffold(
        topBar = { JarvisHeader(connectionState = connectionState, onRetry = viewModel::retryConnection) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
        ) {
            if (uiState.messages.isEmpty()) {
                EmptyConversationHint(modifier = Modifier.weight(1f))
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(uiState.messages, key = { it.id }) { message ->
                        MessageBubble(message)
                    }
                    if (uiState.isWaitingForReply) {
                        item { ThinkingIndicator() }
                    }
                }
            }

            MessageInputBar(
                text = uiState.inputText,
                enabled = !uiState.isWaitingForReply,
                onTextChanged = viewModel::onInputChanged,
                onSend = viewModel::sendMessage,
            )
        }
    }
}

@Composable
private fun JarvisHeader(connectionState: ConnectionState, onRetry: () -> Unit) {
    Surface(color = JarvisSurface) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("JARVIS", style = MaterialTheme.typography.titleLarge)
                ConnectionLabel(connectionState)
            }
            if (connectionState is ConnectionState.Disconnected) {
                TextButton(onClick = onRetry) { Text("Retry") }
            } else {
                ConnectionDot(connectionState)
            }
        }
    }
}

@Composable
private fun ConnectionLabel(state: ConnectionState) {
    val label = when (state) {
        is ConnectionState.Unknown -> "Checking connection\u2026"
        is ConnectionState.Connecting -> "Connecting\u2026"
        is ConnectionState.Connected -> "Connected to JARVIS Core"
        is ConnectionState.Disconnected -> state.reason
    }
    Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = if (state is ConnectionState.Disconnected) JarvisError else JarvisTextSecondary,
    )
}

@Composable
private fun ConnectionDot(state: ConnectionState) {
    val color = when (state) {
        is ConnectionState.Connected -> JarvisAccent
        is ConnectionState.Disconnected -> JarvisError
        else -> JarvisTextSecondary
    }
    Box(
        modifier = Modifier
            .size(10.dp)
            .background(color = color, shape = CircleShape),
    )
}

@Composable
private fun EmptyConversationHint(modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Text(
            "Ask JARVIS anything to begin.",
            color = JarvisTextSecondary,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.sender == Sender.USER
    val bubbleColor = when {
        message.isError -> JarvisError.copy(alpha = 0.15f)
        isUser -> JarvisUserBubble
        else -> JarvisSurface
    }
    val alignment = if (isUser) Alignment.End else Alignment.Start

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Text(
            text = if (isUser) "You" else "JARVIS",
            style = MaterialTheme.typography.labelSmall,
            color = JarvisTextSecondary,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(12.dp),
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                style = MaterialTheme.typography.bodyLarge,
                color = if (message.isError) JarvisError else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

@Composable
private fun ThinkingIndicator() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
            color = JarvisAccent,
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text("JARVIS is thinking\u2026", color = JarvisTextSecondary, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun MessageInputBar(
    text: String,
    enabled: Boolean,
    onTextChanged: (String) -> Unit,
    onSend: () -> Unit,
) {
    Surface(color = JarvisSurface) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChanged,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message JARVIS\u2026") },
                enabled = enabled,
                singleLine = false,
                maxLines = 4,
            )
            IconButton(onClick = onSend, enabled = enabled && text.isNotBlank()) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (enabled && text.isNotBlank()) JarvisAccent else JarvisTextSecondary,
                )
            }
        }
    }
}
