package com.jarvis.android.domain

import java.util.UUID

/**
 * A single turn in the conversation, as the UI understands it.
 *
 * Deliberately separate from the wire format in data/JarvisApiModels.kt
 * - the UI layer must never depend on JARVIS Core's JSON shape
 * directly (see ARCHITECTURE rule: "Do not tightly couple Android UI
 * code to Python implementation details").
 */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val isError: Boolean = false,
)

enum class Sender {
    USER,
    JARVIS,
}
