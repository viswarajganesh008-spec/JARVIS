package com.jarvis.android.data

import kotlinx.serialization.Serializable

/**
 * These mirror the JSON contract defined in JARVIS Core's
 * `api/server.py` exactly:
 *
 *   POST /message
 *   Request:  {"message": "...", "conversation_id": "..."}
 *   Response: {"response": "...", "conversation_id": "...", "metadata": {}}
 *
 * If that contract changes, update it in both places - there is no
 * shared schema between the Kotlin and Python sides yet (see
 * docs/android-core-bridge.md, "Future extension points").
 */
@Serializable
data class MessageRequest(
    val message: String,
    val conversation_id: String? = null,
)

@Serializable
data class MessageResponse(
    val response: String,
    val conversation_id: String,
    val metadata: Map<String, String> = emptyMap(),
)

@Serializable
data class ApiErrorBody(
    val error: String,
)

@Serializable
data class HealthResponse(
    val status: String,
    val jarvis_name: String,
    val active_conversations: Int,
)
