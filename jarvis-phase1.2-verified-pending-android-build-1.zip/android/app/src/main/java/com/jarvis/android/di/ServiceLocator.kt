package com.jarvis.android.di

import com.jarvis.android.BuildConfig
import com.jarvis.android.data.JarvisClient
import com.jarvis.android.data.JarvisHttpClient

/**
 * Deliberately not Hilt/Dagger for this foundation phase - one
 * dependency (JarvisClient) doesn't justify a DI framework yet. If the
 * app grows more injectable dependencies, replace this with Hilt
 * without changing anything above JarvisClient (see its kdoc).
 */
object ServiceLocator {
    val jarvisClient: JarvisClient by lazy {
        JarvisHttpClient(baseUrl = BuildConfig.JARVIS_CORE_BASE_URL)
    }
}
