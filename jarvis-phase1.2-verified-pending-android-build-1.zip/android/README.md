# JARVIS — Android (Foundation)

The primary user interface for JARVIS, talking to the existing Python
JARVIS Core over a local REST bridge. See
`../jarvis/docs/android-core-bridge.md` for the full architecture,
setup, and error-handling contract.

## Quick start

1. Start JARVIS Core's dev bridge (from `../jarvis/`):
   ```bash
   pip install -r requirements.txt
   python run_api.py
   ```
2. Open this `android/` directory as a project in Android Studio.
3. Run on an emulator — no configuration needed, it reaches the host
   machine automatically. For a physical device, see the bridge docs
   linked above.

## Module layout

```
app/src/main/java/com/jarvis/android/
  domain/    ChatMessage, ConnectionState, JarvisError — UI-facing models,
             independent of the HTTP wire format
  data/      JarvisClient (interface) + JarvisHttpClient (OkHttp impl),
             JarvisApiModels (DTOs matching api/server.py's JSON contract)
  ui/chat/   ChatViewModel, ChatScreen (Compose)
  ui/theme/  Color/Type/Theme
  di/        ServiceLocator (manual DI — no framework yet)
```

## Status

This is the Android **foundation**: a real conversation screen backed
by a real HTTP call into JARVIS Core, with proper error handling and
per-conversation context — not a mock, not a hard-coded response. Voice,
vision, and device-control interfaces are structured for but not
implemented; see the architecture doc's "Future extension points".
