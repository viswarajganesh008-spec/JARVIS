# JARVIS Core — Phase 1.1: Intelligence Core + Final Hardening

JARVIS Core is the AI-provider-independent foundation of the JARVIS
personal assistant project. Phase 1 delivered a rule-based command
-line assistant. Phase 1.1 added a real local-model provider
architecture, structured NLU with a confidence-gated AI fallback,
memory intelligence, a RAG-style knowledge/reasoning pipeline,
multi-turn task handling, and ambiguity/clarification handling. **This
final hardening pass adds calculator resource-exhaustion protection,
unifies all tool execution behind the validator that was previously
unused on the actual execution path, adds real local-HTTP-server
provider tests (not just unreachable-address tests), and adds 74 new
tests (142 → 216) targeting abuse, malformed input, and every
documented failure mode** — all while keeping deterministic safety
fully outside the model's control.

## What's new in this hardening pass

- **Calculator hardened against resource exhaustion**
  (`tools/calculator.py`): explicit limits on exponent size, literal
  size, expression length, AST nesting depth, operation count, and
  result bit-length — every one a pre-check that runs *before* the
  expensive operation, not a timeout after the fact. `2 ** 999999999`
  and a 40-digit literal are both rejected in under a millisecond;
  ordinary engineering calculations (`sqrt(25)`, `sin(30)`, a 99-term
  addition chain) are unaffected. See `tests/test_calculator_hardening.py`
  (36 tests) and [ARCHITECTURE.md's Calculator hardening section](ARCHITECTURE.md#calculator-hardening).
- **Tool execution unified behind validation.** `tools/validator.py`
  existed since Phase 1.1 but wasn't actually wired into the execution
  path — `JarvisCore._execute_tool_safely()` is now the only method
  that calls a tool, and it always validates first. A hypothetical
  tool "requested by ai" gets exactly the same risk/confirmation
  treatment as a rule-based request; it cannot self-report as safe.
- **Provider tests against real local HTTP servers**, not just
  unreachable addresses: genuine timeouts (a server that accepts the
  connection and never responds), malformed JSON, non-2xx status, and
  successful generation are all exercised against an actual running
  `http.server` instance in `tests/test_providers.py`.
- **NLU schema flexibility**: the AI-fallback classifier now accepts
  either its own JSON shape or an alternate one using `"intent"` +
  list-shaped `"entities"` — some model prompts/specs use one, some
  the other, and malformed shapes from either still fail closed to the
  rule-based result.
- **Two real punctuation bugs fixed**: "Calculate 25 * 16." was
  silently parsed with the trailing period intact (Python's own float
  grammar accepts `16.` as `16.0`), producing `25 * 16. = 400.0`; and
  "Delete all files." produced a doubled `..` once the confirmation
  template appended its own period. Both fixed with a shared
  `_strip_trailing_terminator()` helper in `core/intent.py`, with
  regression tests.
- **A dedicated `tests/test_failure_modes.py`** (16 tests) explicitly
  covering: provider crashes with an unexpected exception, an empty
  knowledge base, a broken tool, a simulated memory-backend I/O
  failure, and hostile/malformed input (empty string, 10,000+
  characters, control characters, emoji/unicode, SQL-injection-style
  memory content). All 16 passed on the first attempt — meaning the
  existing architecture's error handling was already sound; this
  makes that fact verifiable rather than assumed.

## What's new in Phase 1.1

- **Real local model providers** (`providers/ollama.py`,
  `providers/llamacpp.py`) using stdlib-only HTTP — no mandatory
  third-party dependency, no cloud API. Selected via config/env, with
  clean unavailability handling if the server isn't running.
- **Structured intent understanding** (`core/nlu.py`): rule-based
  classification first; if confidence is low, an AI provider (if one
  is configured and reachable) is consulted for a structured JSON
  classification. Malformed/invalid model output is always caught and
  falls back to the rule-based result.
- **Safety is deterministic and cannot be bypassed by the model.**
  This is enforced in one place (`core/nlu._finalize_safety_fields`):
  risk level is always recomputed from raw text, and any message
  whose *computed* risk is `HIGH`/`CRITICAL` is forced to
  `DANGEROUS_OPERATION` regardless of what intent type the rules or
  the AI fallback assigned it. See [Safety architecture](#safety-architecture).
- **Memory intelligence** (`core/memory_policy.py`): clear first
  -person preference/identity statements ("My favorite language is
  Python") are auto-remembered even without an explicit "remember"
  command; plain questions never are. Secrets (passwords, API keys,
  tokens, credit card numbers) are never stored, even on an explicit
  request.
- **Multi-turn tasks**: "find the area of a circle" → JARVIS asks for
  the radius → the next message supplies it → the tool actually runs.
  State lives in `ContextState.pending_task` and survives across
  messages the same way confirmation state does.
- **Ambiguity handling**: "open it" with no clear referent asks "What
  would you like me to open?" instead of guessing.
- **RAG-ready knowledge pipeline**: retrieval → verification →
  (optional) AI-reasoned answer still grounded in the retrieved
  passage → response, with `knowledge/interfaces.py` defining the
  seam for a future embeddings/vector backend.

## What JARVIS Core is

The rule-based reasoning system from Phase 1 is still there and is
still what runs first for every message — it's fast, free, and fully
auditable. An AI provider is now a real, optional *addition*: consulted
only when the rules are genuinely unsure (intent classification) or
when there's open-ended text to generate (conversation, reasoning over
a retrieved passage). JARVIS with `ai_provider=local` (the default)
behaves exactly like Phase 1: fully functional, just without
open-ended generation.

## Architecture

```
User
  -> CLI (cli.py / python -m jarvis)
  -> JarvisCore (core/orchestrator.py)
      -> Context Engine (core/context.py)          — history, reference resolution, pending tasks
      -> Structured NLU (core/nlu.py)               — rule-based intent + confidence-gated AI fallback
      -> Decision Layer (core/reasoning.py)         — which handler, does it need confirmation?
      -> Memory Intelligence (core/memory_policy.py) — what's worth remembering, secret rejection
      -> Safety Engine (safety/)                    — risk classification + confirmation state machine
      -> Memory (memory/)                           — short-term (session) + long-term (SQLite)
      -> Knowledge Engine (knowledge/)               — ingestion, keyword search, verification, RAG interfaces
      -> Tools (tools/)                              — registry, validator, executor, calculator, geometry
      -> AI Provider (providers/)                    — local / ollama / llamacpp, swappable via config
  -> Response Engine (core/response.py) -> natural-language reply
```

See `ARCHITECTURE.md` for the full turn-by-turn request lifecycle,
provider architecture, and flow diagrams.

## Project structure

```
jarvis/
├── core/             orchestrator, context, intent, nlu, reasoning, response, memory_policy
├── memory/            short-term buffer, long-term SQLite store (+ confidence/expiration)
├── knowledge/         ingestion, search, verification, document model, RAG interfaces
├── tools/             registry, validator, executor, calculator, geometry
├── safety/            risk classifier, confirmation state machine, permissions
├── providers/         AIProvider base, factory, local/ollama/llamacpp implementations
├── config/            JarvisConfig (JSON + env-var overlay)
├── tests/             unittest suite (216 tests)
├── data/              knowledge/ (sample docs), memory.db, index, logs (created at runtime)
├── cli.py, __main__.py  terminal interface (python cli.py or python -m jarvis)
├── .env.example
├── README.md
└── ARCHITECTURE.md
```

## Installation

Requires Python 3.9+. No third-party packages are required to run
JARVIS even with a real model — `providers/ollama.py` and
`providers/llamacpp.py` use only `urllib` from the standard library.

```bash
cd jarvis
python3 -m venv .venv          # optional but recommended
source .venv/bin/activate
```

Optional: to ingest PDF files into the knowledge base, install `pypdf`:

```bash
pip install pypdf
```

Without it, PDF files are skipped during ingestion with a clear
message rather than silently failing — every other format (txt, md,
json, csv) works with no extra dependencies.

## Running JARVIS locally (step by step)

This assumes you're starting from nothing — no model downloaded, no
inference backend installed yet.

**1. Install Python dependencies.** There are none required for core
operation — see [Installation](#installation) above. Only PDF
knowledge-base ingestion needs an optional package (`pip install pypdf`).

**2. Install a supported local inference backend.** Pick one:
   - **Ollama** (simplest): download from https://ollama.com and
     install it for your OS. Confirm it's running with `ollama list`.
   - **llama.cpp**: build or download `llama-server` from
     https://github.com/ggerganov/llama.cpp.

**3. Install/download a compatible model.**
   - Ollama: `ollama pull llama3.2` (or any model from Ollama's
     library — e.g. `qwen2.5:7b`, `mistral`). This downloads several
     GB; make sure you have disk space and time for the first pull.
   - llama.cpp: download a `.gguf` model file (e.g. from Hugging Face)
     to a local path.

**4. Configure environment variables.** Copy `.env.example` to `.env`
and edit it, or export directly:
   ```bash
   export AI_PROVIDER=ollama
   export AI_MODEL=llama3.2
   export AI_BASE_URL=http://localhost:11434
   ```
   (Skip this step entirely to run with `AI_PROVIDER=local` — the
   default — which uses zero AI and is identical to Phase 1 behavior.)

**5. Start JARVIS.**
   ```bash
   cd jarvis
   python3 cli.py
   # or: python3 -m jarvis   (from the directory containing jarvis/)
   ```
   If the provider/model isn't actually reachable, JARVIS detects this
   immediately (`is_available()` check) and falls back to deterministic
   handling with a clear message — it will not hang waiting for a
   model that isn't there.

**6. Run tests.**
   ```bash
   python3 -m unittest discover -s tests -v
   ```
   All 216 should pass — no network access or running model is needed
   for the test suite itself (see [Note on provider test methodology](ARCHITECTURE.md#note-on-provider-test-methodology)
   in ARCHITECTURE.md for how provider tests avoid needing a live model).

## Configuring a local model

By default `AI_PROVIDER=local`, which means no model is connected —
JARVIS runs on rule-based reasoning only (identical to Phase 1). To
connect a real local model:

**Option A — Ollama** (easiest to set up):
```bash
# install & run Ollama (https://ollama.com), then:
ollama pull llama3.2
ollama serve   # usually already running as a service

export AI_PROVIDER=ollama
export AI_MODEL=llama3.2
export AI_BASE_URL=http://localhost:11434
python3 cli.py
```

**Option B — llama.cpp server:**
```bash
llama-server -m /path/to/model.gguf --port 8080

export AI_PROVIDER=llamacpp
export AI_BASE_URL=http://localhost:8080
python3 cli.py
```

See `.env.example` for every configurable value (temperature,
max tokens, context length, request timeout, NLU confidence
threshold, etc.). Copy it to `.env` and export it, or set
`jarvis_config.json` fields directly — environment variables always
win. If the configured provider/model is missing or unreachable,
JARVIS detects this cleanly (`is_available()` returns `False`,
`generate()` raises `ProviderUnavailableError` with an actionable
message) and continues operating on deterministic capabilities —
it never hangs or crashes.

## Running JARVIS

```bash
python3 cli.py
# or, from the directory containing jarvis/:
python3 -m jarvis
```

```
JARVIS Core v1.0
Status: ONLINE
Type 'exit' or 'quit' to stop.

You: calculate 25 * 16
JARVIS: Sure — 25 * 16 = 400

You: remember that I prefer simple explanations
JARVIS: Got it, I'll remember that I prefer simple explanations.

You: my favorite programming language is Python
JARVIS: (quietly remembered — no explicit "remember" needed)

You: what do you remember about me
JARVIS: Here's what I remember:
- my favorite programming language is Python
- I prefer simple explanations

You: find the area of a circle
JARVIS: Sure, I can help with area of the circle. What is the radius?
You: 5 cm
JARVIS: The area of the circle is approximately 78.54.

You: open it
JARVIS: What would you like me to open?

You: delete all my files
JARVIS: This action could delete all my files. Do you want me to continue?
You: no
JARVIS: Okay, I've cancelled that.
```

A sample knowledge base (steam turbines, entropy) ships in
`data/knowledge/` so the demonstration commands work out of the box.
Drop your own `.txt`, `.md`, `.json`, or `.csv` files into that
folder and delete `data/knowledge_index.json` to force a rebuild (or
call `KnowledgeIndex.rebuild()` programmatically).

## Android app

The Android application (`../android/`) is the primary user interface
JARVIS is being built toward. It talks to this exact `JarvisCore` over
a small local REST bridge — nothing about the core changes to support
it. To run both together:

```bash
pip install -r requirements.txt   # installs Flask, the bridge's one dependency
python run_api.py                 # starts the bridge on http://127.0.0.1:8765
```

then open `android/` in Android Studio and run on an emulator (no
further config needed — see `docs/android-core-bridge.md` for the full
architecture, physical-device setup, and error-handling contract).

## Running the tests

```bash
python3 -m unittest discover -s tests -v
```

All 239 tests should pass (216 core + 23 for the Android REST bridge
in `tests/test_api.py`), in a few seconds (most of that time is
the deliberate real-timeout provider tests sleeping briefly), with
**no live model or actual Ollama/llama.cpp installation required** —
provider tests run against either a deliberately unreachable address
(connection-refused handling) or a real local `http.server` instance
spun up just for the test (genuine request/response/timeout handling)
— see [ARCHITECTURE.md's note on provider test methodology](ARCHITECTURE.md#note-on-provider-test-methodology).
(`pytest` works too if installed — the tests use plain `unittest` so
no extra dependency is required.)

## Adding a tool

1. Write a module in `tools/` with a function that takes plain
   arguments and returns a `dict` (see `tools/calculator.py` or
   `tools/geometry.py`).
2. Register it in `JarvisCore._register_default_tools()` with a
   `Tool(name, description, input_schema, risk_level,
   permission_required, execute=..., confirmation_required=...)`.
   Leave `confirmation_required=None` (the default) unless you have a
   specific reason to override the risk-derived default.
3. Route to it from `core/orchestrator.py` (a new handler, or slot
   -filling like the geometry tools) or call it directly via
   `self.executor.execute(name, **kwargs)`. Any tool call — whether
   proposed by a rule or by an AI provider — passes through
   `tools/validator.py` first, which re-derives risk/confirmation from
   the tool's own registered metadata; a requester's own claims about
   safety are never trusted (see `tools/validator.py`'s docstring).

## Adding a knowledge source

Drop a supported file (`.txt`, `.md`, `.json`, `.csv`, `.pdf` with
`pypdf` installed) into the configured `knowledge_directory` (default
`data/knowledge/`) and rebuild the index:

```python
from knowledge.search import KnowledgeIndex
KnowledgeIndex(knowledge_directory="data/knowledge",
               index_path="data/knowledge_index.json").rebuild()
```

To add a new *format*, add a reader function to
`knowledge/ingestion.py` and register it in `_READERS` — chunking,
indexing, and search all stay the same.

## Making the knowledge system RAG-ready (embeddings later)

`knowledge/interfaces.py` defines `DocumentStore`, `EmbeddingProvider`,
`Retriever`, and `KnowledgeStore`. `KnowledgeIndex` implements
`KnowledgeStore` today via keyword scoring. To add a real vector
backend (FAISS, Chroma, Qdrant, sqlite-vec, ...) later: implement a
new class satisfying the same `KnowledgeStore` interface (`search()`,
`add_document_text()`, `rebuild()`), optionally backed by a concrete
`EmbeddingProvider`, and pass an instance of it to `JarvisCore` in
place of `KnowledgeIndex`. Nothing in `core/orchestrator.py` or
`knowledge/verification.py` needs to change.

## Adding a memory type

Long-term memories now carry `content, category, timestamp,
importance, source, confidence, expires_at` (`memory/storage.py`,
migrated automatically for older databases via `MemoryStore._migrate`).
To add a distinct memory type (e.g. episodic vs. semantic), either use
the existing `category` field, or add a new table via a new `*Store`
class following `MemoryStore`'s pattern, exposed through a new method
on `LongTermMemory`. To change *what counts as worth remembering*,
edit `core/memory_policy.py`'s `_PERSONAL_FACT_PATTERNS` — never
bypass `contains_secret()`, which both `LongTermMemory.remember()`
and the auto-remember heuristic call unconditionally.

## Adding an AI provider

1. Implement `providers.base.AIProvider` (`generate`, `chat`,
   `summarize`, `classify`, `is_available`) in a new module under
   `providers/`, following `providers/ollama.py` as a template —
   unreachable-backend errors should raise `ProviderUnavailableError`,
   never propagate a raw connection exception.
2. Register it in `providers/factory.py`'s `_PROVIDERS` dict.
3. Set `AI_PROVIDER` (env) or `ai_provider` (config/JSON) to that name.

`JarvisCore` only ever talks to the abstract `AIProvider` interface
via the factory — no other file needs to change, and JARVIS keeps
working with its rule-based reasoning if the provider is unavailable
or misconfigured (a bad `AI_PROVIDER` value logs a warning and falls
back to `local` rather than crashing at startup).

### Preparing for a future custom JARVIS model

Nothing in `core/` cares whether `AIProvider` is backed by a small
local model, a large one, a fine-tuned "JARVIS model," or a cloud
model — they all look identical from `JarvisCore`'s side of the
interface. A future custom model becomes a new `providers/jarvis_model.py`
implementing the same four methods, registered in the same factory.

## Safety architecture

Every action is classified as `LOW`, `MEDIUM`, `HIGH`, or `CRITICAL`
risk (`safety/risk_classifier.py`) using explicit keyword/pattern
rules — this never changed from Phase 1. What Phase 1.1 adds is the
guarantee that this classification, and whether confirmation is
required, **cannot be influenced by an AI provider**, even when one is
consulted for intent classification:

- `core/nlu.classify_with_fallback()` always calls
  `safety.risk_classifier.classify_risk()` on the raw user text itself
  — never on anything the model returned — to set `risk_level`.
- If that computed risk is `HIGH` or `CRITICAL`, the intent `type` is
  force-set to `DANGEROUS_OPERATION` regardless of what the rules or
  the AI fallback classified it as. This closes a real bug found
  during development: an AI fallback that mislabeled "delete all my
  files" as `CONVERSATION` (with `requires_confirmation: false`) would
  otherwise never reach the confirmation gate at all, because routing
  was keyed on intent type. See `tests/test_nlu.py::TestSafetyCannotBeBypassed`
  and `tests/test_orchestrator_v1_1.py::TestSafetyCannotBeBypassedEndToEnd`
  for the regression tests.
- The same principle applies to tools: `tools/validator.py` derives
  `needs_confirmation`/`needs_permission` purely from the tool's own
  registered `risk_level`/`permission_required` — never from anything
  a requester (rule-based or AI) claims about the request.

Confirmation itself is still the same real state machine
(`safety/confirmation.py`) from Phase 1 — the pending action is held
in `ConfirmationManager.pending` and is not lost between messages.
"yes"/"no"/"cancel"/"stop"/"forget it" are recognized; anything else
triggers a re-prompt rather than guessing.

No tool that can actually delete files, change system settings, or
move money is wired up — dangerous actions are acknowledged as
`(simulated) <action>` after confirmation, by design.

## Testing

In addition to everything from Phase 1, `tests/` now covers: the
provider factory and config-driven selection, unreachable-server
handling for Ollama/llama.cpp (no live server required — every test
targets a deliberately closed port), malformed/invalid AI-classifier
JSON output, the confidence-gated fallback pipeline, the safety
-cannot-be-bypassed invariant (both at the NLU layer and end-to-end
through `JarvisCore`), memory-worth-remembering heuristics, secret
rejection (explicit and automatic), tool request validation (missing
args, unknown tools, a tool that can't self-report as safe), multi
-turn task slot-filling and cancellation, and ambiguous-reference
clarification.

## Known limitations (honestly stated)

- **No model is connected by default.** With `ai_provider=local`
  (the default), intent detection, reference resolution, and safety
  classification remain fully rule-based — this is robust and
  auditable for the demonstrated commands, but not general natural
  -language understanding. Connecting Ollama/llama.cpp (see above)
  adds real generation for ambiguous intents, open-ended conversation,
  and reasoning over retrieved passages — this was **still not
  testable against an actual running model** in the development
  sandbox (no network access to download Ollama/a model or reach a
  real server). Provider *code paths* are now verified against a real
  local `http.server` instance (genuine timeouts, genuine JSON
  parsing, genuine non-2xx handling) in addition to deliberately
  unreachable addresses and mocked/stub providers — this is
  meaningfully more real than the previous pass's mock-only coverage,
  but it is still not the same as a live model's actual output
  quality, latency, or occasional genuinely-malformed-but-plausible
  JSON. A live-model smoke test is recommended before production use.
- **Calculator limits are heuristic, not formally proven.** The
  bit-length estimate for `base ** exponent` (`log2(base) * exponent`)
  is a close approximation, not an exact pre-computation — it could in
  principle let through an edge case slightly over the nominal limit,
  or reject one slightly under it, by a small margin. It cannot let
  through anything catastrophically large, since the raw exponent cap
  (1000) is an independent, unconditional ceiling checked first.
- **Reference resolution is heuristic**, not true coreference
  resolution. It tracks one "current subject" at a time.
- **Knowledge search is keyword overlap, not semantic search** (see
  [RAG-ready section](#making-the-knowledge-system-rag-ready-embeddings-later)
  for the upgrade path).
- **Multi-turn tasks are narrow.** Only "area of a circle/rectangle"
  demonstrate the pending-task mechanism today; it generalizes to any
  tool with required parameters, but only those two are wired up as
  triggers in `core/orchestrator._maybe_start_pending_task`.
- **Memory-worth-remembering heuristics are conservative and
  pattern-based**, not learned. They will miss personal facts phrased
  unusually and will not learn from correction. Secret rejection
  (`core/memory_policy.contains_secret`) is pattern-based too — it
  catches common shapes (password/API-key/token phrasing, `sk-`
  -prefixed tokens, credit card numbers) but is not exhaustive; it is
  a real safeguard, not a guarantee against every possible way a
  secret could be phrased.
- **PDF ingestion depends on the optional `pypdf` package.**
- **No destructive tools are actually wired up** — see Safety
  architecture above. The tool-validation pipeline
  (`tools/validator.py` + `JarvisCore._execute_tool_safely`) is fully
  real and tested, but there is nothing registered yet that could
  actually delete a file or change a system setting for it to gate.
- **Single user, single session.** Confirmation state, pending tasks,
  and short-term memory all assume one conversation at a time.

## Recommended next step

Get a real model in the loop end-to-end: run Ollama locally, set
`AI_PROVIDER=ollama`/`AI_MODEL`, and smoke-test the fallback
classification, conversation, and RAG-reasoning paths against actual
model output — this remains the single biggest gap between "verified"
and "production-ready" in this codebase, since the development
environment never had network access to do this itself. After that,
per the original roadmap, Phase 2 (voice) can wrap
`JarvisCore.process()` with an STT/TTS front end with no core changes
needed, since the interface is already plain text in, plain
text out.
