"""
Knowledge ingestion.

Loads documents from a directory, normalizes their text, and splits
them into chunks with metadata. Keyword search (Phase 1) and any
future semantic/vector search both operate on these same Chunk
objects, so swapping the search backend later needs no change here.

PDF support is real but conditional: if the optional `pypdf` package
is not installed, PDFs are skipped with a clear message rather than
silently pretending to have ingested them.
"""

from __future__ import annotations

import csv
import json
import os
import re
from typing import List

from .documents import Chunk, Document

SUPPORTED_EXTENSIONS = {".txt", ".md", ".json", ".csv", ".pdf"}


def _normalize(text: str) -> str:
    text = text.replace("\r\n", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _chunk_text(text: str, doc_name: str, max_chars: int = 800) -> List[Chunk]:
    """Split on paragraph boundaries, then hard-wrap anything still too long."""
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks: List[Chunk] = []
    buffer = ""
    for para in paragraphs:
        if len(buffer) + len(para) + 1 <= max_chars:
            buffer = f"{buffer}\n{para}".strip()
        else:
            if buffer:
                chunks.append(Chunk(doc_name, len(chunks), buffer))
            if len(para) > max_chars:
                for i in range(0, len(para), max_chars):
                    chunks.append(Chunk(doc_name, len(chunks), para[i:i + max_chars]))
                buffer = ""
            else:
                buffer = para
    if buffer:
        chunks.append(Chunk(doc_name, len(chunks), buffer))
    return chunks


def _read_txt_or_md(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def _read_json(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        data = json.load(f)
    return json.dumps(data, indent=2, ensure_ascii=False)


def _read_csv(path: str) -> str:
    lines = []
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            lines.append(", ".join(row))
    return "\n".join(lines)


def _read_pdf(path: str) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        raise RuntimeError(
            "PDF ingestion requires the optional 'pypdf' package, which is not "
            "installed. Install it with 'pip install pypdf' to ingest PDFs; "
            "other formats (txt, md, json, csv) work without it."
        )
    reader = PdfReader(path)
    return "\n\n".join(page.extract_text() or "" for page in reader.pages)


_READERS = {
    ".txt": _read_txt_or_md,
    ".md": _read_txt_or_md,
    ".json": _read_json,
    ".csv": _read_csv,
    ".pdf": _read_pdf,
}


def ingest_file(path: str) -> Document:
    ext = os.path.splitext(path)[1].lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {ext}")
    reader = _READERS[ext]
    raw_text = reader(path)
    text = _normalize(raw_text)
    name = os.path.basename(path)
    chunks = _chunk_text(text, name)
    return Document(name=name, path=path, file_type=ext.lstrip("."), chunks=chunks)


def ingest_directory(directory: str) -> List[Document]:
    documents: List[Document] = []
    if not os.path.isdir(directory):
        return documents
    for entry in sorted(os.listdir(directory)):
        full_path = os.path.join(directory, entry)
        if not os.path.isfile(full_path):
            continue
        ext = os.path.splitext(entry)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            continue
        try:
            documents.append(ingest_file(full_path))
        except RuntimeError:
            # e.g. PDF without pypdf installed — skip, don't crash the whole ingest.
            continue
    return documents
