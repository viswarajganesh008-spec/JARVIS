"""
RAG-ready interfaces.

Phase 1.1 still ships the same keyword-overlap search from Phase 1 —
per the brief, we are not introducing a vector database dependency
yet. What changes is that the pieces are now named and separated the
way a future embeddings/vector-search backend would need them to be,
so swapping in FAISS/Chroma/Qdrant/sqlite-vec later means writing new
classes that implement these interfaces, not rewriting JarvisCore or
core/reasoning.py.

    DocumentStore     — where raw documents/chunks live
    EmbeddingProvider — turns text into vectors (no-op today)
    Retriever         — given a query, returns ranked SearchResult-like
                         objects (KnowledgeIndex.search already IS this)
    KnowledgeStore     — the combination JarvisCore actually talks to
                         (ingest + retrieve), currently = KnowledgeIndex
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, List, Protocol, runtime_checkable


@runtime_checkable
class SearchResultLike(Protocol):
    doc_name: str
    chunk_index: int
    text: str
    score: float


class DocumentStore(ABC):
    """Where ingested document chunks are kept."""

    @abstractmethod
    def add_document_text(self, doc_name: str, text: str) -> int:
        """Ingest raw text under a document name. Returns chunk count added."""

    @abstractmethod
    def rebuild(self) -> int:
        """Re-ingest everything from the backing source. Returns chunk count."""


class EmbeddingProvider(ABC):
    """Turns text into a vector representation.

    No implementation ships in Phase 1.1 — KnowledgeIndex does keyword
    scoring, not embeddings. This exists purely as the seam a future
    local embedding model (e.g. via the same provider factory pattern
    used for AIProvider) would implement.
    """

    @abstractmethod
    def embed(self, text: str) -> List[float]:
        raise NotImplementedError

    def is_available(self) -> bool:
        return False


class Retriever(ABC):
    """Given a query, return ranked, source-attributed results."""

    @abstractmethod
    def search(self, query: str, top_k: int = 3, min_score: float = 0.05) -> List[Any]:
        """Returns a list of objects satisfying SearchResultLike, best first."""


class KnowledgeStore(DocumentStore, Retriever):
    """The combined interface JarvisCore actually depends on.

    `knowledge.search.KnowledgeIndex` implements this today via keyword
    search. A future `SemanticKnowledgeStore` (embeddings + a vector
    index) implementing the same methods can be swapped in via
    JarvisCore's constructor with no other code changes.
    """
