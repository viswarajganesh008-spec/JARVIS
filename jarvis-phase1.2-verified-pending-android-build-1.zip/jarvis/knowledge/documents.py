"""
Data models for the knowledge engine.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class Chunk:
    doc_name: str
    chunk_index: int
    text: str

    def to_dict(self) -> dict:
        return {"doc_name": self.doc_name, "chunk_index": self.chunk_index, "text": self.text}

    @classmethod
    def from_dict(cls, d: dict) -> "Chunk":
        return cls(d["doc_name"], d["chunk_index"], d["text"])


@dataclass
class Document:
    name: str
    path: str
    file_type: str
    chunks: List[Chunk] = field(default_factory=list)
