"""
Verification layer.

This is what stops JARVIS from fabricating an answer or a source. It
decides, given search results, whether there is enough grounded
information to answer at all, and formats the "according to X"
attribution rather than presenting knowledge as if it came from
nowhere.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from .search import SearchResult

DEFAULT_CONFIDENCE_THRESHOLD = 0.15


@dataclass
class VerifiedAnswer:
    grounded: bool
    text: Optional[str]
    source_doc: Optional[str]
    source_chunk_index: Optional[int]
    confidence: float


def verify_and_format(results: List[SearchResult],
                       threshold: float = DEFAULT_CONFIDENCE_THRESHOLD) -> VerifiedAnswer:
    if not results or results[0].score < threshold:
        return VerifiedAnswer(grounded=False, text=None, source_doc=None,
                               source_chunk_index=None, confidence=0.0)
    best = results[0]
    return VerifiedAnswer(
        grounded=True,
        text=best.text,
        source_doc=best.doc_name,
        source_chunk_index=best.chunk_index,
        confidence=best.score,
    )
