"""
Knowledge search.

Phase 1 implements simple keyword/overlap scoring against an index
built from ingested chunks. The public interface (`KnowledgeIndex`,
`search()`, `SearchResult`) is deliberately backend-agnostic: a
future SemanticSearchIndex (embeddings + vector store) can implement
the same `search(query) -> List[SearchResult]` contract and be
swapped in via config without changing JARVIS Core or the reasoning
layer that calls it.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import List

from .documents import Chunk, Document
from .ingestion import ingest_directory
from .interfaces import KnowledgeStore

_WORD_RE = re.compile(r"[a-z0-9]+")


def _tokenize(text: str) -> List[str]:
    return _WORD_RE.findall(text.lower())


@dataclass
class SearchResult:
    doc_name: str
    chunk_index: int
    text: str
    score: float

    def to_dict(self) -> dict:
        return {
            "doc_name": self.doc_name,
            "chunk_index": self.chunk_index,
            "text": self.text,
            "score": self.score,
        }


class KnowledgeIndex(KnowledgeStore):
    """Simple in-memory keyword index, persisted as JSON.

    Implements the RAG-ready `KnowledgeStore` interface (knowledge/interfaces.py)
    via keyword/overlap scoring rather than embeddings — see that module's
    docstring for how a future semantic backend plugs in instead.
    """

    def __init__(self, knowledge_directory: str = "data/knowledge",
                 index_path: str = "data/knowledge_index.json"):
        self.knowledge_directory = knowledge_directory
        self.index_path = index_path
        self.chunks: List[Chunk] = []
        self._load_or_build()

    def _load_or_build(self) -> None:
        if os.path.exists(self.index_path):
            self._load()
        else:
            self.rebuild()

    def _load(self) -> None:
        with open(self.index_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.chunks = [Chunk.from_dict(c) for c in data.get("chunks", [])]

    def _persist(self) -> None:
        os.makedirs(os.path.dirname(self.index_path) or ".", exist_ok=True)
        with open(self.index_path, "w", encoding="utf-8") as f:
            json.dump({"chunks": [c.to_dict() for c in self.chunks]}, f, indent=2)

    def rebuild(self) -> int:
        documents: List[Document] = ingest_directory(self.knowledge_directory)
        self.chunks = [c for doc in documents for c in doc.chunks]
        self._persist()
        return len(self.chunks)

    def add_document_text(self, doc_name: str, text: str) -> int:
        """Ingest raw text directly (useful for tests / programmatic ingestion)."""
        from .ingestion import _chunk_text, _normalize
        new_chunks = _chunk_text(_normalize(text), doc_name)
        # Replace any existing chunks for this doc name, then append the new ones.
        self.chunks = [c for c in self.chunks if c.doc_name != doc_name] + new_chunks
        self._persist()
        return len(new_chunks)

    def search(self, query: str, top_k: int = 3, min_score: float = 0.05) -> List[SearchResult]:
        query_tokens = set(_tokenize(query))
        if not query_tokens or not self.chunks:
            return []
        scored: List[SearchResult] = []
        for chunk in self.chunks:
            chunk_tokens = _tokenize(chunk.text)
            if not chunk_tokens:
                continue
            chunk_token_set = set(chunk_tokens)
            overlap = query_tokens & chunk_token_set
            if not overlap:
                continue
            # Score: fraction of query terms found, weighted lightly by density in chunk.
            score = len(overlap) / len(query_tokens)
            density = sum(chunk_tokens.count(t) for t in overlap) / len(chunk_tokens)
            score = round(min(1.0, score + 0.2 * density), 4)
            if score >= min_score:
                scored.append(SearchResult(chunk.doc_name, chunk.chunk_index, chunk.text, score))
        scored.sort(key=lambda r: r.score, reverse=True)
        return scored[:top_k]
