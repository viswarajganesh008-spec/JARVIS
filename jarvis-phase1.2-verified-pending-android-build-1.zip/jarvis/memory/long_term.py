"""
Long-term memory: information explicitly worth remembering across
sessions ("remember that I prefer explanations with examples").

This does NOT store every conversation turn automatically — only
what is explicitly committed via `remember()`, or what
core/memory_policy.py flags as a clear personal-fact statement. Short
-term/session context lives in memory/short_term.py instead.

Secrets (passwords, API keys, tokens, etc.) are never stored, even on
an explicit "remember" request — this mirrors the safety engine's
principle that some things aren't overridable by request.
"""

from __future__ import annotations

from typing import List, Optional

from core.memory_policy import contains_secret
from .storage import MemoryStore, MemoryRecord


class MemoryRejectedError(Exception):
    """Raised when content must not be stored (e.g. it looks like a secret)."""


class LongTermMemory:
    def __init__(self, db_path: str = "data/memory.db"):
        self.store = MemoryStore(db_path)

    def remember(self, content: str, category: str = "general",
                 importance: int = 1, source: str = "user",
                 confidence: float = 1.0,
                 expires_at: Optional[float] = None) -> MemoryRecord:
        if contains_secret(content):
            raise MemoryRejectedError(
                "That looks like a password, API key, or other credential — "
                "I won't store it in memory, even on request."
            )
        return self.store.add(content, category=category, importance=importance,
                               source=source, confidence=confidence, expires_at=expires_at)

    def retrieve(self, query: str) -> List[MemoryRecord]:
        return self.store.search(query)

    def list_all(self) -> List[MemoryRecord]:
        return self.store.list_all()

    def update(self, memory_id: int, content: Optional[str] = None,
               category: Optional[str] = None, importance: Optional[int] = None) -> bool:
        if content is not None and contains_secret(content):
            raise MemoryRejectedError(
                "That looks like a password, API key, or other credential — "
                "I won't store it in memory, even on request."
            )
        return self.store.update(memory_id, content=content, category=category,
                                  importance=importance)

    def delete(self, memory_id: int) -> bool:
        return self.store.delete(memory_id)

    def forget(self, query: str) -> int:
        """Delete all memories whose content matches `query`. Returns count deleted."""
        return self.store.delete_matching(query)

    def forget_all(self) -> None:
        self.store.clear()

    def purge_expired(self) -> int:
        return self.store.delete_expired()

    def close(self) -> None:
        self.store.close()
