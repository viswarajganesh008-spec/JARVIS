"""
SQLite storage backend for JARVIS long-term memory.

Chosen over a folder of JSON files because it gives us real querying,
atomic writes, and a schema we can evolve with migrations instead of
hand-rolled file parsing.
"""

from __future__ import annotations

import os
import sqlite3
import time
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class MemoryRecord:
    id: Optional[int]
    content: str
    category: str
    timestamp: float
    importance: int
    source: str
    confidence: float = 1.0
    expires_at: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "content": self.content,
            "category": self.category,
            "timestamp": self.timestamp,
            "importance": self.importance,
            "source": self.source,
            "confidence": self.confidence,
            "expires_at": self.expires_at,
        }

    def is_expired(self, now: Optional[float] = None) -> bool:
        if self.expires_at is None:
            return False
        return (now if now is not None else time.time()) >= self.expires_at


SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    timestamp REAL NOT NULL,
    importance INTEGER NOT NULL DEFAULT 1,
    source TEXT NOT NULL DEFAULT 'user',
    confidence REAL NOT NULL DEFAULT 1.0,
    expires_at REAL
);
"""

_COLUMNS = "id, content, category, timestamp, importance, source, confidence, expires_at"


class MemoryStore:
    """Thin, explicit wrapper around a SQLite database for memories.

    Kept separate from the higher-level LongTermMemory API so the
    storage engine (SQLite today) can be swapped later without
    touching any code that calls LongTermMemory.
    """

    def __init__(self, db_path: str = "data/memory.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
        self._conn = sqlite3.connect(self.db_path)
        self._conn.execute(SCHEMA)
        self._conn.commit()
        self._migrate()

    def _migrate(self) -> None:
        """Add columns introduced after the original schema, for DBs created
        by an earlier version of JARVIS. Safe to run every startup."""
        existing = {row[1] for row in self._conn.execute("PRAGMA table_info(memories)")}
        if "confidence" not in existing:
            self._conn.execute("ALTER TABLE memories ADD COLUMN confidence REAL NOT NULL DEFAULT 1.0")
        if "expires_at" not in existing:
            self._conn.execute("ALTER TABLE memories ADD COLUMN expires_at REAL")
        self._conn.commit()

    def add(self, content: str, category: str = "general", importance: int = 1,
            source: str = "user", confidence: float = 1.0,
            expires_at: Optional[float] = None) -> MemoryRecord:
        ts = time.time()
        cur = self._conn.execute(
            "INSERT INTO memories (content, category, timestamp, importance, source, "
            "confidence, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (content, category, ts, importance, source, confidence, expires_at),
        )
        self._conn.commit()
        return MemoryRecord(cur.lastrowid, content, category, ts, importance, source,
                             confidence, expires_at)

    def get(self, memory_id: int) -> Optional[MemoryRecord]:
        row = self._conn.execute(
            f"SELECT {_COLUMNS} FROM memories WHERE id = ?", (memory_id,)
        ).fetchone()
        return MemoryRecord(*row) if row else None

    def list_all(self) -> List[MemoryRecord]:
        rows = self._conn.execute(
            f"SELECT {_COLUMNS} FROM memories ORDER BY timestamp DESC"
        ).fetchall()
        return [MemoryRecord(*r) for r in rows]

    def search(self, query: str) -> List[MemoryRecord]:
        like = f"%{query}%"
        rows = self._conn.execute(
            f"SELECT {_COLUMNS} FROM memories WHERE content LIKE ? ORDER BY timestamp DESC",
            (like,),
        ).fetchall()
        return [MemoryRecord(*r) for r in rows]

    def update(self, memory_id: int, content: Optional[str] = None,
               category: Optional[str] = None, importance: Optional[int] = None,
               confidence: Optional[float] = None) -> bool:
        existing = self.get(memory_id)
        if not existing:
            return False
        content = content if content is not None else existing.content
        category = category if category is not None else existing.category
        importance = importance if importance is not None else existing.importance
        confidence = confidence if confidence is not None else existing.confidence
        self._conn.execute(
            "UPDATE memories SET content = ?, category = ?, importance = ?, confidence = ? "
            "WHERE id = ?",
            (content, category, importance, confidence, memory_id),
        )
        self._conn.commit()
        return True

    def delete(self, memory_id: int) -> bool:
        cur = self._conn.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
        self._conn.commit()
        return cur.rowcount > 0

    def delete_matching(self, query: str) -> int:
        matches = self.search(query)
        for m in matches:
            self._conn.execute("DELETE FROM memories WHERE id = ?", (m.id,))
        self._conn.commit()
        return len(matches)

    def delete_expired(self, now: Optional[float] = None) -> int:
        now = now if now is not None else time.time()
        cur = self._conn.execute(
            "DELETE FROM memories WHERE expires_at IS NOT NULL AND expires_at <= ?", (now,)
        )
        self._conn.commit()
        return cur.rowcount

    def clear(self) -> None:
        self._conn.execute("DELETE FROM memories")
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()
