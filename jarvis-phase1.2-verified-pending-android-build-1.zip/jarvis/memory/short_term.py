"""
Short-term memory: the current conversation, current task, and
recently touched entities. Bounded so it never grows unbounded —
size is controlled by config (`max_context_messages`).
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional


@dataclass
class Turn:
    role: str  # "user" or "jarvis"
    text: str


class ShortTermMemory:
    def __init__(self, max_messages: int = 20):
        self.max_messages = max_messages
        self.turns: Deque[Turn] = deque(maxlen=max_messages)
        self.current_task: Optional[str] = None
        self.recent_tool_results: Deque[dict] = deque(maxlen=5)

    def add_turn(self, role: str, text: str) -> None:
        self.turns.append(Turn(role, text))

    def add_tool_result(self, tool_name: str, result: dict) -> None:
        self.recent_tool_results.append({"tool": tool_name, "result": result})

    def recent_history(self, n: Optional[int] = None) -> List[Turn]:
        items = list(self.turns)
        return items[-n:] if n else items

    def clear(self) -> None:
        self.turns.clear()
        self.current_task = None
        self.recent_tool_results.clear()
