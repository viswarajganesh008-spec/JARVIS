"""
Risk classifier.

Phase 1 uses transparent, auditable keyword/pattern rules rather than
a model, precisely because safety decisions must be inspectable and
predictable. This can later be augmented (never silently replaced)
by an AIProvider-backed classifier for judgment calls the rules miss.
"""

from __future__ import annotations

import re
from enum import Enum


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


_CRITICAL_PATTERNS = [
    r"\bfactory reset\b",
    r"\bdelete everything\b",
    r"\bwipe (the )?(device|system|drive|disk|everything)\b",
    r"\bformat (the )?(disk|drive|hard drive|c:)\b",
    r"\breinstall (the )?(os|operating system)\b",
]

_HIGH_PATTERNS = [
    r"\bdelete all\b",
    r"\bdelete .*\bfiles\b",
    r"\bremove .*\bfiles\b",
    r"\bdelete .*\bfolder\b",
    r"\brm -rf\b",
    r"\binstall\b",
    r"\buninstall\b",
    r"\bchange .*(system settings|password|permissions)\b",
    r"\btransfer money\b",
    r"\bsend money\b",
    r"\bmake (a )?payment\b",
    r"\bshut ?down (the )?(system|computer|device)\b",
]

_MEDIUM_PATTERNS = [
    r"\bsend (a )?message\b",
    r"\bsend (an )?email\b",
    r"\bcreate (an )?appointment\b",
    r"\bschedule\b",
    r"\bmodify (a |the )?file\b",
    r"\bedit (a |the )?file\b",
    r"\brename\b",
    r"\bmove (a |the )?file\b",
]


def classify_risk(action_text: str) -> RiskLevel:
    text = action_text.lower()

    for pattern in _CRITICAL_PATTERNS:
        if re.search(pattern, text):
            return RiskLevel.CRITICAL

    for pattern in _HIGH_PATTERNS:
        if re.search(pattern, text):
            return RiskLevel.HIGH

    for pattern in _MEDIUM_PATTERNS:
        if re.search(pattern, text):
            return RiskLevel.MEDIUM

    return RiskLevel.LOW


def requires_confirmation(risk: RiskLevel, confirmation_policy: str = "risky_only") -> bool:
    """Decide whether an action at this risk level needs explicit confirmation.

    confirmation_policy:
      - "always": confirm everything above LOW
      - "risky_only": confirm MEDIUM/HIGH/CRITICAL (default)
      - "never": only ever confirm CRITICAL (HIGH still forced True for safety)
    """
    if risk == RiskLevel.CRITICAL:
        return True
    if risk == RiskLevel.HIGH:
        return True  # HIGH always requires confirmation regardless of policy
    if risk == RiskLevel.MEDIUM:
        return confirmation_policy in ("always", "risky_only")
    return confirmation_policy == "always"
