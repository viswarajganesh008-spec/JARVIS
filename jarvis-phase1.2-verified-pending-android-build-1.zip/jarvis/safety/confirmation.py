"""
Confirmation state machine.

Holds exactly one pending action at a time (Phase 1 is single-user,
single-session). The pending action is never lost between messages —
it lives here, not in a variable that gets discarded after a turn.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, Optional

from .risk_classifier import RiskLevel

_YES_PATTERNS = [r"^yes\b", r"^yeah\b", r"^yep\b", r"^confirm\b", r"^go ahead\b", r"^do it\b",
                 r"^sure\b", r"^ok(ay)?\b"]
_NO_PATTERNS = [r"^no\b", r"^nope\b", r"^cancel\b", r"^stop\b", r"^forget it\b",
                r"^don'?t\b", r"^never ?mind\b"]


class ConfirmationState(str, Enum):
    IDLE = "IDLE"
    WAITING_FOR_CONFIRMATION = "WAITING_FOR_CONFIRMATION"


class ConfirmationResult(str, Enum):
    CONFIRMED = "CONFIRMED"
    CANCELLED = "CANCELLED"
    AMBIGUOUS = "AMBIGUOUS"


@dataclass
class PendingAction:
    description: str
    risk_level: RiskLevel
    tool_name: Optional[str]
    tool_kwargs: Dict[str, Any]


class ConfirmationManager:
    def __init__(self):
        self.state = ConfirmationState.IDLE
        self.pending: Optional[PendingAction] = None

    def request(self, description: str, risk_level: RiskLevel,
                tool_name: Optional[str] = None, tool_kwargs: Optional[Dict[str, Any]] = None) -> str:
        self.pending = PendingAction(description, risk_level, tool_name, tool_kwargs or {})
        self.state = ConfirmationState.WAITING_FOR_CONFIRMATION
        return self._prompt_for(description, risk_level)

    def _prompt_for(self, description: str, risk_level: RiskLevel) -> str:
        if risk_level == RiskLevel.CRITICAL:
            return (f"This is a critical, likely irreversible action: {description}. "
                    f"Please confirm explicitly: yes or no.")
        return f"This action could {description}. Do you want me to continue?"

    def is_waiting(self) -> bool:
        return self.state == ConfirmationState.WAITING_FOR_CONFIRMATION

    def respond(self, user_text: str) -> ConfirmationResult:
        text = user_text.strip().lower()
        if any(re.search(p, text) for p in _YES_PATTERNS):
            return ConfirmationResult.CONFIRMED
        if any(re.search(p, text) for p in _NO_PATTERNS):
            return ConfirmationResult.CANCELLED
        return ConfirmationResult.AMBIGUOUS

    def resolve(self) -> None:
        """Clear the pending action after it has been confirmed or cancelled."""
        self.pending = None
        self.state = ConfirmationState.IDLE
