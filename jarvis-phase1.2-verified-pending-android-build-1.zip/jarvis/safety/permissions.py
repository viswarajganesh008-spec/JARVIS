"""
Permissions.

Phase 1 has a single local user, so this is intentionally minimal: it
answers "does this tool/action require explicit permission before
execution" based on the tool's own declared `permission_required`
flag and its risk level. This is the seam where a future multi-user
or capability-based permission system plugs in without changing
callers — they only ever ask `permission_required_for(...)`.
"""

from __future__ import annotations

from safety.risk_classifier import RiskLevel


def permission_required_for(risk_level: RiskLevel, tool_permission_required: bool = False) -> bool:
    if tool_permission_required:
        return True
    return risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL)
