"""
JARVIS Core — CLI interface.

Run with: python cli.py
"""

from __future__ import annotations

import sys

from config.config import JarvisConfig
from core.orchestrator import JarvisCore

BANNER = """JARVIS Core v1.0
Status: ONLINE
Type 'exit' or 'quit' to stop.
"""


def main() -> None:
    config = JarvisConfig.load()
    jarvis = JarvisCore(config)
    print(BANNER)
    try:
        while True:
            try:
                user_input = input("You: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit"):
                break
            reply = jarvis.process(user_input)
            print(f"JARVIS: {reply}\n")
    finally:
        jarvis.close()
        print("JARVIS Core shutting down.")


if __name__ == "__main__":
    sys.exit(main())
