# ARCHITECTURE.md

This document explains how JARVIS Core's components actually
communicate, turn by turn, as of the Phase 1.1 Final Hardening pass.
Phase 1's turn-by-turn flow is preserved and extended, not replaced —
see each section for what changed and why.

## What the hardening pass changed

Three things, on top of everything Phase 1.1 already had:

1. **Calculator resource-exhaustion hardening** (`tools/calculator.py`).
   Python integers are arbitrary-precision, so a syntactically valid
   expression like `2 ** 999999999` or a 40-digit literal could consume
   unbounded CPU/memory before ever producing a result. Every limit
   (max exponent, max literal size, max expression length, max AST
   nesting depth, max operation count, max result bit-length) is a
   *pre-check* that runs before the expensive operation, not a
   post-hoc timeout — see [Calculator hardening](#calculator-hardening).
   The calculator also gained a small whitelist of math functions
   (`sqrt`, `sin`, `cos`, `tan`, `log`, ...) via the same AST-walking
   approach as before — still no `eval()`.
2. **Tool execution unified behind the validator.** `tools/validator.py`
   existed in Phase 1.1 but wasn't actually on the execution path —
   `core/orchestrator.py` called `ToolExecutor.execute()` directly.
   `JarvisCore._execute_tool_safely()` is now the *only* method that
   calls a tool, and it always calls `validate_tool_request()` first —
   see [Model output safety](#model-output-safety).
3. **NLU schema flexibility + provider realism.** The AI-fallback
   classifier now accepts either its own documented JSON shape or the
   exact example shape given in later specs (`"intent"` vs
   `"intent_type"`, list- or dict-shaped `"entities"`). Providers gained
   explicit `system` instruction support reaching the actual request
   payload (tested against a real local HTTP server, not just mocks).

## Design principle

Knowledge retrieval, reasoning, tools, memory, and safety are kept in
separate packages that only depend on each other through narrow
interfaces (a function signature, a dataclass, an abstract base
class) — never by reaching into each other's internals. Phase 1.1's
central design constraint follows from this: **the AI model is a
component JARVIS may consult, not a thing JARVIS delegates authority
to.** Concretely, that means every safety-relevant decision is made
by deterministic code that runs *after* any model output and is never
overridden by it. See [Safety flow](#safety-flow) for exactly where
that's enforced.

## System architecture

```
                              User
                               |
                          Interface (cli.py / __main__.py)
                               |
                    +----------v-----------+
                    |      JarvisCore       |   core/orchestrator.py
                    |  (the only place that  |   — the sole integration point
                    |   wires layers together)|
                    +----------+-----------+
                               |
       +----------+------------+------------+-----------+
       |          |            |            |           |
   Context      NLU        Reasoning     Memory      Knowledge
 (core/       (core/       (core/       (memory/)    (knowledge/)
 context.py)   nlu.py)    reasoning.py)     |             |
       |          |            |        long_term.py   ingestion.py
  pending_task  rule-based   decide():   short_term.py  search.py
  history      + AI fallback  intent ->                verification.py
  references   (confidence-   handler                  interfaces.py
               gated)         mapping
       |          |            |            |             |
       +----------+------------+------------+-------------+
                               |
                    +----------v-----------+
                    |     Safety Engine     |   safety/
                    | risk_classifier.py     |   deterministic,
                    | confirmation.py        |   NEVER model-controlled
                    | permissions.py         |
                    +----------+-----------+
                               |
                    +----------v-----------+
                    |    Tools (tools/)      |   registry.py, validator.py,
                    |  registry -> validator  |   executor.py, calculator.py,
                    |  -> executor            |   geometry.py
                    +----------+-----------+
                               |
                    +----------v-----------+
                    |  AI Provider (opt.)    |   providers/
                    |  local / ollama /       |   base.py, factory.py,
                    |  llamacpp                |   local.py, ollama.py,
                    +----------+-----------+   llamacpp.py
                               |
                    +----------v-----------+
                    | Response Engine        |   core/response.py
                    | (core/response.py)     |
                    +----------+-----------+
                               |
                              User
```

## Request lifecycle (turn-by-turn)

`JarvisCore.process(user_text)` in `core/orchestrator.py` is still the
only place that wires layers together. For a normal message with no
pending confirmation or task:

1. **Pending confirmation check.** If `ConfirmationManager.is_waiting()`,
   the message is interpreted as yes/no/ambiguous and nothing below
   runs — see [Safety flow](#safety-flow).
2. **Pending task check.** If `ContextManager.has_pending_task()`
   (e.g. JARVIS is waiting on a circle's radius), the message is
   treated as a slot value, not a fresh command — see
   [Multi-turn task flow](#multi-turn-task-flow).
3. **Capture prior context.** The current tracked subject/topic is
   saved (`self._prior_target`) *before* anything about this turn
   updates it, then `ContextManager.update_from_user_message` appends
   to history and re-derives a subject from the raw message.
4. **Structured intent understanding** (`core/nlu.classify_with_fallback`):
   - `classify_intent()` (`core/intent.py`) runs first, against raw
     text, and now returns a `confidence` in `[0, 1]` alongside type
     /risk/payload — high for an explicit pattern match ("calculate
     ...", "remember that ..."), low for the catch-all
     QUESTION/CONVERSATION branches.
   - If confidence is below `nlu_confidence_threshold` (config) **and**
     an AI provider is configured and reachable, `_try_ai_classification`
     asks it for a structured JSON classification via
     `AIProvider.generate_json()`. Invalid JSON, an unknown intent
     type, or any exception falls back to the rule-based result — the
     AI fallback can only ever be *used*, never *required*.
   - `_finalize_safety_fields` then runs unconditionally on whichever
     result was chosen — see [Safety flow](#safety-flow) for exactly
     what it does and why it's the one part of this pipeline that
     isn't allowed to trust the model.
5. **Ambiguous-reference guard.** A `TOOL_OPERATION` whose payload is a
   bare pronoun ("open it") returns a clarification question instead
   of proceeding — see [Uncertainty handling](#uncertainty-handling).
6. **Multi-turn task detection.** Certain phrasings ("area of a
   circle" without a radius already given) start a pending task and
   return a slot-filling prompt instead of routing further.
7. **Decision.** `decide()` (`core/reasoning.py`) maps the
   (now-finalized) intent type to a handler method name and confirms
   `needs_confirmation` — recomputed here too, from the same
   deterministic rules, as a second, independent check.
8. **Safety gate.** If confirmation is needed, `ConfirmationManager.request()`
   holds the pending action and returns a prompt; nothing executes.
9. **Handler dispatch.** The matching `handle_*` method runs, calling
   into `memory/`, `knowledge/`, or `tools/` as needed. Only the
   question/knowledge handlers resolve references
   (`ContextManager.resolve_references(text, target=self._prior_target)`),
   using the subject captured in step 3 — not whatever step 3's own
   state update just derived from the *current* message — so "when
   was he born?" resolves against the *previous* turn's subject, and
   "remember **that** I like examples" is never corrupted by treating
   "that" as a pronoun (memory/tool intents never get resolved text).
10. **Memory intelligence.** After the handler runs (and only for
    intents that weren't already an explicit memory command),
    `_maybe_auto_remember` calls `core/memory_policy.decide_memory_action`
    on the raw message — see [Memory flow](#memory-flow).
11. **Response.** The handler's return value goes back to the caller
    and is appended to history; `ContextManager.record_turn_outcome`
    stores the intent type and response text for the *next* turn's
    context-building.

## Provider architecture

```
core/orchestrator.py
        |
        | imports only:
        v
providers/base.py (AIProvider — abstract: generate, chat, summarize,
                    classify, is_available, generate_json)
        ^
        | implemented by (selected at runtime via providers/factory.py)
        |
   +----+-------------------+--------------------+
   |                        |                    |
providers/local.py   providers/ollama.py   providers/llamacpp.py
LocalAIProvider       OllamaProvider         LlamaCppProvider
(always available,    (stdlib urllib ->      (stdlib urllib ->
 always raises         Ollama /api/generate    llama.cpp server
 ProviderUnavailable-  and /api/chat)          /completion)
 Error on generate)
```

`providers/factory.get_provider(name, **kwargs)` is the single place
that maps a config string to a class; `get_provider_from_config(config)`
builds one directly from a `JarvisConfig`. `JarvisCore.__init__` calls
`_build_provider`, which catches `UnknownProviderError`/`ValueError`
(bad provider name, or e.g. Ollama selected with no `AI_MODEL`) and
falls back to `LocalAIProvider` with a logged warning — a
configuration mistake degrades gracefully rather than crashing
startup. Runtime unavailability (server not running) is a different,
expected condition: `is_available()` returns `False` cheaply (a
short-timeout health check), and `generate()`/`chat()`/etc. raise
`ProviderUnavailableError` with an actionable message rather than
hanging — every call site in `core/orchestrator.py` catches this
specific exception and falls back to a deterministic response.

`AIProvider.generate_json()` (defined once in `providers/base.py`,
inherited by every provider) wraps `generate()` and adds JSON parsing
with prose/code-fence salvage, raising `ProviderResponseError` on
anything unparseable — this is what `core/nlu.py` calls, so it only
ever has to handle two exception types (`ProviderUnavailableError`,
`ProviderResponseError`), never hand-roll JSON parsing itself.

## Safety flow

```
  raw user text
        |
        v
  classify_risk(raw_text)   <- safety/risk_classifier.py
        |                      deterministic keyword/pattern rules,
        |                      runs on RAW TEXT ONLY, never on
        |                      anything an AI provider returned
        v
  risk in {HIGH, CRITICAL}? --yes--> intent.type FORCED to
        |                            DANGEROUS_OPERATION,
        no                           regardless of what the rule
        |                            engine or AI fallback classified
        v                            it as
  intent.type as classified
        |
        v
  requires_confirmation(risk, confirmation_policy)
        |
        v
  ConfirmationManager.request() -> pending action held in
  ConfirmationManager.pending (survives across messages) -> prompt
        |
        v
  user replies yes/no/ambiguous -> execute / cancel / re-prompt
```

This is `core/nlu._finalize_safety_fields`, and it is the fix for a
real bug found during Phase 1.1 development: a stub AI provider that
classified "delete all my files" as `CONVERSATION` with
`requires_confirmation: false` produced a `StructuredIntent` that
never reached the confirmation check at all, because routing was
keyed on intent *type*, and type came straight from the model.
`_finalize_safety_fields` closes this by making the *deterministically
computed risk* authoritative over type, not just over the
risk/confirmation fields — a HIGH/CRITICAL-risk message becomes
`DANGEROUS_OPERATION` unconditionally. Regression tests:
`tests/test_nlu.py::TestSafetyCannotBeBypassed`,
`tests/test_orchestrator_v1_1.py::TestSafetyCannotBeBypassedEndToEnd`.

The same non-negotiable-safety principle is enforced independently
for tools: `tools/validator.validate_tool_request()` derives
`needs_confirmation`/`needs_permission` from the `Tool`'s own
registered `risk_level`/`permission_required`/`confirmation_required`
— metadata set once, at registration time, by application code — never
from anything the requester (`ToolRequest.requested_by == "ai"` or
`"rule_based"`) claims about its own request.

## Memory flow

```
  raw user text
        |
        v
  explicit "remember that X" / "forget X" / "what do you remember"?
        |                                          |
       yes                                         no
        |                                          |
        v                                          v
  handled directly by                    handler for the ACTUAL
  handle_memory_* (core/                 intent runs first (e.g.
  orchestrator.py)                       handle_conversation) --
        |                                then, after the reply is
        v                                built:
  LongTermMemory.remember()                        |
  ALWAYS checks contains_secret()                   v
  first (core/memory_policy.py) --          decide_memory_action(text)
  raises MemoryRejectedError if it          (core/memory_policy.py)
  looks like a password/API key/            |
  token/credit card, even on an     matched a personal-fact pattern
  explicit request                  (preference/identity) AND not a
        |                           question AND not a secret?
        v                                   |
  stored with confidence + optional        yes -> LongTermMemory.remember(
  expires_at (memory/storage.py)                   source="auto")
                                            no  -> nothing stored
```

`contains_secret()` is the one check both paths share — it cannot be
bypassed by phrasing, by explicit request, or by the auto-remember
heuristic accidentally matching a preference-shaped sentence that
happens to contain a credential.

## Knowledge / RAG flow

```
  question / knowledge query text
        |
        v
  ContextManager.resolve_references(text, target=prior_target)
        |
        v
  KnowledgeIndex.search(query)  -> List[SearchResult]  (keyword overlap,
        |                          knowledge/search.py)
        v
  verify_and_format(results)  -> VerifiedAnswer(grounded, source_doc,
        |                        text, confidence)   (knowledge/verification.py)
        v
  grounded?
   |            \
  yes             no
   |               \
   v                 v
  AI provider     AI provider available?
  available?         |            \
   |    \           yes            no
  yes    no          |              \
   |      \          v                v
   v        v    provider.generate(   R.knowledge_unavailable()
"Based on   "According  question)     ("I don't currently have
 <source>:   to         (ungrounded -  enough information...")
 <reasoned   <source>:  not attributed
 answer>"    <raw       to a source)
 (still      chunk>"
 grounded,
 reasoned
 over ONLY
 the
 retrieved
 passage)
```

The prompt sent to the provider for the "grounded + reasoning" case
explicitly instructs it to answer using *only* the retrieved passage
and not add outside facts — this is a prompting convention, not an
enforced constraint (Phase 1.1 has no way to verify the model actually
complied), which is why the response is still labeled "Based on
`<source>`" rather than presented as independently verified.

`knowledge/interfaces.py` defines the RAG-ready seam
(`DocumentStore`, `EmbeddingProvider`, `Retriever`, `KnowledgeStore`);
`KnowledgeIndex` implements `KnowledgeStore` via keyword scoring today.
A future embeddings-backed store implementing the same interface swaps
in at `JarvisCore.__init__` with no change to this flow.

## Multi-turn task flow

```
  "find the area of a circle"  (no radius given)
        |
        v
  _maybe_start_pending_task() matches -> ContextManager.start_pending_task(
        |                                  "circle_area", "circle_area", ["radius"])
        v
  R.task_ask_for_slot(...) -> "What is the radius?"
        |
        v
  [next message]  "5 cm"
        |
        v
  process() sees has_pending_task() FIRST, before intent classification
        |
        v
  extract_number("5 cm") -> 5.0 -> ContextManager.fill_pending_slot("radius", 5.0)
        |
        v
  task.is_complete()? -> yes -> ToolExecutor.execute("circle_area", radius=5.0)
        |                       (same executor, same path as any other tool call)
        v
  ContextManager.clear_pending_task() -> R.task_result(...)
```

A non-numeric reply re-prompts for the same slot rather than
advancing or guessing; "cancel"/"stop"/"never mind"/"forget it" clears
the pending task at any point. This reuses the same "state that
survives across messages" pattern as `ConfirmationManager` —
`ContextState.pending_task` is checked before intent classification
runs, the same way `ConfirmationManager.is_waiting()` is.

## Uncertainty handling

A `TOOL_OPERATION` intent whose payload is a bare pronoun ("it",
"that", "this", "them") is treated as ambiguous unconditionally —
`_check_ambiguous_target` does not attempt to resolve it against
`self._prior_target` the way question-answering does, because
resolving "open it" to "open <whatever topic was last discussed>"
isn't a safe guess (opening an application named after a conversation
topic rarely makes sense), whereas resolving "explain it" to "explain
<topic>" does. JARVIS asks "What would you like me to open?" instead.

## Calculator hardening

```
expression string
        |
        v
  len(expression) > MAX_EXPRESSION_LENGTH (300)?  --yes--> reject, no parse attempt
        |no
        v
  ast.parse(expression, mode="eval")  -> SyntaxError -> reject cleanly
        |
        v
  walk the AST (_eval_node), tracking depth and an _OperationBudget:
        |
        +-- depth > MAX_NESTING_DEPTH (150)?          --yes--> reject
        +-- budget.operations > MAX_OPERATIONS (150)? --yes--> reject
        +-- any Constant whose |value| > MAX_INT_LITERAL (1e18)? --yes--> reject
        +-- BinOp is Pow?
        |      |
        |      v
        |   _check_pow_safety(base, exponent):
        |      |exponent| > MAX_EXPONENT (1000)?         --yes--> reject
        |      estimate result bits = |exponent| * log2(|base|)
        |      estimate > MAX_RESULT_BITS (4096)?         --yes--> reject
        |      (both checks run BEFORE operator.pow() is ever called)
        |
        v
  compute the operation -> _check_result_size(result):
        int result: bit_length() > MAX_RESULT_BITS? --yes--> reject
        float result: not math.isfinite()?           --yes--> reject
        |
        v
  final result
```

Every limit is deliberately calibrated against *realistic* use, not
just against attacks — the first hardening attempt set
`MAX_NESTING_DEPTH=30`, which turned out to reject a perfectly
ordinary 99-term addition chain (`1+1+1+...`), because Python's
left-associative parsing makes such a chain deeply *nested* in AST
terms even though it's computationally trivial. The limits now in
`tools/calculator.py` were re-tuned so `tests/test_calculator_hardening.py`'s
`TestNormalEngineeringCalculations` class passes alongside every
attack-case test — hardening that breaks ordinary use isn't
successful hardening.

`run()` (the function actually registered as the `calculator` tool)
additionally catches `RecursionError` as a last-resort backstop, even
though `MAX_NESTING_DEPTH` should always catch a pathological AST
first — a crafted expression must never be able to crash JARVIS via
Python's own recursion limit.

## Model output safety

```
  (rule-based match, OR completed multi-turn task, OR — in principle —
   an AI provider proposing a tool call)
        |
        v
  ToolRequest(tool_name, arguments, requested_by="rule_based" | "ai")
        |
        v
  validate_tool_request()  <- tools/validator.py
        |
        +-- tool_name not in registry?          -> ok=False, clean error
        +-- missing required arguments?          -> ok=False, clean error
        +-- risk = RiskLevel(tool.risk_level)     (from registration metadata,
        |                                          NEVER from the request)
        +-- needs_confirmation = tool.confirmation_required
        |                        or requires_confirmation(risk, policy)
        v
  JarvisCore._execute_tool_safely()
        |
        +-- validation.ok is False?              -> return error dict, no execution
        +-- validation.needs_confirmation?        -> refuse to execute here (defense
        |                                            in depth — nothing currently
        |                                            routes a confirmation-requiring
        |                                            tool through this method, since
        |                                            dangerous actions are gated at
        |                                            the intent level first)
        v
  ToolExecutor.execute()  -> real function call, exceptions caught
```

`_execute_tool_safely()` is the **only** method in `JarvisCore` that
calls a tool — `handle_calculation` and the multi-turn task completion
path (`_continue_pending_task`) both go through it, and it records
`requested_by` for audit purposes only; that field never changes the
outcome. `tests/test_orchestrator_v1_1.py::TestModelCannotExecuteToolsDirectly`
proves this directly: a hypothetical `CRITICAL`-risk tool registered at
runtime is refused when requested with `requested_by="ai"`, with
exactly the same refusal a rule-based request would get.



- **`core/context.py` (`ContextManager`)** — owns conversation state:
  history, subject/topic tracking, `pending_task`, and
  `previous_intent_type`/`previous_response` for the next turn.
  `build_prompt_context()` assembles a *bounded* bundle (capped
  history, capped memory/knowledge snippets) for any future AI
  provider call — deliberately never sends unlimited history.
- **`core/intent.py` (`classify_intent`)** — pure function, text in,
  `Intent(type, risk_level, payload, raw_text, confidence)` out. No
  side effects, no I/O, no knowledge of AI providers.
- **`core/nlu.py` (`classify_with_fallback`)** — the confidence-gated
  pipeline described above. Depends on `core/intent.py` and
  `providers/base.py` only; owns the one safety-finalization step
  every other consumer of intent classification relies on.
- **`core/memory_policy.py`** — pure functions (`contains_secret`,
  `decide_memory_action`), no I/O. `memory/long_term.py` and
  `core/orchestrator.py` both call `contains_secret` independently
  (defense in depth: explicit remember vs. auto-remember).
- **`core/reasoning.py` (`decide`)** — pure function, duck-typed over
  either `Intent` or `StructuredIntent` (same `{type, risk_level,
  payload, raw_text}` shape), intent in, `Decision` out.
- **`memory/long_term.py` (`LongTermMemory`)** — the only thing
  `JarvisCore` talks to for persistent memory; delegates storage to
  `memory/storage.py` (`MemoryStore`, SQLite, with an automatic
  `_migrate()` step for databases created by an older schema).
- **`knowledge/search.py` (`KnowledgeIndex`)** implements
  `knowledge/interfaces.py`'s `KnowledgeStore`; `knowledge/verification.py`
  (`verify_and_format`) is the separate "is this good enough to answer
  from" gate, used identically whether or not an AI provider then
  reasons over the grounded passage.
- **`tools/registry.py` + `tools/validator.py` + `tools/executor.py`**
  — three separate concerns: what tools exist (`ToolRegistry`), is
  *this* request against *this* tool actually valid and how risky is
  it (`validate_tool_request`), and actually calling the tool's
  function with exceptions caught (`ToolExecutor`).
- **`safety/risk_classifier.py` + `safety/confirmation.py` +
  `safety/permissions.py`** — unchanged in role from Phase 1;
  `core/nlu.py` and `tools/validator.py` are now both consumers.
- **`providers/base.py` (`AIProvider`)** + **`providers/factory.py`**
  — abstract contract + the single dispatch point. `core/orchestrator.py`
  imports `providers.factory.get_provider_from_config`, never a
  concrete provider class.

## Why SQLite over JSON files for memory

Unchanged from Phase 1: SQLite gives atomic writes, real querying, and
an easy migration path (see `MemoryStore._migrate`, which added
`confidence`/`expires_at` columns in Phase 1.1 without requiring a
data export/import step) — all via the standard library.

## Why keyword search instead of embeddings for knowledge

Unchanged from Phase 1: embeddings require a model, which conflicts
with JARVIS's ability to run fully on `ai_provider=local`. Phase 1.1
formalizes the seam (`knowledge/interfaces.py`) without introducing a
vector database dependency, per the brief's explicit instruction not
to "unnecessarily introduce a huge external infrastructure."

## Failure handling

Every failure mode below is covered by `tests/test_failure_modes.py`
and degrades to a clean string response — never an uncaught exception,
a hang, or a crash:

| Failure | Where it's caught | Behavior |
|---|---|---|
| Provider unreachable/down | `ProviderUnavailableError` caught at each call site in `core/orchestrator.py` | `R.provider_unavailable(...)` or falls back to rule-based/deterministic handling |
| Provider times out | `urllib` timeout -> `ProviderUnavailableError` in `providers/ollama.py`/`llamacpp.py` | Same as above — a real timeout, not just connection-refused, is tested against an actual stalling local server |
| Provider returns invalid JSON | `ProviderResponseError` from `AIProvider.generate_json()`, caught in `core/nlu.py` | Falls back to the rule-based classification |
| Provider raises an unexpected exception (a bug in that provider) | Broad `except Exception` in `core/nlu._try_ai_classification` and the top-level handler try/except in `JarvisCore.process()` | Falls back to rule-based classification, or a generic "I ran into a problem" reply — never propagates |
| Knowledge search returns nothing | `verify_and_format([])` -> `grounded=False` | `R.knowledge_unavailable()` or a model-generated (unattributed) answer if a provider is available |
| Tool execution fails | `ToolExecutor.execute()`'s broad `except Exception` | Clean `{"ok": False, "error": ...}` dict, never propagates |
| Tool request invalid/unknown/missing args | `validate_tool_request()` | Clean error dict, execution never attempted |
| Memory backend failure (e.g. disk I/O error) | Top-level handler try/except in `JarvisCore.process()` (there is no memory-specific try/except beyond secret-rejection) | Generic "I ran into a problem" reply |
| Malformed/hostile user input (empty string, 10k+ chars, control characters, emoji/unicode, SQL-injection-style content) | No special-casing needed — every layer treats input as opaque text; SQLite parameterized queries prevent injection | Processed normally or answered with an honest "I don't know" — never a crash |

## Note on provider test methodology

Because this project is developed without live network access to a
real Ollama/llama.cpp instance, `tests/test_providers.py` verifies
provider *code paths* two ways: (1) against deliberately unreachable
addresses (e.g. `http://localhost:1`) for connection-refused handling,
and (2) against real local `http.server.HTTPServer` instances running
in a background thread for actual request/response handling —
successful generation, malformed JSON, non-2xx status, and genuine
timeouts (a handler that accepts the connection and sleeps, forcing
the client to time out rather than fail instantly). This is
meaningfully more real than mocking `urllib` itself, but it is still
not the same as testing against an actual Ollama server with an
actual model loaded — see the README's Known Limitations for what
that means in practice.

## Extension points for future phases

| Phase | What plugs in | Where |
|---|---|---|
| 2 — Voice | STT feeding `JarvisCore.process()`; TTS reading its return value | New `interfaces/voice.py`, no core changes |
| 3 — Vision | New intent type(s) + a vision tool registered in `ToolRegistry` | `tools/vision.py`, `core/intent.py` routing |
| 4 — Satellite/real-world data | New tool(s), risk-classified like any other | `tools/` |
| 5/6 — Image/video generation | New tool(s), likely `MEDIUM`/`HIGH` risk given cost/side effects | `tools/` |
| 7 — Android control | New tool(s), almost certainly `HIGH`/`CRITICAL` risk, confirmation-gated | `tools/`, `safety/risk_classifier.py` patterns |
| 8 — Computer/browser/IoT control | Same as above, with careful `permissions.py` design | `tools/`, `safety/` |
| 9 — Autonomous execution | A new orchestration mode layered *on top of* `JarvisCore.process()`, reusing the same safety gate for every autonomous action | `core/` (new module, not a rewrite) |
| Custom JARVIS model | A new `providers/jarvis_model.py` implementing `AIProvider` | `providers/`, `providers/factory.py` |

The common thread, unchanged since Phase 1: every future capability is
a new tool (or a new intent + tool pair) registered through the
existing `ToolRegistry` and gated through the existing `safety/`
pipeline, or a new `AIProvider` registered through the existing
factory. `core/orchestrator.py` itself should not need structural
rewrites for any of these — Phase 1.1 added an entire NLU/memory
-intelligence/multi-turn/RAG layer without one.
