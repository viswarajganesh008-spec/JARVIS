# Steam Turbines

A steam turbine is a device that extracts thermal energy from
pressurized steam and converts it into rotational mechanical work.
High-pressure steam produced by a boiler is directed through a series
of blades mounted on a rotor. As the steam expands and cools, it
pushes against the blades, causing the rotor to spin.

Most large-scale electricity generation today relies on steam
turbines connected to generators, including in coal, natural gas,
nuclear, and some solar-thermal power plants. Steam turbines are
valued for their high efficiency at large scale and their ability to
run continuously for long periods with proper maintenance.
