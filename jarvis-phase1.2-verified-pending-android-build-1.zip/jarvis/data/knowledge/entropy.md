# Entropy

Entropy is a measure of disorder, randomness, or the number of
possible microscopic arrangements in a system. In thermodynamics, the
second law states that the total entropy of an isolated system tends
to increase over time, meaning natural processes move toward states
of greater disorder unless energy is added from outside.

In information theory, entropy measures the uncertainty or
unpredictability of information content — a message with higher
entropy carries more information because it is less predictable.
