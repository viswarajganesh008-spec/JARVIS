"""
Local-development REST bridge between the Android app and JARVIS Core.

    Android App --HTTP--> this module --.process()--> JarvisCore
                                                            |
                                          existing orchestration/safety

Endpoints
---------
POST   /message
    Request:  {"message": "...", "conversation_id": "..."}
    Response: {"response": "...", "conversation_id": "...", "metadata": {...}}
    conversation_id is optional on the first call - if omitted, a new
    one is generated and returned so the client can reuse it for
    follow-up turns in the same conversation.

GET    /health
    Response: {"status": "ok", "jarvis_name": "...", "active_conversations": N}
    Used by the Android app to show a connection-state indicator
    before the user sends anything.

DELETE /conversation/<conversation_id>
    Discards that conversation's JarvisCore session (context, pending
    task/confirmation state). Response: {"cleared": true|false}.

Design notes (see also ARCHITECTURE.md "Android bridge" section):

- This module is a *transport* layer only. It never classifies intent,
  decides risk, or executes a tool itself - every message is handed
  whole to JarvisCore.process(), the same entry point cli.py uses.
  That is what keeps "every request enters the existing orchestration
  /safety architecture" true by construction rather than by convention.
- No internal tool, file, or shell access is exposed through this API
  - there is no endpoint that takes a tool name or command. The only
  input surface is free-text `message`, exactly like the CLI's stdin.
- Untrusted input boundary: this process assumes anything arriving
  over HTTP is untrusted. Every field is type/length/shape-checked
  before it reaches JarvisCore; malformed input gets a clean 4xx JSON
  error, never a stack trace or an unhandled exception.
- Binds to 127.0.0.1 by default (see run()) - this bridge is meant for
  an Android emulator/device on the same trusted development machine
  (emulator reaches host via 10.0.2.2, a physical device via the LAN
  IP passed explicitly), not for exposure on an untrusted network.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict, Tuple

from flask import Flask, Response, jsonify, request

from config.config import JarvisConfig
from api.sessions import SessionManager

_MAX_MESSAGE_LENGTH = 8000  # generous for typed input; rejects pathological payloads
logger = logging.getLogger("jarvis.api")


def _error(message: str, status: int) -> Tuple[Response, int]:
    return jsonify({"error": message}), status


def _validate_message_payload(body: Any) -> Tuple[str, str, Any]:
    """Validate a decoded JSON request body for POST /message.

    Returns (message, conversation_id, error_response_or_None). On
    failure, message/conversation_id are empty strings and the third
    element is the (response, status) tuple to return as-is.
    """
    if not isinstance(body, dict):
        return "", "", _error("Request body must be a JSON object.", 400)

    message = body.get("message")
    if message is None:
        return "", "", _error("Field 'message' is required.", 400)
    if not isinstance(message, str):
        return "", "", _error("Field 'message' must be a string.", 400)
    if not message.strip():
        return "", "", _error("Field 'message' must not be empty.", 400)
    if len(message) > _MAX_MESSAGE_LENGTH:
        return "", "", _error(
            f"Field 'message' exceeds the {_MAX_MESSAGE_LENGTH}-character limit.", 400
        )

    conversation_id = body.get("conversation_id")
    if conversation_id is None or conversation_id == "":
        conversation_id = str(uuid.uuid4())
    elif not isinstance(conversation_id, str):
        return "", "", _error("Field 'conversation_id' must be a string.", 400)
    elif len(conversation_id) > 128:
        return "", "", _error("Field 'conversation_id' is too long.", 400)

    return message, conversation_id, None


def create_app(config_factory=None) -> Flask:
    """Flask application factory.

    A factory (rather than a module-level app) so tests can create
    an isolated app + SessionManager per test instead of sharing
    process-wide state.
    """
    config_factory = config_factory or JarvisConfig.load
    app = Flask(__name__)
    sessions = SessionManager(config_factory)
    app.config["JARVIS_SESSIONS"] = sessions

    @app.errorhandler(404)
    def _not_found(_e):
        return _error("Not found.", 404)

    @app.errorhandler(405)
    def _method_not_allowed(_e):
        return _error("Method not allowed.", 405)

    @app.errorhandler(Exception)
    def _unhandled(e):
        # A single bad request must never crash the bridge or leak an
        # internal stack trace to the client - the Android app only
        # ever sees a clean JSON error it can render.
        logger.exception("unhandled_error")
        return _error("Internal server error.", 500)

    @app.get("/health")
    def health():
        try:
            probe_config = config_factory()
            jarvis_name = probe_config.jarvis_name
        except Exception:  # noqa: BLE001 - health check must never itself 500
            jarvis_name = "JARVIS"
        return jsonify({
            "status": "ok",
            "jarvis_name": jarvis_name,
            "active_conversations": sessions.session_count(),
        })

    @app.post("/message")
    def post_message():
        body = request.get_json(silent=True)
        if body is None and request.data:
            return _error("Request body must be valid JSON.", 400)

        message, conversation_id, error = _validate_message_payload(body or {})
        if error is not None:
            return error

        try:
            reply = sessions.process(conversation_id, message)
        except Exception:  # noqa: BLE001 - JarvisCore already catches handler
            # errors internally and returns a message; this is a last
            # -resort net for anything that still escapes (e.g. a
            # session construction failure), never a bare 500 traceback.
            logger.exception("jarvis_process_failed conversation_id=%s", conversation_id)
            return _error("JARVIS Core is unavailable. Please try again.", 503)

        return jsonify({
            "response": reply,
            "conversation_id": conversation_id,
            "metadata": {},
        })

    @app.delete("/conversation/<conversation_id>")
    def delete_conversation(conversation_id: str):
        cleared = sessions.reset(conversation_id)
        return jsonify({"cleared": cleared})

    return app


def run(host: str = "127.0.0.1", port: int = 8765) -> None:
    app = create_app()
    app.run(host=host, port=port, threaded=True)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run()
