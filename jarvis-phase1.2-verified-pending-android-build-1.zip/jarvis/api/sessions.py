"""
Conversation/session routing for the Android bridge.

JarvisCore is intentionally single-session (see safety/confirmation.py
and core/context.py docstrings: "Phase 1 is single-user, single
-session"). Context, pending multi-turn tasks, and pending
confirmations all live *inside* one JarvisCore instance. To let the
Android app hold several independent conversations (and to keep each
conversation's follow-up questions — "explain it simpler" — resolving
against the right prior turn) this module keeps one JarvisCore
instance per conversation_id, rather than trying to make JarvisCore
itself multi-session.

This is a deliberate, documented scoping choice for the local
-development bridge, not a hidden limitation: see ARCHITECTURE.md.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Callable, Dict, Optional

from config.config import JarvisConfig
from core.orchestrator import JarvisCore

# A conversation_id the Android app never sent us before is a normal,
# expected event (first message of a new chat) - not an error. Cap how
# many concurrent conversations we hold in memory so a client that
# generates a fresh conversation_id per message can't leak memory
# forever during local development.
_MAX_SESSIONS = 200


@dataclass
class _Session:
    core: JarvisCore
    lock: threading.Lock
    last_used: float


class SessionManager:
    """Creates and reuses one JarvisCore per conversation_id.

    Thread-safe: a per-session lock serializes calls to that
    conversation's JarvisCore.process() (JarvisCore holds mutable
    turn-by-turn state - e.g. a pending confirmation - that must not
    be touched by two requests concurrently), while different
    conversations can run concurrently.
    """

    def __init__(self, config_factory: Callable[[], JarvisConfig]):
        self._config_factory = config_factory
        self._sessions: Dict[str, _Session] = {}
        self._directory_lock = threading.Lock()

    def _create_session(self) -> _Session:
        core = JarvisCore(self._config_factory())
        return _Session(core=core, lock=threading.Lock(), last_used=time.time())

    def _evict_oldest_if_needed_locked(self) -> None:
        if len(self._sessions) < _MAX_SESSIONS:
            return
        oldest_id = min(self._sessions, key=lambda k: self._sessions[k].last_used)
        stale = self._sessions.pop(oldest_id)
        stale.core.close()

    def get_or_create(self, conversation_id: str) -> _Session:
        with self._directory_lock:
            session = self._sessions.get(conversation_id)
            if session is None:
                self._evict_oldest_if_needed_locked()
                session = self._create_session()
                self._sessions[conversation_id] = session
            session.last_used = time.time()
            return session

    def process(self, conversation_id: str, message: str) -> str:
        """Route one message through that conversation's JarvisCore.

        This is the *only* thing the API layer calls into the core
        with - the same JarvisCore.process(text) -> str entry point
        the CLI uses. No tool, memory, or safety logic is duplicated
        or bypassed here.
        """
        session = self.get_or_create(conversation_id)
        with session.lock:
            return session.core.process(message)

    def session_count(self) -> int:
        with self._directory_lock:
            return len(self._sessions)

    def close_all(self) -> None:
        with self._directory_lock:
            for session in self._sessions.values():
                session.core.close()
            self._sessions.clear()

    def reset(self, conversation_id: str) -> bool:
        """Discard one conversation's state (used by DELETE /conversation/<id>)."""
        with self._directory_lock:
            session = self._sessions.pop(conversation_id, None)
        if session is None:
            return False
        session.core.close()
        return True
