"""
JARVIS Core — Android development bridge (REST API).

This package exposes the existing JarvisCore orchestrator over HTTP so
the Android application (or any other client) can talk to it during
local development, without JARVIS Core needing to know anything about
Android.

Nothing in here re-implements or bypasses orchestration: every request
is handed to ``JarvisCore.process()`` exactly as the CLI (``cli.py``)
does. This module only adds transport (HTTP in, JSON out), per
-conversation session routing, and input validation at the boundary.
See ARCHITECTURE.md's "Android bridge" section for the full request
lifecycle and the reasoning behind the design choices below.
"""
