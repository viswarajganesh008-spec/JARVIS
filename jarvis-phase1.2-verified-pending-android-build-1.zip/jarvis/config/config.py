"""
Configuration system for JARVIS Core.

Centralizes all tunable settings so nothing is hard-coded throughout
the project. Precedence, low to high:

    dataclass defaults  ->  JSON config file  ->  environment variables

Environment variables let you switch provider/model without touching
source or the JSON file — see `.env.example` for the full list.
Call `save()` to persist any runtime changes back to disk.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, Optional

DEFAULT_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "jarvis_config.json"
)

# Maps env var name -> (config field name, type caster)
_ENV_OVERRIDES = {
    "JARVIS_NAME": ("jarvis_name", str),
    "USER_NAME": ("user_name", str),
    "MEMORY_ENABLED": ("memory_enabled", lambda v: v.strip().lower() not in ("0", "false", "no")),
    "MEMORY_DB_PATH": ("memory_db_path", str),
    "KNOWLEDGE_DIRECTORY": ("knowledge_directory", str),
    "KNOWLEDGE_INDEX_PATH": ("knowledge_index_path", str),
    "CONFIRMATION_POLICY": ("confirmation_policy", str),
    "MAX_CONTEXT_MESSAGES": ("max_context_messages", int),
    "AI_PROVIDER": ("ai_provider", str),
    "AI_MODEL": ("ai_model", str),
    "AI_BASE_URL": ("ai_base_url", str),
    "AI_TEMPERATURE": ("ai_temperature", float),
    "AI_MAX_TOKENS": ("ai_max_tokens", int),
    "AI_CONTEXT_LENGTH": ("ai_context_length", int),
    "AI_REQUEST_TIMEOUT": ("ai_request_timeout", float),
    "NLU_CONFIDENCE_THRESHOLD": ("nlu_confidence_threshold", float),
    "LOGGING_LEVEL": ("logging_level", str),
    "LOG_FILE": ("log_file", str),
}


@dataclass
class JarvisConfig:
    jarvis_name: str = "JARVIS"
    user_name: str = "User"

    memory_enabled: bool = True
    memory_db_path: str = "data/memory.db"

    knowledge_directory: str = "data/knowledge"
    knowledge_index_path: str = "data/knowledge_index.json"

    # "always", "risky_only", "never" — governs whether MEDIUM-risk
    # actions require confirmation. HIGH and CRITICAL always require it,
    # regardless of policy, and regardless of what any AI provider claims.
    confirmation_policy: str = "risky_only"

    max_context_messages: int = 20

    # --- AI provider settings ---
    # ai_provider: "local" (no-op placeholder, always available, never
    # generates), "ollama" (local Ollama server), "llamacpp" (local
    # llama.cpp server / any OpenAI-completion-compatible local endpoint).
    ai_provider: str = "local"
    ai_model: str = ""
    ai_base_url: str = "http://localhost:11434"
    ai_temperature: float = 0.7
    ai_max_tokens: int = 512
    ai_context_length: int = 4096
    ai_request_timeout: float = 10.0

    # Below this rule-based classification confidence, the NLU fallback
    # (an AI provider, if available) is consulted for intent classification.
    # Its output is NEVER trusted for risk/confirmation — see core/nlu.py.
    nlu_confidence_threshold: float = 0.55

    logging_level: str = "INFO"
    log_file: str = "data/jarvis.log"

    extra: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def load(cls, path: str = DEFAULT_CONFIG_PATH,
              env: Optional[Dict[str, str]] = None) -> "JarvisConfig":
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                known = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
                extra = {k: v for k, v in data.items() if k not in cls.__dataclass_fields__}
                cfg = cls(**known)
                cfg.extra.update(extra)
            except (json.JSONDecodeError, TypeError, ValueError):
                # Corrupt config file: fall back to defaults rather than crash.
                cfg = cls()
        else:
            cfg = cls()

        cfg._apply_env_overrides(env if env is not None else os.environ)
        return cfg

    def _apply_env_overrides(self, env: Dict[str, str]) -> None:
        for env_key, (field_name, caster) in _ENV_OVERRIDES.items():
            if env_key in env and env[env_key] != "":
                try:
                    setattr(self, field_name, caster(env[env_key]))
                except (ValueError, TypeError):
                    # Never let a malformed env var crash startup.
                    continue

    def save(self, path: str = DEFAULT_CONFIG_PATH) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, indent=2)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)
