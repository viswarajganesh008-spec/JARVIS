"""
OllamaProvider — a real local model backend using an Ollama server
(https://ollama.com), which runs open-weight models (Llama, Mistral,
Qwen, etc.) fully locally with no cloud API involved.

Uses only the standard library (urllib) so JARVIS has zero mandatory
third-party dependencies even for a "real" provider. If `requests` is
available it doesn't matter either way — this never needs it.

This provider does NOT assume the model or server is installed or
running. `is_available()` performs a short, cheap health check and
returns False cleanly on any connection error, timeout, or non-2xx
response; every generation method raises `ProviderUnavailableError`
with a clear, actionable message rather than hanging or crashing
JARVIS Core.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Dict, List

from .base import AIProvider, ProviderUnavailableError


class OllamaProvider(AIProvider):
    name = "ollama"

    def __init__(self, model: str = "", base_url: str = "http://localhost:11434",
                 temperature: float = 0.7, max_tokens: int = 512,
                 request_timeout: float = 10.0, **_ignored: Any):
        if not model:
            raise ValueError(
                "OllamaProvider requires a model name (set AI_MODEL, e.g. "
                "'llama3.2' or 'qwen2.5:7b')."
            )
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = request_timeout

    # ------------------------------------------------------------------ #
    def is_available(self) -> bool:
        try:
            req = urllib.request.Request(f"{self.base_url}/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=min(self.timeout, 3.0)) as resp:
                return 200 <= resp.status < 300
        except Exception:  # noqa: BLE001 - any failure means "not available"
            return False

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}{path}", data=data, method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = resp.read().decode("utf-8", errors="replace")
        except urllib.error.URLError as e:
            raise ProviderUnavailableError(
                f"Could not reach Ollama at {self.base_url} (model '{self.model}'): {e}. "
                f"Is 'ollama serve' running and has 'ollama pull {self.model}' been run?"
            ) from e
        except TimeoutError as e:
            raise ProviderUnavailableError(
                f"Ollama request to {self.base_url} timed out after {self.timeout}s."
            ) from e
        try:
            return json.loads(body)
        except (ValueError, TypeError) as e:
            raise ProviderUnavailableError(
                f"Ollama returned a non-JSON response: {e}"
            ) from e

    # ------------------------------------------------------------------ #
    def generate(self, prompt: str, **kwargs: Any) -> str:
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": kwargs.get("temperature", self.temperature),
                "num_predict": kwargs.get("max_tokens", self.max_tokens),
            },
        }
        system = kwargs.get("system")
        if system:
            payload["system"] = system
        result = self._post("/api/generate", payload)
        return result.get("response", "")

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> str:
        system = kwargs.get("system")
        if system and not (messages and messages[0].get("role") == "system"):
            messages = [{"role": "system", "content": system}] + list(messages)
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": kwargs.get("temperature", self.temperature),
                "num_predict": kwargs.get("max_tokens", self.max_tokens),
            },
        }
        result = self._post("/api/chat", payload)
        return result.get("message", {}).get("content", "")

    def summarize(self, text: str, **kwargs: Any) -> str:
        prompt = f"Summarize the following text concisely:\n\n{text}\n\nSummary:"
        return self.generate(prompt, **kwargs)

    def classify(self, text: str, labels: List[str], **kwargs: Any) -> str:
        label_list = ", ".join(labels)
        prompt = (
            f"Classify the following message into exactly one of these labels: "
            f"{label_list}.\nRespond with only the label, nothing else.\n\n"
            f"Message: {text}\nLabel:"
        )
        result = self.generate(prompt, **kwargs).strip()
        # Guard against the model inventing a label that wasn't offered.
        for label in labels:
            if label.lower() in result.lower():
                return label
        return labels[0] if labels else result
