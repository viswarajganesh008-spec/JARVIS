"""
AIProvider factory.

The single place that maps a provider name (from config or an
explicit call) to a concrete class. `core/orchestrator.py` never
imports a concrete provider — only this factory and the abstract
`AIProvider` type — so adding a new backend never touches core code.

If the requested provider fails to *construct* (e.g. Ollama selected
with no AI_MODEL configured), that is a configuration error and is
raised immediately and clearly. If a provider constructs fine but its
server later turns out to be unreachable, that is a runtime
availability concern handled by `is_available()` /
`ProviderUnavailableError`, not a factory-time failure.
"""

from __future__ import annotations

from typing import Any

from .base import AIProvider

_PROVIDERS = {
    "local": "providers.local.LocalAIProvider",
    "ollama": "providers.ollama.OllamaProvider",
    "llamacpp": "providers.llamacpp.LlamaCppProvider",
}


class UnknownProviderError(ValueError):
    pass


def _import_class(dotted_path: str):
    module_path, class_name = dotted_path.rsplit(".", 1)
    module = __import__(module_path, fromlist=[class_name])
    return getattr(module, class_name)


def get_provider(name: str = "local", **kwargs: Any) -> AIProvider:
    """Construct the named AI provider.

    kwargs are passed straight through to the provider's constructor —
    typically `model`, `base_url`, `temperature`, `max_tokens`,
    `request_timeout` (unused kwargs are accepted and ignored by each
    provider's `**_ignored`, so callers can pass one shared kwargs dict).
    """
    key = (name or "local").strip().lower()
    if key not in _PROVIDERS:
        raise UnknownProviderError(
            f"Unknown AI provider '{name}'. Available providers: "
            f"{', '.join(sorted(_PROVIDERS))}."
        )
    cls = _import_class(_PROVIDERS[key])
    return cls(**kwargs)


def get_provider_from_config(config) -> AIProvider:
    """Build a provider directly from a JarvisConfig instance."""
    return get_provider(
        config.ai_provider,
        model=config.ai_model,
        base_url=config.ai_base_url,
        temperature=config.ai_temperature,
        max_tokens=config.ai_max_tokens,
        request_timeout=config.ai_request_timeout,
    )
