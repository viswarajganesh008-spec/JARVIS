"""
LlamaCppProvider — a real local model backend for a running
`llama-server` (llama.cpp's built-in HTTP server) or any other local
endpoint that speaks its `/completion` API. Like OllamaProvider, this
uses only the standard library and treats an unreachable server as a
clean, catchable condition rather than a crash.

Start a compatible server with, e.g.:
    llama-server -m model.gguf --port 8080

Then set:
    AI_PROVIDER=llamacpp
    AI_BASE_URL=http://localhost:8080
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Dict, List

from .base import AIProvider, ProviderUnavailableError


class LlamaCppProvider(AIProvider):
    name = "llamacpp"

    def __init__(self, model: str = "", base_url: str = "http://localhost:8080",
                 temperature: float = 0.7, max_tokens: int = 512,
                 request_timeout: float = 10.0, **_ignored: Any):
        # model is optional here — llama.cpp servers are usually started
        # with exactly one model already loaded — but kept for logging/API
        # symmetry with OllamaProvider, which can host several models.
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = request_timeout

    def is_available(self) -> bool:
        try:
            req = urllib.request.Request(f"{self.base_url}/health", method="GET")
            with urllib.request.urlopen(req, timeout=min(self.timeout, 3.0)) as resp:
                return 200 <= resp.status < 300
        except Exception:  # noqa: BLE001
            return False

    def _post(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}{path}", data=data, method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = resp.read().decode("utf-8", errors="replace")
        except urllib.error.URLError as e:
            raise ProviderUnavailableError(
                f"Could not reach the llama.cpp server at {self.base_url}: {e}. "
                f"Is 'llama-server' running with a model loaded?"
            ) from e
        except TimeoutError as e:
            raise ProviderUnavailableError(
                f"llama.cpp server request to {self.base_url} timed out after "
                f"{self.timeout}s."
            ) from e
        try:
            return json.loads(body)
        except (ValueError, TypeError) as e:
            raise ProviderUnavailableError(
                f"llama.cpp server returned a non-JSON response: {e}"
            ) from e

    def generate(self, prompt: str, **kwargs: Any) -> str:
        system = kwargs.get("system")
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        payload = {
            "prompt": full_prompt,
            "temperature": kwargs.get("temperature", self.temperature),
            "n_predict": kwargs.get("max_tokens", self.max_tokens),
        }
        result = self._post("/completion", payload)
        return result.get("content", "")

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> str:
        # Flatten to a simple prompt — llama.cpp's /completion endpoint is
        # not inherently chat-structured the way Ollama's /api/chat is.
        system = kwargs.pop("system", None)
        prompt_parts = []
        if system and not (messages and messages[0].get("role") == "system"):
            prompt_parts.append(f"system: {system}")
        prompt_parts.extend(f"{m.get('role', 'user')}: {m.get('content', '')}" for m in messages)
        prompt_parts.append("assistant:")
        return self.generate("\n".join(prompt_parts), **kwargs)

    def summarize(self, text: str, **kwargs: Any) -> str:
        prompt = f"Summarize the following text concisely:\n\n{text}\n\nSummary:"
        return self.generate(prompt, **kwargs)

    def classify(self, text: str, labels: List[str], **kwargs: Any) -> str:
        label_list = ", ".join(labels)
        prompt = (
            f"Classify the following message into exactly one of these labels: "
            f"{label_list}.\nRespond with only the label, nothing else.\n\n"
            f"Message: {text}\nLabel:"
        )
        result = self.generate(prompt, **kwargs).strip()
        for label in labels:
            if label.lower() in result.lower():
                return label
        return labels[0] if labels else result
