"""
LocalAIProvider — the safe, always-available "no model" placeholder.

Phase 1 shipped with NO model plugged in on purpose: JARVIS Core must
run fully without any AI provider, using its rule-based intent
engine, keyword knowledge search, and safe calculator. This class is
what `ai_provider = "local"` selects — it is honest about being
unavailable rather than pretending to generate text.

Phase 1.1 adds real network-backed providers (see providers/ollama.py
and providers/llamacpp.py) selected via the same factory
(providers/factory.py) so JARVIS can use an actual local/open-weight
model without any change to core/orchestrator.py.
"""

from __future__ import annotations

from typing import Any, Dict, List

from .base import AIProvider, ProviderUnavailableError

# Kept as an alias for backward compatibility with anything importing
# providers.local.ProviderUnavailableError directly — the canonical
# definition now lives in providers/base.py so every provider shares it.
__all__ = ["LocalAIProvider", "ProviderUnavailableError", "get_provider"]


class LocalAIProvider(AIProvider):
    name = "local"

    def __init__(self, model_path: str = None, **_ignored: Any):
        self.model_path = model_path
        self._loaded = False  # would become True once a real model is wired in

    def is_available(self) -> bool:
        return self._loaded

    def _unavailable(self):
        raise ProviderUnavailableError(
            "No AI provider is connected (ai_provider='local'). JARVIS Core "
            "operates using its rule-based reasoning, knowledge search, and "
            "tools. Set AI_PROVIDER=ollama or AI_PROVIDER=llamacpp (plus "
            "AI_MODEL/AI_BASE_URL) to connect a real local model."
        )

    def generate(self, prompt: str, **kwargs: Any) -> str:
        self._unavailable()

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> str:
        self._unavailable()

    def summarize(self, text: str, **kwargs: Any) -> str:
        self._unavailable()

    def classify(self, text: str, labels: List[str], **kwargs: Any) -> str:
        self._unavailable()


def get_provider(name: str = "local", **kwargs) -> AIProvider:
    """Backward-compatible shim — delegates to the real factory.

    New code should import `providers.factory.get_provider` directly;
    this remains so any existing import of `providers.local.get_provider`
    keeps working unchanged.
    """
    from .factory import get_provider as _factory_get_provider
    return _factory_get_provider(name, **kwargs)
