"""
AIProvider abstraction.

JARVIS Core must never depend on a single commercial AI vendor. Any
model — local, open-weight, cloud, or several at once — plugs into
the reasoning layer by implementing this interface. Nothing in
core/, memory/, knowledge/, tools/, or safety/ imports a specific
provider directly; they only depend on this abstract class.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class ProviderUnavailableError(Exception):
    """Raised when a provider method is called but the backend (local model,
    Ollama server, llama.cpp server, ...) is not actually reachable/loaded.

    This is a normal, expected condition — callers (JarvisCore) catch it
    and fall back to deterministic handling rather than crashing.
    """


class ProviderResponseError(Exception):
    """Raised when a provider returned a response JARVIS could not use
    (malformed JSON where JSON was required, empty response, etc.).
    """


class AIProvider(ABC):
    """Common interface every model backend must implement."""

    name: str = "base"

    @abstractmethod
    def generate(self, prompt: str, **kwargs: Any) -> str:
        """Free-form text generation from a single prompt."""
        raise NotImplementedError

    @abstractmethod
    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> str:
        """Multi-turn chat given a list of {"role", "content"} messages."""
        raise NotImplementedError

    @abstractmethod
    def summarize(self, text: str, **kwargs: Any) -> str:
        """Condense text into a shorter summary."""
        raise NotImplementedError

    @abstractmethod
    def classify(self, text: str, labels: List[str], **kwargs: Any) -> str:
        """Return the best-matching label for `text` from `labels`."""
        raise NotImplementedError

    def is_available(self) -> bool:
        """Whether this provider is currently usable (model loaded, API reachable, etc.).

        Must be cheap and must never raise — implementations should catch
        their own connection/timeout errors and return False.
        """
        return True

    def generate_json(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        """Convenience wrapper: call generate() and parse the result as JSON.

        Raises ProviderResponseError on anything that isn't valid JSON, so
        callers (e.g. the NLU fallback classifier) can catch exactly one
        exception type instead of hand-rolling json.loads everywhere. This
        never raises anything the caller could accidentally treat as a
        successful result — callers must always be ready to fall back.
        """
        import json as _json
        raw = self.generate(prompt, **kwargs)
        text = (raw or "").strip()
        # Models often wrap JSON in prose or code fences — try to salvage
        # just the {...} span rather than failing outright.
        if not text.startswith("{"):
            start = text.find("{")
            end = text.rfind("}")
            if start != -1 and end != -1 and end > start:
                text = text[start:end + 1]
        try:
            return _json.loads(text)
        except (ValueError, TypeError) as e:
            raise ProviderResponseError(f"Provider did not return valid JSON: {e}")
