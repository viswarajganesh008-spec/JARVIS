# JARVIS Android — Architecture & Development Setup

This document explains how the Android application connects to the
existing JARVIS Core, how to run both during development, and what is
(and isn't) built yet. It complements the root `ARCHITECTURE.md`,
which still describes JARVIS Core itself — nothing about the core's
own architecture has changed.

## 1. High-level architecture

```
Android App (Kotlin, Jetpack Compose)
      |  JarvisClient (HTTP, JSON)
      v
api/server.py  (Flask - local dev bridge, this repo)
      |  JarvisCore.process(text) -> str   [same call cli.py makes]
      v
Existing JARVIS Core
  (context, memory, intent, knowledge, tools, safety, providers)
      |
      v
Response  ->  back up the same path
```

The Android app **never** talks to Python directly and never invokes
a tool by name. It sends free-text messages, exactly like typing into
`cli.py`. Every request goes through the full orchestrator — intent
classification, risk classification, confirmation flow, tool
validation — before anything happens. There is no separate "fast path"
or "trusted API caller" shortcut.

## 2. Why one JarvisCore per conversation

`JarvisCore` was built as a single-session object: its context,
pending multi-turn task, and pending confirmation all live as instance
state (see `core/context.py` and `safety/confirmation.py` docstrings).
So that the Android app can hold multiple independent conversations
without one conversation's pending confirmation leaking into another,
`api/sessions.py` keeps one `JarvisCore` instance per
`conversation_id`, created lazily on first use and capped at 200
concurrent sessions (oldest evicted first) so a client that mints a
fresh id per message can't leak memory indefinitely during dev.

This is a bridge-level design choice, not a change to JarvisCore
itself — `JarvisCore` is used completely unmodified.

## 3. Running JARVIS Core + the dev bridge

From the repository's `jarvis/` directory:

```bash
pip install -r requirements.txt   # installs Flask, the one new dependency
python run_api.py                 # starts the bridge on http://127.0.0.1:8765
```

The existing CLI (`python cli.py`) still works exactly as before and
is unaffected — the bridge is an additional entry point, not a
replacement.

Check it's up:

```bash
curl http://127.0.0.1:8765/health
```

## 4. Connecting the Android app

- **Android emulator**: no setup needed. The emulator reaches the host
  machine's `127.0.0.1` via the special address `10.0.2.2`, which is
  the default baked into `BuildConfig.JARVIS_CORE_BASE_URL`
  (`app/build.gradle.kts`).
- **Physical device on the same Wi-Fi**: start the bridge bound to all
  interfaces, `JARVIS_API_HOST=0.0.0.0 python run_api.py`, then change
  `JARVIS_CORE_BASE_URL` in `app/build.gradle.kts` to
  `http://<your-machine's-LAN-IP>:8765`.

Open `android/` as a project root in Android Studio (Hedgehog or
newer). It should sync and build without additional configuration
beyond a normal Android SDK install.

**Gradle wrapper note:** this repository includes
`gradle/wrapper/gradle-wrapper.properties` (pinned to Gradle 8.7) but
not the wrapper jar/scripts (`gradlew`, `gradlew.bat`,
`gradle-wrapper.jar`), since generating those requires running Gradle
once. The first time you open the project, either let Android Studio
regenerate them automatically, or run `gradle wrapper --gradle-version
8.7` from `android/` with any local Gradle install.

## 5. Development vs. production

The dev bridge is **not** a production architecture:

- Plain HTTP, no auth, `usesCleartextTraffic="true"` in the manifest —
  acceptable only because it's scoped to localhost/LAN during
  development.
- One Flask process per developer machine, not designed for multiple
  concurrent real users.
- `run_api.py`'s Flask dev server explicitly warns it isn't a
  production WSGI server.

Before any non-development deployment, this needs: real
authentication/pairing between the app and a specific JARVIS Core
instance, TLS (or a mechanism other than raw cleartext HTTP), a
production WSGI server, and a network security config replacing the
blanket cleartext-traffic allowance. None of that is implemented yet —
this phase intentionally stops at the local-dev bridge.

## 6. Error handling contract

The Android app must handle, without crashing:

| Condition | Where it's handled | Kotlin type |
|---|---|---|
| Core process not running | `JarvisHttpClient` (`IOException`) | `JarvisError.CoreUnavailable` |
| Network unreachable | `JarvisHttpClient` | `JarvisError.NetworkFailure` |
| Request/response timeout | `JarvisHttpClient` (`SocketTimeoutException`) | `JarvisError.Timeout` |
| Non-2xx from bridge | `JarvisHttpClient` | `JarvisError.ServerError` |
| Body isn't valid JSON | `JarvisHttpClient` | `JarvisError.MalformedResponse` |
| Empty/blank response text | `JarvisHttpClient` | `JarvisError.EmptyResponse` |
| Malformed/empty request from app | `api/server.py` validation | HTTP 400 with `{"error": "..."}` |

`ChatViewModel` never lets an exception escape `sendMessage()` — every
outcome becomes either a normal JARVIS reply or an error-flagged
`ChatMessage`, rendered inline in the conversation with a specific,
readable message (see `ChatScreen.kt`'s `MessageBubble`).

## 7. Future extension points (not implemented yet)

Interfaces are structured so these can be added without reshaping what
exists:

- **Voice**: `JarvisClient` takes and returns plain text; a future
  speech-to-text/text-to-speech layer would sit entirely on the
  Android side, feeding `sendMessage()` the transcribed text — no
  change needed to the interface or to JARVIS Core.
- **Vision**: would need a new bridge endpoint (e.g. `POST
  /message/with-image`) and a corresponding `JarvisClient` method;
  intentionally not added until there's a real vision subsystem behind
  it in Core.
- **Device control / Blender / 3D**: same pattern — a new tool
  registered in `tools/` on the Core side, exposed to the model
  through the existing tool-registry/validator/safety path. The
  Android app would never call such a tool directly; it would just ask
  in natural language, same as everything else.

## 8. What this phase deliberately does not include

Per the phase objectives: wake word, always-listening mic, speaker
authentication, camera intelligence, Blender/3D/image/video
generation, autonomous device control, and any advanced personality
system. The architecture above is shaped to make adding these easier
later, but none of them exist yet.
