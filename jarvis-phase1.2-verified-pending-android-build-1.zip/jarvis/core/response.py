"""
Response engine.

Centralizes JARVIS's phrasing so it never sounds robotic ("COMMAND
RECEIVED") and so it's trivial to swap in an AIProvider-generated,
more natural phrasing later — callers just ask for a named template
and pass data; nothing about *how* a response is worded is scattered
through the reasoning code.
"""

from __future__ import annotations

from typing import Optional


def calculation_result(expression: str, result) -> str:
    return f"Sure — {expression.strip()} = {result}"


def calculation_error(expression: str, error: str) -> str:
    return f"I couldn't calculate that ({error}). Could you rephrase the expression?"


def memory_saved(content: str) -> str:
    return f"Got it, I'll remember that {content}."


def memory_not_found(query: str) -> str:
    return f"I don't have anything remembered about \"{query}\"."


def memory_list(items) -> str:
    if not items:
        return "I don't have anything stored in long-term memory yet."
    lines = [f"- {m.content}" for m in items]
    return "Here's what I remember:\n" + "\n".join(lines)

def memory_retrieved(items) -> str:
    if not items:
        return "I don't have anything remembered about that."
    if len(items) == 1:
        return f"You mentioned: {items[0].content}"
    lines = [f"- {m.content}" for m in items]
    return "Here's what I remember related to that:\n" + "\n".join(lines)


def memory_forgotten(count: int, query: str) -> str:
    if count == 0:
        return f"I didn't find anything matching \"{query}\" to forget."
    return f"Done — I've forgotten {count} thing(s) matching \"{query}\"."


def knowledge_answer(source_doc: str, chunk_text: str) -> str:
    return f"According to {source_doc}: {chunk_text}"


def knowledge_unavailable() -> str:
    return "I don't currently have enough information to answer that reliably, so I don't want to guess."


def confirmation_prompt(prompt_text: str) -> str:
    return prompt_text


def confirmation_ambiguous() -> str:
    return "Please confirm explicitly: yes or no."


def action_executed(description: str) -> str:
    return f"Done. {description}"


def action_cancelled() -> str:
    return "Okay, I've cancelled that."


def tool_not_found(name: str) -> str:
    return f"I don't currently have a tool capable of doing that ({name})."


def tool_failed(name: str, error: str) -> str:
    return f"I couldn't complete that operation ({name}): {error}"


def unknown_command() -> str:
    return "I don't currently have a tool capable of doing that."


def generic_no_ai_provider() -> str:
    return ("I don't have a connected reasoning model for open-ended conversation yet — "
            "I can still calculate, remember things, search my knowledge base, and run tools.")


def provider_unavailable(reason: str) -> str:
    return f"My connected AI provider isn't reachable right now ({reason}). {generic_no_ai_provider()}"


def knowledge_reasoned_answer(source_doc: str, reasoned_text: str) -> str:
    """A model-reasoned answer that is still grounded in a retrieved source."""
    return f"Based on {source_doc}: {reasoned_text}"


def clarification_needed(question: str) -> str:
    return question


def ambiguous_reference(what: str = "that") -> str:
    return f"I'm not sure what \"{what}\" refers to — could you say more specifically what you mean?"


def ambiguous_open_target() -> str:
    return "What would you like me to open?"


def task_ask_for_slot(task_description: str, slot_name: str) -> str:
    return f"Sure, I can help with {task_description}. What is the {slot_name}?"


def task_result(task_description: str, result) -> str:
    return f"The {task_description} is approximately {result}."


def task_cancelled() -> str:
    return "Okay, I've cancelled that task."


def memory_rejected(reason: str) -> str:
    return f"I'm not going to remember that — {reason}"
