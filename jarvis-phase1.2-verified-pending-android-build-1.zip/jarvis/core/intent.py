"""
Intent / decision classifier.

Phase 1 has no model in the loop, so intent is determined with
explicit, ordered pattern rules. This is transparent and testable —
you can always say exactly why a command was routed a given way.
An AIProvider-backed classifier can be added later as an additional
signal (e.g. for ambiguous cases) without replacing this contract:
callers just get an Intent back either way.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from safety.risk_classifier import RiskLevel, classify_risk


class IntentType(str, Enum):
    CALCULATION = "CALCULATION"
    MEMORY_REMEMBER = "MEMORY_REMEMBER"
    MEMORY_RETRIEVE = "MEMORY_RETRIEVE"
    MEMORY_LIST = "MEMORY_LIST"
    MEMORY_FORGET = "MEMORY_FORGET"
    KNOWLEDGE_QUERY = "KNOWLEDGE_QUERY"
    TOOL_OPERATION = "TOOL_OPERATION"
    DANGEROUS_OPERATION = "DANGEROUS_OPERATION"
    CONVERSATION = "CONVERSATION"
    QUESTION = "QUESTION"
    UNKNOWN = "UNKNOWN"


@dataclass
class Intent:
    type: IntentType
    risk_level: RiskLevel
    payload: str  # the relevant slice of text for the handler (e.g. the math expression)
    raw_text: str
    # Rule-based classification confidence in [0, 1]. High (>=0.85) for an
    # explicit pattern match (a calculation, "remember that...", a clear
    # dangerous-action phrase). Lower for the catch-all QUESTION/CONVERSATION
    # branches, which is exactly the signal core/nlu.py uses to decide
    # whether to consult an AI provider as a fallback classifier.
    confidence: float = 1.0


_CALC_RE = re.compile(
    r"^(calculate|compute|what'?s|what is|solve)?\s*[\d\.\(\)\s\+\-\*/%\^]+$"
)
_CALC_TRIGGER_RE = re.compile(r"\b(calculate|compute)\b", re.IGNORECASE)
_MATH_CHARS_RE = re.compile(r"^[\d\.\s\+\-\*/%\^\(\)]+$")

_REMEMBER_RE = re.compile(r"^\s*remember (that )?(.+)$", re.IGNORECASE)
_RETRIEVE_RE = re.compile(r"^\s*(what do you remember|do you remember|recall)\b(.*)$",
                           re.IGNORECASE)
_LIST_RE = re.compile(r"^\s*(list|show) (my )?memories\b", re.IGNORECASE)
_FORGET_RE = re.compile(r"^\s*forget (that )?(.+)$", re.IGNORECASE)

_KNOWLEDGE_RE = re.compile(r"^\s*(search knowledge|explain|what is|tell me about)\s+(.+)$",
                            re.IGNORECASE)

_TOOL_OPEN_RE = re.compile(r"^\s*open\s+(.+)$", re.IGNORECASE)

_QUESTION_WORDS = ("who", "what", "when", "where", "why", "how", "is", "does", "did", "can")


def _strip_trailing_terminator(s: str) -> str:
    """Strip one trailing sentence-ending punctuation mark (. ! ?).

    Response templates embed payloads mid-sentence (e.g. "Sure — {expr} =
    {result}", "This action could {description}. Do you want..."); without
    this, "calculate 25 * 16." or "delete all files." leaves a stray
    trailing/doubled punctuation mark in the reply.
    """
    return s.rstrip(".!?").strip()


def classify_intent(text: str) -> Intent:
    stripped = text.strip()
    lowered = stripped.lower()

    # 1. Explicit calculation trigger, or text that is essentially pure arithmetic.
    if _CALC_TRIGGER_RE.search(lowered):
        expr = re.sub(r"\b(calculate|compute)\b", "", lowered, flags=re.IGNORECASE).strip()
        expr = _strip_trailing_terminator(expr)
        expr = expr.replace("^", "**").replace("x", "*") if _looks_mathy(expr) else expr
        return Intent(IntentType.CALCULATION, RiskLevel.LOW, expr, text, confidence=0.95)

    bare_expr = _strip_trailing_terminator(lowered.replace("x", "*"))
    if _MATH_CHARS_RE.match(bare_expr) and any(c.isdigit() for c in bare_expr):
        return Intent(IntentType.CALCULATION, RiskLevel.LOW, bare_expr.replace("^", "**"), text, confidence=0.9)

    # 2. Memory operations.
    m = _FORGET_RE.match(stripped)
    if m:
        return Intent(IntentType.MEMORY_FORGET, RiskLevel.LOW, m.group(2).strip(), text, confidence=0.9)

    if _LIST_RE.match(stripped):
        return Intent(IntentType.MEMORY_LIST, RiskLevel.LOW, "", text, confidence=0.95)

    m = _RETRIEVE_RE.match(stripped)
    if m:
        retrieve_query = m.group(2).strip().rstrip("?.! ").strip()
        # "about me"/"about myself" is filler, not a search term — treat it
        # the same as no query at all (i.e. "list everything").
        if retrieve_query.lower() in ("about me", "about myself", "about you", ""):
            retrieve_query = ""
        return Intent(IntentType.MEMORY_RETRIEVE, RiskLevel.LOW, retrieve_query, text, confidence=0.9)

    m = _REMEMBER_RE.match(stripped)
    if m:
        # Strip a single trailing sentence-ending punctuation mark so the
        # response template ("Got it, I'll remember that {content}.") never
        # ends up with a stray double period.
        content = m.group(2).strip().rstrip(".").strip()
        return Intent(IntentType.MEMORY_REMEMBER, RiskLevel.LOW, content, text, confidence=0.9)

    # 3. Dangerous / risky operations — checked before generic tool/knowledge routing.
    risk = classify_risk(stripped)
    if risk in (RiskLevel.HIGH, RiskLevel.CRITICAL):
        return Intent(IntentType.DANGEROUS_OPERATION, risk, _strip_trailing_terminator(stripped),
                       text, confidence=0.85)

    # 4. Knowledge retrieval.
    m = _KNOWLEDGE_RE.match(stripped)
    if m:
        return Intent(IntentType.KNOWLEDGE_QUERY, RiskLevel.LOW,
                       _strip_trailing_terminator(m.group(2).strip()), text, confidence=0.9)

    # 5. Generic tool operations (e.g. "open calculator").
    m = _TOOL_OPEN_RE.match(stripped)
    if m:
        return Intent(IntentType.TOOL_OPERATION, risk,
                       _strip_trailing_terminator(m.group(1).strip()), text, confidence=0.8)

    # 6. MEDIUM-risk actions not otherwise categorized (send a message, schedule, etc.)
    if risk == RiskLevel.MEDIUM:
        return Intent(IntentType.DANGEROUS_OPERATION, risk, stripped, text, confidence=0.85)

    # 7. Fall back to question vs. plain conversation.
    if lowered.startswith(_QUESTION_WORDS) or stripped.endswith("?"):
        return Intent(IntentType.QUESTION, RiskLevel.LOW, stripped, text, confidence=0.5)

    return Intent(IntentType.CONVERSATION, RiskLevel.LOW, stripped, text, confidence=0.3)


def _looks_mathy(expr: str) -> bool:
    return bool(re.search(r"\d", expr)) and bool(re.search(r"[\+\-\*/\^x]", expr))
