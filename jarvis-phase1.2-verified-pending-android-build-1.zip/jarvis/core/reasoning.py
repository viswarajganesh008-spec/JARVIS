"""
Reasoning / Decision layer.

Sits between Intent classification and execution. Its only job is to
decide *what should happen* for a given intent — which handler
applies, and whether the safety engine needs to gate it — without
itself touching memory, knowledge, or tools. That keeps knowledge
retrieval, reasoning, tools, memory, and execution cleanly separated,
per the architecture requirement.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union

from core.intent import Intent, IntentType
from safety.risk_classifier import RiskLevel, requires_confirmation

# core.nlu.StructuredIntent duck-types the same {type, risk_level, payload,
# raw_text} shape as Intent — accepted here without importing core.nlu, to
# avoid a core.reasoning <-> core.nlu import cycle (nlu doesn't need this
# module, but keeping the dependency one-directional is simpler to reason about).
AnyIntent = Union[Intent, "StructuredIntentLike"]


@dataclass
class Decision:
    handler: str  # name of the handler in JarvisCore to invoke
    needs_confirmation: bool
    risk_level: RiskLevel
    payload: str
    description: str  # human-readable description of the action, for confirmation prompts


_HANDLER_BY_INTENT = {
    IntentType.CALCULATION: "handle_calculation",
    IntentType.MEMORY_REMEMBER: "handle_memory_remember",
    IntentType.MEMORY_RETRIEVE: "handle_memory_retrieve",
    IntentType.MEMORY_LIST: "handle_memory_list",
    IntentType.MEMORY_FORGET: "handle_memory_forget",
    IntentType.KNOWLEDGE_QUERY: "handle_knowledge_query",
    IntentType.TOOL_OPERATION: "handle_tool_operation",
    IntentType.DANGEROUS_OPERATION: "handle_dangerous_operation",
    IntentType.QUESTION: "handle_question",
    IntentType.CONVERSATION: "handle_conversation",
    IntentType.UNKNOWN: "handle_unknown",
}


def decide(intent: AnyIntent, confirmation_policy: str = "risky_only") -> Decision:
    handler = _HANDLER_BY_INTENT.get(intent.type, "handle_unknown")
    needs_confirmation = (
        intent.type == IntentType.DANGEROUS_OPERATION
        and requires_confirmation(intent.risk_level, confirmation_policy)
    )
    description = intent.payload or intent.raw_text
    return Decision(
        handler=handler,
        needs_confirmation=needs_confirmation,
        risk_level=intent.risk_level,
        payload=intent.payload,
        description=description,
    )
