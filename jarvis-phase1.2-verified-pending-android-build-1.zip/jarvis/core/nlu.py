"""
Structured NLU layer.

Pipeline:

    User message
      -> rule-based intent detection (core/intent.py)
      -> if confidence is high enough -> use it directly
      -> if ambiguous -> ask the configured AI provider for a
         structured classification (if one is available)
      -> always produce a StructuredIntent

CRITICAL SAFETY INVARIANT: risk_level and requires_confirmation on the
returned StructuredIntent are ALWAYS computed deterministically from
the raw text by safety/risk_classifier.py — never taken from the AI
provider's output, even when the provider is asked to (and does)
return them. An AI provider claiming "confirmation not needed" for a
delete/factory-reset command is simply ignored; see
`_finalize_safety_fields`. This is what "safety must remain outside
the model" (Phase 1.1 requirement) means in code.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from core.intent import Intent, IntentType, classify_intent
from providers.base import AIProvider, ProviderResponseError, ProviderUnavailableError
from safety.risk_classifier import RiskLevel, classify_risk, requires_confirmation

logger = logging.getLogger("jarvis")

_VALID_INTENT_TYPES = {t.value for t in IntentType}

_CLASSIFIER_PROMPT_TEMPLATE = """You are the intent classifier inside a safety-critical assistant.
Classify the user's message into exactly one of these intent types:
{intent_types}

Respond with ONLY a single JSON object (no prose, no code fences) with this shape:
{{"intent": "<one of the types above>", "confidence": <0.0-1.0>, "entities": [], "action": null, "parameters": {{}}, "payload": "<the relevant text for a handler>"}}

Conversation context (may be empty): {context}
User message: {message}
JSON:"""


@dataclass
class StructuredIntent:
    type: IntentType
    confidence: float
    entities: Dict[str, Any] = field(default_factory=dict)
    parameters: Dict[str, Any] = field(default_factory=dict)
    requested_action: str = ""
    payload: str = ""
    raw_text: str = ""
    risk_level: RiskLevel = RiskLevel.LOW
    requires_confirmation_flag: bool = False
    reasoning_context: Dict[str, Any] = field(default_factory=dict)  # debugging/audit trail
    source: str = "rule_based"  # "rule_based" or "ai_fallback"

    @property
    def needs_confirmation(self) -> bool:
        return self.requires_confirmation_flag


def _from_rule_based(intent: Intent) -> StructuredIntent:
    return StructuredIntent(
        type=intent.type,
        confidence=intent.confidence,
        entities={},
        parameters={},
        requested_action=intent.type.value,
        payload=intent.payload,
        raw_text=intent.raw_text,
        source="rule_based",
    )


def _finalize_safety_fields(structured: StructuredIntent,
                             confirmation_policy: str) -> StructuredIntent:
    """Recompute risk/confirmation from raw text — the one non-negotiable step.

    Runs for both rule-based and AI-fallback results, so there is exactly
    one code path that ever sets these two fields for real.
    """
    risk = classify_risk(structured.raw_text)
    order = [RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
    # A rule-based DANGEROUS_OPERATION already carries the risk that
    # triggered it; take the higher of the two so a fallback classification
    # can never *downgrade* an already-detected risk.
    if structured.type == IntentType.DANGEROUS_OPERATION and structured.risk_level in order:
        risk = max(risk, structured.risk_level, key=order.index)
    structured.risk_level = risk

    # SAFETY-CRITICAL: intent *type* is not a trustworthy gate on its own —
    # an AI fallback classification (or, in principle, a bug in the rule
    # engine) could label a HIGH/CRITICAL-risk message as CONVERSATION or
    # QUESTION, which would otherwise never reach the confirmation check
    # below. Risk is computed deterministically above from raw text and
    # cannot be spoofed by the model; here we make risk authoritative over
    # type as well, so a HIGH/CRITICAL-risk message is *always* routed as
    # DANGEROUS_OPERATION regardless of what classified it that way.
    if risk in (RiskLevel.HIGH, RiskLevel.CRITICAL):
        structured.type = IntentType.DANGEROUS_OPERATION

    structured.requires_confirmation_flag = (
        structured.type == IntentType.DANGEROUS_OPERATION
        and requires_confirmation(risk, confirmation_policy)
    )
    return structured


def _try_ai_classification(text: str, provider: AIProvider,
                            context_snapshot: Optional[dict]) -> Optional[StructuredIntent]:
    prompt = _CLASSIFIER_PROMPT_TEMPLATE.format(
        intent_types=", ".join(sorted(_VALID_INTENT_TYPES)),
        context=context_snapshot or {},
        message=text,
    )
    try:
        data = provider.generate_json(prompt)
    except (ProviderUnavailableError, ProviderResponseError) as e:
        logger.info("nlu_fallback_failed reason=%s", e)
        return None
    except Exception as e:  # noqa: BLE001 - a misbehaving provider must not crash NLU
        logger.warning("nlu_fallback_unexpected_error error=%s", e)
        return None

    intent_type_raw = str(data.get("intent_type", data.get("intent", ""))).strip().upper()
    if intent_type_raw not in _VALID_INTENT_TYPES:
        logger.info("nlu_fallback_invalid_intent_type value=%r", intent_type_raw)
        return None

    try:
        confidence = float(data.get("confidence", 0.5))
    except (TypeError, ValueError):
        confidence = 0.5
    confidence = max(0.0, min(1.0, confidence))

    entities = data.get("entities", {})
    if isinstance(entities, list):
        entities = {"items": entities}
    elif not isinstance(entities, dict):
        entities = {}

    parameters = data.get("parameters", {})
    if not isinstance(parameters, dict):
        parameters = {}

    requested_action = data.get("action", data.get("requested_action", intent_type_raw))
    if not isinstance(requested_action, str):
        requested_action = intent_type_raw

    if "payload" in data and isinstance(data["payload"], str):
        payload = data["payload"]
    elif entities.get("items") and all(isinstance(i, str) for i in entities["items"]):
        # No explicit payload, but the model gave entities (e.g. the spec
        # example: {"intent": "KNOWLEDGE_QUERY", "entities": ["entropy"]}) —
        # use them as a reasonable default search/handler payload.
        payload = " ".join(entities["items"])
    else:
        payload = text

    return StructuredIntent(
        type=IntentType(intent_type_raw),
        confidence=confidence,
        entities=entities,
        parameters=parameters,
        requested_action=requested_action,
        payload=payload,
        raw_text=text,
        # These get overwritten unconditionally in _finalize_safety_fields —
        # set here only so reasoning_context can show what the model claimed.
        risk_level=RiskLevel.LOW,
        requires_confirmation_flag=False,
        reasoning_context={"model_claimed": dict(data)},
        source="ai_fallback",
    )


def classify_with_fallback(text: str, provider: Optional[AIProvider] = None,
                            confidence_threshold: float = 0.55,
                            confirmation_policy: str = "risky_only",
                            context_snapshot: Optional[dict] = None) -> StructuredIntent:
    """Run the full rule-based -> AI-fallback -> safety-finalization pipeline."""
    rule_intent = classify_intent(text)
    structured = _from_rule_based(rule_intent)
    # Carry the rule-based risk through so _finalize_safety_fields can take
    # the max() against it even if the AI fallback runs next.
    structured.risk_level = rule_intent.risk_level

    if structured.confidence < confidence_threshold and provider is not None:
        try:
            available = provider.is_available()
        except Exception:  # noqa: BLE001
            available = False
        if available:
            ai_result = _try_ai_classification(text, provider, context_snapshot)
            if ai_result is not None and ai_result.confidence >= structured.confidence:
                ai_result.reasoning_context["rule_based_fallback"] = {
                    "type": rule_intent.type.value,
                    "confidence": rule_intent.confidence,
                }
                structured = ai_result

    return _finalize_safety_fields(structured, confirmation_policy)
