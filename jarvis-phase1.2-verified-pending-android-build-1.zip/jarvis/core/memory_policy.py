"""
Memory decision policy.

Decides, for messages that were NOT an explicit "remember that ..."
command, whether they contain something worth quietly storing as
long-term memory (a stated personal preference or fact), versus a
plain question that must never be auto-stored.

Also defines the secret-pattern guard used by memory/long_term.py:
passwords, API keys, tokens, and similar credentials are never stored
in long-term memory, even if the user explicitly asks to remember
them — safety here does not bend to an explicit request, the same
principle as the safety engine's confirmation rules.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

# --- Secret detection -------------------------------------------------- #

_SECRET_PATTERNS = [
    re.compile(r"\bpassword\s*(is|:)?\s*\S+", re.IGNORECASE),
    re.compile(r"\bapi[_ -]?key\s*(is|:)?\s*\S+", re.IGNORECASE),
    re.compile(r"\b(secret|access)[_ -]?key\s*(is|:)?\s*\S+", re.IGNORECASE),
    re.compile(r"\b(auth|bearer)[_ -]?token\s*(is|:)?\s*\S+", re.IGNORECASE),
    re.compile(r"\bcredit ?card\s*(number)?\s*(is|:)?\s*\d", re.IGNORECASE),
    re.compile(r"\b(ssn|social security number)\s*(is|:)?\s*\d", re.IGNORECASE),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"\bsk-[A-Za-z0-9]{16,}"),  # common API-key-shaped tokens
]


def contains_secret(text: str) -> bool:
    return any(p.search(text) for p in _SECRET_PATTERNS)


# --- "Is this worth remembering?" heuristics --------------------------- #

@dataclass
class MemoryDecision:
    should_remember: bool
    content: str
    category: str
    importance: int
    confidence: float
    reason: str


# Patterns that indicate a stated personal preference/fact worth keeping,
# even without an explicit "remember" command.
_PERSONAL_FACT_PATTERNS = [
    (re.compile(r"^\s*my favorite (.+?) is (.+)$", re.IGNORECASE), "preference"),
    (re.compile(r"^\s*i prefer (.+)$", re.IGNORECASE), "preference"),
    (re.compile(r"^\s*i (?:really )?(?:like|love|enjoy) (.+)$", re.IGNORECASE), "preference"),
    (re.compile(r"^\s*i (?:really )?(?:dislike|hate) (.+)$", re.IGNORECASE), "preference"),
    (re.compile(r"^\s*my name is (.+)$", re.IGNORECASE), "identity"),
    (re.compile(r"^\s*i work (at|as|for) (.+)$", re.IGNORECASE), "identity"),
    (re.compile(r"^\s*i live in (.+)$", re.IGNORECASE), "identity"),
    (re.compile(r"^\s*i am (?:a|an) (.+)$", re.IGNORECASE), "identity"),
]

# A plain question is never auto-stored, even if it happens to contain
# words that overlap a personal-fact pattern's vocabulary.
_QUESTION_INDICATORS = re.compile(
    r"^\s*(what|who|when|where|why|how|is|does|did|can|could|would|will)\b", re.IGNORECASE
)


def decide_memory_action(text: str) -> MemoryDecision:
    """Decide whether a non-explicit-remember message should be stored.

    This is intentionally conservative: only clear first-person
    statements of preference/identity are auto-flagged, and anything
    phrased as a question is never stored, however similar its
    vocabulary is to a stored fact ("What is Python?" must not become
    a memory just because "I love Python" would be).
    """
    stripped = text.strip()

    if contains_secret(stripped):
        return MemoryDecision(False, "", "rejected", 0, 0.0, "contains a secret/credential")

    if stripped.endswith("?") or _QUESTION_INDICATORS.match(stripped):
        return MemoryDecision(False, "", "none", 0, 0.0, "phrased as a question")

    for pattern, category in _PERSONAL_FACT_PATTERNS:
        if pattern.match(stripped):
            return MemoryDecision(
                should_remember=True,
                content=stripped,
                category=category,
                importance=2,
                confidence=0.75,
                reason=f"matched personal-fact pattern ({category})",
            )

    return MemoryDecision(False, "", "none", 0, 0.0, "no personal-fact pattern matched")
