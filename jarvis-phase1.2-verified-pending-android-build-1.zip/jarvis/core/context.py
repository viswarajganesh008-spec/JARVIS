"""
Context Engine.

Tracks the running conversation and does lightweight, rule-based
reference resolution ("he" / "it" / "that" -> the last relevant
entity or topic). This is intentionally simple for Phase 1: there is
no language model in the loop yet, so resolution is heuristic, not
true coreference resolution. It is designed to be replaced by an
AIProvider-backed resolver later without changing its interface.

Known limitation (documented, not hidden): pronoun resolution only
tracks a single "current subject" and a single "current topic". It
will get confused by multiple competing entities in one message, and
it does not do deep grammatical analysis. This is a real, working
approximation, not a stub.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, List, Optional

from memory.short_term import ShortTermMemory

PRONOUNS = {"he", "him", "his", "she", "her", "hers", "it", "its", "they", "them", "their",
            "this", "that", "these", "those"}

# Very small stopword list used only to help pick out a plausible
# "subject" from a sentence — not a real NLP parser.
_STOPWORDS = {
    "who", "what", "when", "where", "why", "how", "is", "was", "are", "were", "the",
    "a", "an", "of", "in", "on", "at", "to", "for", "and", "or", "invented", "born",
    "explain", "tell", "me", "about", "does", "do", "did", "please", "can", "you",
}


@dataclass
class PendingTask:
    """A multi-turn task waiting on one or more missing parameters.

    Example: "find the area of a circle" -> needs "radius" -> user says
    "5 cm" -> task completes and the tool actually runs.
    """
    task_name: str
    tool_name: str
    required_slots: List[str]
    collected: dict = field(default_factory=dict)
    prompt_for_next: str = ""

    def next_missing_slot(self) -> Optional[str]:
        for slot in self.required_slots:
            if slot not in self.collected:
                return slot
        return None

    def is_complete(self) -> bool:
        return self.next_missing_slot() is None


@dataclass
class ContextState:
    current_topic: Optional[str] = None
    current_subject: Optional[str] = None
    recent_entities: List[str] = field(default_factory=list)
    current_task: Optional[str] = None
    previous_intent_type: Optional[str] = None
    previous_response: Optional[str] = None
    pending_task: Optional[PendingTask] = None


class ContextManager:
    def __init__(self, max_messages: int = 20):
        self.short_term = ShortTermMemory(max_messages=max_messages)
        self.state = ContextState()

    # ------------------------------------------------------------------ #
    # Multi-turn pending task support
    # ------------------------------------------------------------------ #
    def start_pending_task(self, task_name: str, tool_name: str,
                            required_slots: List[str], prompt_for_next: str = "") -> None:
        self.state.pending_task = PendingTask(
            task_name=task_name, tool_name=tool_name,
            required_slots=list(required_slots), prompt_for_next=prompt_for_next,
        )

    def has_pending_task(self) -> bool:
        return self.state.pending_task is not None

    def fill_pending_slot(self, slot: str, value: Any) -> None:
        if self.state.pending_task:
            self.state.pending_task.collected[slot] = value

    def clear_pending_task(self) -> None:
        self.state.pending_task = None

    def record_turn_outcome(self, intent_type: str, response_text: str) -> None:
        self.state.previous_intent_type = intent_type
        self.state.previous_response = response_text

    def resolve_references(self, text: str, target: Optional[str] = None) -> str:
        """Best-effort substitution of pronouns with a known subject/topic.

        Returns a rewritten string used only for downstream knowledge/question
        lookup — the original user text is still what gets stored/logged, and
        this is never used to reinterpret memory or tool commands (a bare
        "that" in "remember that ..." is a complementizer, not a reference).

        If `target` is not given, falls back to the *current* tracked
        subject/topic. Callers resolving a follow-up question should pass the
        subject captured *before* this turn's own update_from_user_message
        call, since that call may re-derive a subject from the new message
        itself.
        """
        words = text.split()
        resolved_words = []
        if target is None:
            target = self.state.current_subject or self.state.current_topic
        for w in words:
            bare = re.sub(r"[^\w]", "", w).lower()
            if bare in PRONOUNS and target:
                resolved_words.append(w.lower().replace(bare, target))
            else:
                resolved_words.append(w)
        return " ".join(resolved_words)

    def update_from_user_message(self, text: str) -> None:
        self.short_term.add_turn("user", text)
        subject = self._extract_subject(text)
        if subject:
            self.state.current_subject = subject
            self.state.current_topic = subject
            self.state.recent_entities.append(subject)
            self.state.recent_entities = self.state.recent_entities[-10:]

    def update_from_jarvis_message(self, text: str) -> None:
        self.short_term.add_turn("jarvis", text)

    def _extract_subject(self, text: str) -> Optional[str]:
        """Pull a plausible noun-phrase subject out of a question/statement.

        Heuristic only: strips stopwords/punctuation and takes the
        longest remaining contiguous word run. Good enough for
        "Who invented the telephone?" -> "telephone", not good enough
        for complex multi-clause sentences (documented limitation).
        """
        cleaned = re.sub(r"[^\w\s]", "", text.lower())
        tokens = [t for t in cleaned.split() if t not in _STOPWORDS and t not in PRONOUNS]
        if not tokens:
            return None
        return " ".join(tokens[-3:]) if len(tokens) <= 3 else " ".join(tokens[-2:])

    def snapshot(self) -> dict:
        return {
            "current_topic": self.state.current_topic,
            "current_subject": self.state.current_subject,
            "recent_entities": self.state.recent_entities,
            "current_task": self.state.current_task,
            "previous_intent_type": self.state.previous_intent_type,
            "previous_response": self.state.previous_response,
            "has_pending_task": self.has_pending_task(),
            "history_length": len(self.short_term.turns),
        }

    def build_prompt_context(self, memory_items: Optional[List[str]] = None,
                              knowledge_snippets: Optional[List[str]] = None,
                              max_history_turns: int = 5) -> dict:
        """Assemble a bounded context bundle for an AI provider call.

        Deliberately caps history and inputs rather than sending the
        entire conversation — satisfies "do not send unlimited history
        to the model." Callers (orchestrator handlers) supply already
        -retrieved memory/knowledge text; this method never fetches
        anything itself, keeping context-building and retrieval separate.
        """
        recent = self.short_term.recent_history(max_history_turns)
        return {
            "recent_history": [{"role": t.role, "text": t.text} for t in recent],
            "current_topic": self.state.current_topic,
            "recent_entities": self.state.recent_entities[-5:],
            "previous_intent_type": self.state.previous_intent_type,
            "relevant_memory": (memory_items or [])[:5],
            "relevant_knowledge": (knowledge_snippets or [])[:3],
        }
