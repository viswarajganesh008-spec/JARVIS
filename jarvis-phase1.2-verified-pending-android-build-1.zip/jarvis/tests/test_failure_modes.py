"""
Failure-mode tests.

Each test in this file simulates a specific way the world can go wrong
(unreachable model, empty knowledge base, broken tool, memory backend
failure, hostile/malformed user input) and asserts that JarvisCore
degrades gracefully — a clean message, never an uncaught exception,
never a hang, never a crash.
"""

import os
import shutil
import sqlite3
import tempfile
import unittest

from config.config import JarvisConfig
from core.orchestrator import JarvisCore
from memory.long_term import LongTermMemory
from providers.base import AIProvider, ProviderUnavailableError


class _AlwaysUnavailableProvider(AIProvider):
    name = "unavailable"

    def is_available(self):
        return False

    def generate(self, prompt, **kwargs):
        raise ProviderUnavailableError("simulated: model server is down")

    def chat(self, messages, **kwargs):
        raise ProviderUnavailableError("simulated: model server is down")

    def summarize(self, text, **kwargs):
        raise ProviderUnavailableError("simulated: model server is down")

    def classify(self, text, labels, **kwargs):
        raise ProviderUnavailableError("simulated: model server is down")


class _CrashingProvider(AIProvider):
    """Simulates a provider with a bug — raises something that ISN'T one of
    the two exception types core/nlu.py explicitly knows how to handle."""
    name = "crashing"

    def is_available(self):
        return True

    def generate(self, prompt, **kwargs):
        raise RuntimeError("simulated unexpected provider bug")

    def chat(self, messages, **kwargs):
        raise RuntimeError("simulated unexpected provider bug")

    def summarize(self, text, **kwargs):
        raise RuntimeError("simulated unexpected provider bug")

    def classify(self, text, labels, **kwargs):
        raise RuntimeError("simulated unexpected provider bug")


def _make_jarvis(tmpdir, provider=None, knowledge_dir=None):
    config = JarvisConfig(
        memory_db_path=os.path.join(tmpdir, "memory.db"),
        knowledge_directory=knowledge_dir or os.path.join(tmpdir, "empty_kb"),
        knowledge_index_path=os.path.join(tmpdir, "index.json"),
        log_file=os.path.join(tmpdir, "jarvis.log"),
        nlu_confidence_threshold=0.99,
    )
    jarvis = JarvisCore(config)
    if provider is not None:
        jarvis.provider = provider
    return jarvis


class TestProviderFailureModes(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_unavailable_provider_conversation_degrades_gracefully(self):
        jarvis = _make_jarvis(self.tmpdir, provider=_AlwaysUnavailableProvider())
        reply = jarvis.process("tell me something interesting")
        self.assertIsInstance(reply, str)
        self.assertGreater(len(reply), 0)
        jarvis.close()

    def test_provider_that_raises_unexpected_exception_does_not_crash_nlu(self):
        jarvis = _make_jarvis(self.tmpdir, provider=_CrashingProvider())
        # This message is deliberately ambiguous so the AI fallback path
        # actually gets invoked (and then blows up in a way core/nlu.py
        # doesn't specifically expect) — classify_with_fallback must catch
        # it, not propagate it.
        reply = jarvis.process("hmm yeah I guess so whatever")
        self.assertIsInstance(reply, str)
        jarvis.close()

    def test_provider_that_raises_unexpected_exception_does_not_crash_conversation(self):
        jarvis = _make_jarvis(self.tmpdir, provider=_CrashingProvider())
        # handle_conversation only explicitly catches ProviderUnavailableError;
        # confirm a wilder provider bug still doesn't take JARVIS down —
        # the top-level handler try/except in process() is the backstop.
        reply = jarvis.process("just chatting, nothing specific")
        self.assertIsInstance(reply, str)
        self.assertGreater(len(reply), 0)
        jarvis.close()


class TestKnowledgeFailureModes(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_knowledge_base_gives_honest_answer(self):
        jarvis = _make_jarvis(self.tmpdir)  # empty_kb dir doesn't even exist
        reply = jarvis.process("search knowledge quantum gravity unification")
        self.assertIsInstance(reply, str)
        self.assertTrue("don't" in reply.lower() or "not" in reply.lower())
        jarvis.close()

    def test_knowledge_query_with_unavailable_provider_still_answers_honestly(self):
        jarvis = _make_jarvis(self.tmpdir, provider=_AlwaysUnavailableProvider())
        reply = jarvis.process("explain nonexistent concept xyzzy")
        self.assertIsInstance(reply, str)
        jarvis.close()


class TestToolFailureModes(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.jarvis = _make_jarvis(self.tmpdir)

    def tearDown(self):
        self.jarvis.close()
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_broken_tool_execution_does_not_crash_jarvis(self):
        from tools.registry import Tool

        def boom(**kwargs):
            raise RuntimeError("simulated hardware failure")

        self.jarvis.tools.register(Tool(
            name="broken_tool", description="", input_schema={}, risk_level="LOW",
            permission_required=False, execute=boom,
        ))
        result = self.jarvis._execute_tool_safely("broken_tool", requested_by="rule_based")
        self.assertFalse(result["ok"])
        self.assertIn("simulated hardware failure", result["error"])

    def test_calculation_with_invalid_input_degrades_gracefully(self):
        reply = self.jarvis.process("calculate 2 +++ / nonsense")
        self.assertIsInstance(reply, str)


class TestMemoryFailureModes(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_memory_backend_failure_does_not_crash_process(self):
        jarvis = _make_jarvis(self.tmpdir)

        def broken_remember(*args, **kwargs):
            raise sqlite3.OperationalError("simulated: disk I/O error")

        jarvis.memory.remember = broken_remember
        # process()'s top-level try/except around handler dispatch is the
        # backstop here — the explicit remember command itself calls
        # self.memory.remember() with no inner try/except of its own for
        # generic storage failures (only MemoryRejectedError is caught
        # explicitly), so this proves the outer safety net actually works.
        reply = jarvis.process("remember that I like tea")
        self.assertIsInstance(reply, str)
        self.assertGreater(len(reply), 0)
        jarvis.close()

    def test_memory_disabled_does_not_crash_any_memory_command(self):
        config = JarvisConfig(
            memory_enabled=False,
            knowledge_directory=os.path.join(self.tmpdir, "kb"),
            knowledge_index_path=os.path.join(self.tmpdir, "index.json"),
            log_file=os.path.join(self.tmpdir, "jarvis.log"),
        )
        jarvis = JarvisCore(config)
        for msg in ["remember that I like tea", "what do you remember",
                    "forget tea", "list memories"]:
            reply = jarvis.process(msg)
            self.assertIsInstance(reply, str)
        jarvis.close()


class TestInvalidUserInput(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.jarvis = _make_jarvis(self.tmpdir)

    def tearDown(self):
        self.jarvis.close()
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_string_does_not_crash(self):
        reply = self.jarvis.process("")
        self.assertIsInstance(reply, str)

    def test_whitespace_only_does_not_crash(self):
        reply = self.jarvis.process("     \n\t  ")
        self.assertIsInstance(reply, str)

    def test_extremely_long_input_does_not_crash(self):
        reply = self.jarvis.process("tell me about " + "x" * 10000)
        self.assertIsInstance(reply, str)

    def test_unicode_and_emoji_input_does_not_crash(self):
        reply = self.jarvis.process("what is entropy? 🔥🧠💥 你好 안녕하세요")
        self.assertIsInstance(reply, str)

    def test_control_characters_do_not_crash(self):
        reply = self.jarvis.process("calculate 2\x00 + \x01 2")
        self.assertIsInstance(reply, str)

    def test_only_punctuation_does_not_crash(self):
        reply = self.jarvis.process("!!!???...")
        self.assertIsInstance(reply, str)

    def test_sql_injection_style_input_does_not_crash_memory(self):
        reply = self.jarvis.process("remember that '; DROP TABLE memories; --")
        self.assertIsInstance(reply, str)
        # And the table should still be intact afterward.
        items = self.jarvis.memory.list_all()
        self.assertIsInstance(items, list)


if __name__ == "__main__":
    unittest.main()
