import json
import os
import tempfile
import unittest

from config.config import JarvisConfig
from api.server import create_app


def _make_config_factory(tmpdir):
    """Build a config_factory like the one create_app() expects, wired
    to an isolated temp directory per test (mirrors tests/test_orchestrator.py)."""
    kb_dir = os.path.join(tmpdir, "knowledge")
    os.makedirs(kb_dir, exist_ok=True)

    def factory():
        return JarvisConfig(
            memory_db_path=os.path.join(tmpdir, "memory.db"),
            knowledge_directory=kb_dir,
            knowledge_index_path=os.path.join(tmpdir, "index.json"),
            log_file=os.path.join(tmpdir, "jarvis.log"),
            confirmation_policy="risky_only",
        )

    return factory


class ApiTestBase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.app = create_app(config_factory=_make_config_factory(self.tmpdir))
        self.client = self.app.test_client()

    def tearDown(self):
        self.app.config["JARVIS_SESSIONS"].close_all()

    def post_message(self, payload):
        return self.client.post("/message", data=json.dumps(payload),
                                 content_type="application/json")


class TestHealthEndpoint(ApiTestBase):
    def test_health_returns_ok(self):
        resp = self.client.get("/health")
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        self.assertEqual(body["status"], "ok")
        self.assertIn("jarvis_name", body)
        self.assertEqual(body["active_conversations"], 0)

    def test_health_reflects_active_conversation_count(self):
        self.post_message({"message": "hello", "conversation_id": "conv-1"})
        resp = self.client.get("/health")
        self.assertEqual(resp.get_json()["active_conversations"], 1)


class TestMessageRequestConstruction(ApiTestBase):
    """Covers request shape / response parsing from the Android client's
    point of view: given a well-formed request, is the response shaped
    exactly as JarvisClient will expect?"""

    def test_basic_message_returns_response_and_conversation_id(self):
        resp = self.post_message({"message": "hello", "conversation_id": "conv-1"})
        self.assertEqual(resp.status_code, 200)
        body = resp.get_json()
        self.assertIn("response", body)
        self.assertIsInstance(body["response"], str)
        self.assertEqual(body["conversation_id"], "conv-1")
        self.assertEqual(body["metadata"], {})

    def test_omitted_conversation_id_generates_one(self):
        resp = self.post_message({"message": "hello"})
        body = resp.get_json()
        self.assertTrue(body["conversation_id"])
        self.assertIsInstance(body["conversation_id"], str)

    def test_empty_conversation_id_generates_one(self):
        resp = self.post_message({"message": "hello", "conversation_id": ""})
        body = resp.get_json()
        self.assertTrue(body["conversation_id"])


class TestConversationContextHandling(ApiTestBase):
    def test_same_conversation_id_reuses_context_for_followup(self):
        first = self.post_message({
            "message": "What is entropy?", "conversation_id": "conv-context",
        })
        self.assertEqual(first.status_code, 200)

        second = self.post_message({
            "message": "Explain it simpler.", "conversation_id": "conv-context",
        })
        self.assertEqual(second.status_code, 200)
        # Should not be treated as a brand-new, contextless topic - the
        # orchestrator's own pronoun/topic resolution is exercised here;
        # this test only asserts the bridge actually routed both calls
        # to the *same* JarvisCore instance rather than fresh ones.
        self.assertEqual(second.get_json()["conversation_id"], "conv-context")

    def test_different_conversation_ids_get_independent_sessions(self):
        self.post_message({"message": "My favorite language is Python.",
                            "conversation_id": "conv-a"})
        resp = self.post_message({"message": "What is my favorite language?",
                                   "conversation_id": "conv-b"})
        self.assertEqual(resp.status_code, 200)
        # conv-b never heard the fact stated in conv-a; this just
        # verifies the two conversations don't share JarvisCore state
        # (i.e. sessions are actually keyed per conversation_id).
        sessions = self.app.config["JARVIS_SESSIONS"]
        self.assertEqual(sessions.session_count(), 2)


class TestMalformedAndEdgeCaseInput(ApiTestBase):
    def test_missing_message_field_rejected(self):
        resp = self.post_message({"conversation_id": "conv-1"})
        self.assertEqual(resp.status_code, 400)
        self.assertIn("error", resp.get_json())

    def test_empty_message_rejected(self):
        resp = self.post_message({"message": "   "})
        self.assertEqual(resp.status_code, 400)

    def test_non_string_message_rejected(self):
        resp = self.post_message({"message": 12345})
        self.assertEqual(resp.status_code, 400)

    def test_oversized_message_rejected(self):
        resp = self.post_message({"message": "a" * 9000})
        self.assertEqual(resp.status_code, 400)

    def test_non_string_conversation_id_rejected(self):
        resp = self.post_message({"message": "hi", "conversation_id": 42})
        self.assertEqual(resp.status_code, 400)

    def test_malformed_json_body_rejected_cleanly(self):
        resp = self.client.post("/message", data="{not valid json",
                                 content_type="application/json")
        self.assertEqual(resp.status_code, 400)
        self.assertIn("error", resp.get_json())

    def test_non_object_json_body_rejected(self):
        resp = self.client.post("/message", data=json.dumps(["a", "list"]),
                                 content_type="application/json")
        self.assertEqual(resp.status_code, 400)

    def test_empty_body_rejected(self):
        resp = self.client.post("/message", data="", content_type="application/json")
        self.assertEqual(resp.status_code, 400)


class TestBackendErrorHandling(ApiTestBase):
    def test_unknown_route_returns_clean_404_json(self):
        resp = self.client.get("/does-not-exist")
        self.assertEqual(resp.status_code, 404)
        self.assertIn("error", resp.get_json())

    def test_wrong_method_returns_clean_405_json(self):
        resp = self.client.get("/message")
        self.assertEqual(resp.status_code, 405)
        self.assertIn("error", resp.get_json())


class TestSafetyBoundaryPreserved(ApiTestBase):
    """The bridge must never let a dangerous action execute without the
    same confirmation flow the CLI enforces - it has no separate
    'trusted' path for API callers."""

    def test_dangerous_request_asks_for_confirmation_not_executes(self):
        resp = self.post_message({
            "message": "delete all files", "conversation_id": "conv-danger",
        })
        self.assertEqual(resp.status_code, 200)
        reply = resp.get_json()["response"].lower()
        self.assertTrue(
            "confirm" in reply or "continue" in reply or "sure" in reply,
            f"expected a confirmation prompt, got: {reply!r}",
        )

    def test_confirmation_state_is_per_conversation(self):
        # Start a dangerous action on conv-danger-2 ...
        self.post_message({"message": "delete all files",
                            "conversation_id": "conv-danger-2"})
        # ...a totally unrelated conversation must not inherit that
        # pending-confirmation state.
        resp = self.post_message({"message": "hello",
                                   "conversation_id": "conv-unrelated"})
        self.assertEqual(resp.status_code, 200)
        reply = resp.get_json()["response"].lower()
        self.assertNotIn("critical", reply)


class TestConversationReset(ApiTestBase):
    def test_delete_existing_conversation_returns_cleared_true(self):
        self.post_message({"message": "hello", "conversation_id": "conv-x"})
        resp = self.client.delete("/conversation/conv-x")
        self.assertEqual(resp.status_code, 200)
        self.assertTrue(resp.get_json()["cleared"])

    def test_delete_unknown_conversation_returns_cleared_false(self):
        resp = self.client.delete("/conversation/never-existed")
        self.assertEqual(resp.status_code, 200)
        self.assertFalse(resp.get_json()["cleared"])


class TestSessionManagerDirectly(unittest.TestCase):
    """A couple of unit-level checks on SessionManager that don't need
    the Flask layer at all."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.factory = _make_config_factory(self.tmpdir)

    def test_reuses_same_core_for_same_conversation_id(self):
        from api.sessions import SessionManager
        manager = SessionManager(self.factory)
        s1 = manager.get_or_create("conv-1")
        s2 = manager.get_or_create("conv-1")
        self.assertIs(s1.core, s2.core)
        manager.close_all()

    def test_distinct_conversation_ids_get_distinct_cores(self):
        from api.sessions import SessionManager
        manager = SessionManager(self.factory)
        s1 = manager.get_or_create("conv-1")
        s2 = manager.get_or_create("conv-2")
        self.assertIsNot(s1.core, s2.core)
        manager.close_all()


if __name__ == "__main__":
    unittest.main()
