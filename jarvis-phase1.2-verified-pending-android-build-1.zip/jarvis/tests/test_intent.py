import unittest

from core.intent import IntentType, classify_intent
from safety.risk_classifier import RiskLevel


class TestIntentClassification(unittest.TestCase):
    def test_calculation_high_confidence(self):
        intent = classify_intent("calculate 25 * 36")
        self.assertEqual(intent.type, IntentType.CALCULATION)
        self.assertGreaterEqual(intent.confidence, 0.85)

    def test_bare_arithmetic_detected(self):
        intent = classify_intent("2 + 2")
        self.assertEqual(intent.type, IntentType.CALCULATION)

    def test_memory_remember_high_confidence(self):
        intent = classify_intent("remember that I like examples")
        self.assertEqual(intent.type, IntentType.MEMORY_REMEMBER)
        self.assertGreaterEqual(intent.confidence, 0.85)

    def test_dangerous_operation_detected(self):
        intent = classify_intent("delete all my files")
        self.assertEqual(intent.type, IntentType.DANGEROUS_OPERATION)
        self.assertEqual(intent.risk_level, RiskLevel.HIGH)

    def test_knowledge_query_detected(self):
        intent = classify_intent("explain entropy")
        self.assertEqual(intent.type, IntentType.KNOWLEDGE_QUERY)

    def test_ambiguous_conversation_low_confidence(self):
        intent = classify_intent("that's cool I guess")
        self.assertEqual(intent.type, IntentType.CONVERSATION)
        self.assertLess(intent.confidence, 0.55)

    def test_ambiguous_question_moderate_confidence(self):
        intent = classify_intent("wait is that even possible")
        self.assertLess(intent.confidence, 0.85)


class TestIntentPunctuationHandling(unittest.TestCase):
    """Regression coverage for two real bugs found during Phase 1.1 CLI
    verification: a trailing period from 'remember that X.' leaking into a
    doubled '..' in the response, and a trailing '?' on 'what do you
    remember about me?' preventing the filler-phrase ('about me') match."""

    def test_remember_strips_trailing_period(self):
        intent = classify_intent("Remember that I prefer simple explanations.")
        self.assertEqual(intent.payload, "I prefer simple explanations")

    def test_remember_without_trailing_period_unaffected(self):
        intent = classify_intent("remember that I prefer simple explanations")
        self.assertEqual(intent.payload, "I prefer simple explanations")

    def test_retrieve_about_me_with_question_mark_is_list_all(self):
        intent = classify_intent("What do you remember about me?")
        self.assertEqual(intent.payload, "")

    def test_retrieve_about_me_without_question_mark_is_list_all(self):
        intent = classify_intent("what do you remember about me")
        self.assertEqual(intent.payload, "")

    def test_retrieve_specific_query_still_works(self):
        # Only the exact filler phrases ("about me"/"about myself"/"about
        # you") collapse to list-all — anything else is a real search term.
        intent = classify_intent("what do you remember about JARVIS")
        self.assertEqual(intent.payload, "about JARVIS")

    def test_calculate_with_trailing_period_strips_it(self):
        # Regression: "calculate 25 * 16." was previously parsed with the
        # period intact — Python's float grammar silently accepted "16."
        # as 16.0, producing a confusing "25 * 16. = 400.0" reply.
        intent = classify_intent("Calculate 25 * 16.")
        self.assertEqual(intent.payload, "25 * 16")
        self.assertEqual(intent.type, IntentType.CALCULATION)

    def test_dangerous_operation_with_trailing_period_strips_it(self):
        # Regression: "Delete all files." produced a doubled ".." once the
        # response template appended its own period after the payload.
        intent = classify_intent("Delete all files.")
        self.assertEqual(intent.payload, "Delete all files")
        self.assertEqual(intent.type, IntentType.DANGEROUS_OPERATION)

    def test_knowledge_query_with_trailing_question_mark_handled(self):
        intent = classify_intent("explain entropy?")
        self.assertEqual(intent.payload, "entropy")

    def test_bare_calculation_strips_trailing_period(self):
        intent = classify_intent("25 * 16.")
        self.assertEqual(intent.payload, "25 * 16")

    def test_calculation_with_genuine_decimal_unaffected(self):
        # A trailing terminator strip must never eat a real decimal digit —
        # only a lone trailing '.' with nothing after it is punctuation.
        intent = classify_intent("calculate 3.14 * 2")
        self.assertEqual(intent.payload, "3.14 * 2")

    def test_knowledge_query_strips_trailing_period(self):
        intent = classify_intent("explain entropy.")
        self.assertEqual(intent.payload, "entropy")


if __name__ == "__main__":
    unittest.main()
