import json
import os
import shutil
import tempfile
import unittest

from config.config import JarvisConfig
from core.orchestrator import JarvisCore
from providers.base import AIProvider
from tools.registry import Tool


class _AlwaysLowConfidenceStubProvider(AIProvider):
    """Available, but returns malformed/low-value JSON — exercises the
    'AI fallback ran but couldn't help' path without any network access."""
    name = "stub"

    def is_available(self):
        return True

    def generate(self, prompt, **kwargs):
        return "I'm not sure how to classify that."

    def chat(self, messages, **kwargs):
        return ""

    def summarize(self, text, **kwargs):
        return ""

    def classify(self, text, labels, **kwargs):
        return labels[0] if labels else ""


class _LyingSafetyProvider(AIProvider):
    """Always claims a dangerous request is safe conversation — used to
    prove JarvisCore's confirmation gate can't be talked out of firing."""
    name = "lying"

    def is_available(self):
        return True

    def generate(self, prompt, **kwargs):
        return json.dumps({
            "intent_type": "CONVERSATION",
            "confidence": 0.99,
            "payload": "delete all my files",
            "requires_confirmation": False,
        })

    def chat(self, messages, **kwargs):
        return ""

    def summarize(self, text, **kwargs):
        return ""

    def classify(self, text, labels, **kwargs):
        return labels[0] if labels else ""


class OrchestratorTestBase(unittest.TestCase):
    provider_cls = None

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        kb_dir = os.path.join(self.tmpdir, "knowledge")
        os.makedirs(kb_dir, exist_ok=True)
        with open(os.path.join(kb_dir, "thermo.txt"), "w", encoding="utf-8") as f:
            f.write("Entropy is a measure of disorder in a thermodynamic system.")

        self.config = JarvisConfig(
            memory_db_path=os.path.join(self.tmpdir, "memory.db"),
            knowledge_directory=kb_dir,
            knowledge_index_path=os.path.join(self.tmpdir, "index.json"),
            log_file=os.path.join(self.tmpdir, "jarvis.log"),
            confirmation_policy="risky_only",
            nlu_confidence_threshold=0.99,  # force fallback attempts in these tests
        )
        self.jarvis = JarvisCore(self.config)
        if self.provider_cls is not None:
            self.jarvis.provider = self.provider_cls()

    def tearDown(self):
        self.jarvis.close()
        shutil.rmtree(self.tmpdir, ignore_errors=True)


class TestMultiTurnTask(OrchestratorTestBase):
    def test_area_of_circle_multi_turn(self):
        reply1 = self.jarvis.process("find the area of a circle")
        self.assertIn("radius", reply1.lower())
        reply2 = self.jarvis.process("5 cm")
        self.assertIn("78.5", reply2)  # pi * 5^2 ≈ 78.54

    def test_area_of_rectangle_multi_turn(self):
        reply1 = self.jarvis.process("find the area of a rectangle")
        self.assertIn("width", reply1.lower())
        reply2 = self.jarvis.process("3")
        self.assertIn("height", reply2.lower())
        reply3 = self.jarvis.process("4")
        self.assertIn("12", reply3)

    def test_pending_task_can_be_cancelled(self):
        self.jarvis.process("find the area of a circle")
        reply = self.jarvis.process("cancel")
        self.assertIn("cancel", reply.lower())
        self.assertFalse(self.jarvis.context.has_pending_task())

    def test_non_numeric_reply_reprompts_same_slot(self):
        self.jarvis.process("find the area of a circle")
        reply = self.jarvis.process("pretty big")
        self.assertIn("radius", reply.lower())
        self.assertTrue(self.jarvis.context.has_pending_task())


class TestAmbiguousReference(OrchestratorTestBase):
    def test_open_it_asks_for_clarification(self):
        reply = self.jarvis.process("open it")
        self.assertIn("what would you like me to open", reply.lower())

    def test_open_calculator_is_not_ambiguous(self):
        reply = self.jarvis.process("open calculator")
        self.assertIn("calculator", reply.lower())
        self.assertNotIn("what would you like", reply.lower())


class TestMemoryIntelligence(OrchestratorTestBase):
    def test_implicit_preference_is_auto_remembered(self):
        self.jarvis.process("My favorite programming language is Python.")
        reply = self.jarvis.process("what do you remember")
        self.assertIn("python", reply.lower())

    def test_plain_question_is_not_auto_remembered(self):
        self.jarvis.process("What is Python?")
        reply = self.jarvis.process("what do you remember")
        self.assertNotIn("python", reply.lower())

    def test_secret_is_never_auto_remembered(self):
        self.jarvis.process("My password is hunter2, just so you know.")
        reply = self.jarvis.process("what do you remember")
        self.assertNotIn("hunter2", reply.lower())

    def test_explicit_remember_of_secret_is_refused_not_silently_dropped(self):
        reply = self.jarvis.process("remember that my password is hunter2")
        self.assertIn("not going to remember", reply.lower())


class TestSafetyCannotBeBypassedEndToEnd(OrchestratorTestBase):
    provider_cls = _LyingSafetyProvider

    def test_dangerous_action_still_requires_confirmation(self):
        reply = self.jarvis.process("delete all my files")
        self.assertTrue("confirm" in reply.lower() or "continue" in reply.lower())
        self.assertTrue(self.jarvis.confirmation.is_waiting())

    def test_confirmation_state_not_skipped_by_lying_provider(self):
        self.jarvis.process("delete all my files")
        reply = self.jarvis.process("no")
        self.assertIn("cancel", reply.lower())


class TestProviderUnavailableDuringConversation(OrchestratorTestBase):
    def test_no_provider_configured_gives_honest_message(self):
        # default config: ai_provider="local" -> always unavailable
        reply = self.jarvis.process("tell me something interesting")
        self.assertTrue(len(reply) > 0)
        self.assertIsInstance(reply, str)


class TestKnowledgeStillWorksWithFallbackEnabled(OrchestratorTestBase):
    provider_cls = _AlwaysLowConfidenceStubProvider

    def test_knowledge_grounded_answer_survives_malformed_fallback(self):
        reply = self.jarvis.process("search knowledge entropy")
        self.assertIn("thermo.txt", reply)

    def test_calculation_unaffected_by_ai_fallback_path(self):
        reply = self.jarvis.process("calculate 12 * 12")
        self.assertIn("144", reply)


class TestModelCannotExecuteToolsDirectly(unittest.TestCase):
    """Requirement: if the model requests a tool, it must pass through the
    same validator/risk/confirmation pipeline as any rule-based request —
    it can never talk its way past validation by claiming to be safe."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.jarvis = JarvisCore(JarvisConfig(
            memory_db_path=os.path.join(self.tmpdir, "memory.db"),
            knowledge_directory=os.path.join(self.tmpdir, "kb"),
            knowledge_index_path=os.path.join(self.tmpdir, "index.json"),
            log_file=os.path.join(self.tmpdir, "jarvis.log"),
        ))

    def tearDown(self):
        self.jarvis.close()
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_ai_requested_unknown_tool_rejected_cleanly(self):
        result = self.jarvis._execute_tool_safely("delete_everything", requested_by="ai")
        self.assertFalse(result["ok"])
        self.assertIn("error", result)

    def test_ai_requested_valid_tool_with_missing_args_rejected(self):
        result = self.jarvis._execute_tool_safely("calculator", requested_by="ai")
        self.assertFalse(result["ok"])
        self.assertIn("expression", result["error"])

    def test_ai_requested_safe_tool_with_valid_args_still_executes(self):
        # Being requested "by ai" doesn't make an already-safe LOW-risk tool
        # extra suspicious — it validates and runs normally.
        result = self.jarvis._execute_tool_safely("calculator", requested_by="ai",
                                                    expression="6 * 7")
        self.assertTrue(result["ok"])
        self.assertEqual(result["result"], 42)

    def test_hypothetically_dangerous_tool_blocked_regardless_of_requester(self):
        # Register a HIGH-risk tool the way a future capability might, and
        # confirm _execute_tool_safely refuses to run it outright rather
        # than trusting any caller (rule-based or "ai") to have already
        # obtained confirmation through some other path.
        self.jarvis.tools.register(Tool(
            name="wipe_disk", description="Simulated destructive tool.",
            input_schema={}, risk_level="CRITICAL", permission_required=True,
            execute=lambda: {"ok": True, "result": "disk wiped"},
        ))
        result = self.jarvis._execute_tool_safely("wipe_disk", requested_by="ai")
        self.assertFalse(result["ok"])
        self.assertIn("confirmation", result["error"].lower())


if __name__ == "__main__":
    unittest.main()
