import unittest

from safety.confirmation import ConfirmationManager, ConfirmationResult, ConfirmationState
from safety.risk_classifier import RiskLevel, classify_risk, requires_confirmation


class TestRiskClassifier(unittest.TestCase):
    def test_low_risk_normal_command(self):
        self.assertEqual(classify_risk("open calculator"), RiskLevel.LOW)
        self.assertEqual(classify_risk("explain steam turbines"), RiskLevel.LOW)

    def test_high_risk_delete_files(self):
        self.assertEqual(classify_risk("delete all my files"), RiskLevel.HIGH)

    def test_critical_risk_factory_reset(self):
        self.assertEqual(classify_risk("do a factory reset"), RiskLevel.CRITICAL)

    def test_medium_risk_send_message(self):
        self.assertEqual(classify_risk("send a message to John"), RiskLevel.MEDIUM)

    def test_requires_confirmation_rules(self):
        self.assertTrue(requires_confirmation(RiskLevel.CRITICAL, "never"))
        self.assertTrue(requires_confirmation(RiskLevel.HIGH, "never"))
        self.assertFalse(requires_confirmation(RiskLevel.LOW, "risky_only"))
        self.assertTrue(requires_confirmation(RiskLevel.MEDIUM, "risky_only"))


class TestConfirmationStateMachine(unittest.TestCase):
    def setUp(self):
        self.cm = ConfirmationManager()

    def test_normal_command_no_confirmation_needed(self):
        self.assertFalse(self.cm.is_waiting())

    def test_delete_triggers_waiting_state(self):
        self.cm.request("permanently delete your files", RiskLevel.HIGH)
        self.assertEqual(self.cm.state, ConfirmationState.WAITING_FOR_CONFIRMATION)
        self.assertIsNotNone(self.cm.pending)

    def test_yes_confirms(self):
        self.cm.request("permanently delete your files", RiskLevel.HIGH)
        result = self.cm.respond("yes")
        self.assertEqual(result, ConfirmationResult.CONFIRMED)

    def test_no_cancels(self):
        self.cm.request("permanently delete your files", RiskLevel.HIGH)
        result = self.cm.respond("no")
        self.assertEqual(result, ConfirmationResult.CANCELLED)

    def test_ambiguous_response(self):
        self.cm.request("permanently delete your files", RiskLevel.HIGH)
        result = self.cm.respond("maybe later")
        self.assertEqual(result, ConfirmationResult.AMBIGUOUS)

    def test_pending_action_survives_until_resolved(self):
        self.cm.request("permanently delete your files", RiskLevel.HIGH)
        self.cm.respond("maybe")  # ambiguous — must not clear pending
        self.assertIsNotNone(self.cm.pending)
        self.assertTrue(self.cm.is_waiting())
        self.cm.resolve()
        self.assertIsNone(self.cm.pending)
        self.assertFalse(self.cm.is_waiting())

    def test_critical_risk_requires_explicit_confirmation(self):
        self.cm.request("perform a factory reset", RiskLevel.CRITICAL)
        self.assertEqual(self.cm.pending.risk_level, RiskLevel.CRITICAL)


if __name__ == "__main__":
    unittest.main()
