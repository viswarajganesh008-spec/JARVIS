import os
import shutil
import tempfile
import unittest

from config.config import JarvisConfig
from core.orchestrator import JarvisCore


class TestJarvisCoreIntegration(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        kb_dir = os.path.join(self.tmpdir, "knowledge")
        os.makedirs(kb_dir, exist_ok=True)
        with open(os.path.join(kb_dir, "thermo.txt"), "w", encoding="utf-8") as f:
            f.write("Entropy is a measure of disorder in a thermodynamic system. "
                    "A steam turbine converts thermal energy from steam into "
                    "mechanical work to generate electricity.")

        self.config = JarvisConfig(
            memory_db_path=os.path.join(self.tmpdir, "memory.db"),
            knowledge_directory=kb_dir,
            knowledge_index_path=os.path.join(self.tmpdir, "index.json"),
            log_file=os.path.join(self.tmpdir, "jarvis.log"),
            confirmation_policy="risky_only",
        )
        self.jarvis = JarvisCore(self.config)

    def tearDown(self):
        self.jarvis.close()
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_calculate_command(self):
        reply = self.jarvis.process("calculate 25 * 36")
        self.assertIn("900", reply)

    def test_remember_and_recall(self):
        self.jarvis.process("remember that I prefer simple explanations")
        reply = self.jarvis.process("what do you remember")
        self.assertIn("simple explanations", reply)

    def test_search_knowledge_steam_turbine(self):
        reply = self.jarvis.process("search knowledge steam turbine")
        self.assertIn("thermo.txt", reply)

    def test_search_knowledge_no_information(self):
        reply = self.jarvis.process("search knowledge quantum chromodynamics gluon confinement")
        self.assertTrue("don't" in reply.lower() or "not" in reply.lower())

    def test_delete_files_requires_confirmation_then_cancels(self):
        reply = self.jarvis.process("delete all my files")
        self.assertIn("confirm" in reply.lower() or "continue" in reply.lower(), [True])
        reply2 = self.jarvis.process("no")
        self.assertIn("cancel", reply2.lower())

    def test_delete_files_confirmation_then_yes_executes_simulated(self):
        self.jarvis.process("delete all my files")
        reply2 = self.jarvis.process("yes")
        self.assertIn("simulated", reply2.lower())

    def test_factory_reset_is_critical_and_gated(self):
        reply = self.jarvis.process("perform a factory reset")
        self.assertIn("confirm", reply.lower())

    def test_ambiguous_confirmation_reprompts(self):
        self.jarvis.process("delete all my files")
        reply = self.jarvis.process("maybe")
        self.assertIn("yes or no", reply.lower())

    def test_pronoun_followup(self):
        self.jarvis.process("explain entropy")
        reply = self.jarvis.process("explain it simply")
        # Should not crash and should still attempt a grounded/ungrounded answer.
        self.assertIsInstance(reply, str)
        self.assertTrue(len(reply) > 0)


if __name__ == "__main__":
    unittest.main()
