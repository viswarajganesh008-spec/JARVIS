import os
import tempfile
import unittest

from memory.long_term import LongTermMemory


class TestMemory(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "test_memory.db")
        self.mem = LongTermMemory(self.db_path)

    def tearDown(self):
        self.mem.close()

    def test_store_memory(self):
        record = self.mem.remember("I prefer simple explanations")
        self.assertIsNotNone(record.id)
        self.assertEqual(record.content, "I prefer simple explanations")

    def test_retrieve_memory(self):
        self.mem.remember("My project is called JARVIS")
        results = self.mem.retrieve("JARVIS")
        self.assertEqual(len(results), 1)
        self.assertIn("JARVIS", results[0].content)

    def test_retrieve_no_match(self):
        self.mem.remember("Something unrelated")
        results = self.mem.retrieve("nonexistent_topic")
        self.assertEqual(results, [])

    def test_list_all(self):
        self.mem.remember("First fact")
        self.mem.remember("Second fact")
        all_items = self.mem.list_all()
        self.assertEqual(len(all_items), 2)

    def test_delete_memory(self):
        record = self.mem.remember("Temporary fact")
        deleted = self.mem.delete(record.id)
        self.assertTrue(deleted)
        self.assertEqual(self.mem.list_all(), [])

    def test_forget_by_query(self):
        self.mem.remember("I like engineering examples")
        self.mem.remember("Unrelated fact")
        count = self.mem.forget("engineering")
        self.assertEqual(count, 1)
        remaining = self.mem.list_all()
        self.assertEqual(len(remaining), 1)
        self.assertEqual(remaining[0].content, "Unrelated fact")

    def test_forget_no_match(self):
        self.mem.remember("Some fact")
        count = self.mem.forget("no_such_thing")
        self.assertEqual(count, 0)

    def test_update_memory(self):
        record = self.mem.remember("Old content")
        updated = self.mem.update(record.id, content="New content")
        self.assertTrue(updated)
        self.assertEqual(self.mem.store.get(record.id).content, "New content")


if __name__ == "__main__":
    unittest.main()
