import unittest

from tools.calculator import CALCULATOR_TOOL_SCHEMA, run as run_calculator
from tools.executor import ToolExecutor
from tools.registry import Tool, ToolRegistry
from tools.validator import ToolRequest, validate_tool_request


def _make_registry() -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(Tool(
        name="calculator",
        description=CALCULATOR_TOOL_SCHEMA["description"],
        input_schema=CALCULATOR_TOOL_SCHEMA["input_schema"],
        risk_level=CALCULATOR_TOOL_SCHEMA["risk_level"],
        permission_required=False,
        execute=lambda expression: run_calculator(expression),
    ))
    registry.register(Tool(
        name="delete_file",
        description="Delete a file from disk.",
        input_schema={"path": "string"},
        risk_level="HIGH",
        permission_required=True,
        execute=lambda path: {"ok": True, "result": f"deleted {path}"},
    ))
    registry.register(Tool(
        name="lying_tool",
        description="A tool that claims not to need confirmation despite being HIGH risk.",
        input_schema={},
        risk_level="HIGH",
        permission_required=True,
        confirmation_required=None,  # derive from risk — not overridden by any caller
        execute=lambda: {"ok": True, "result": "done"},
    ))
    return registry


class TestToolValidation(unittest.TestCase):
    def setUp(self):
        self.registry = _make_registry()

    def test_safe_tool_validates_ok(self):
        result = validate_tool_request(
            ToolRequest("calculator", {"expression": "2 + 2"}), self.registry
        )
        self.assertTrue(result.ok)
        self.assertFalse(result.needs_confirmation)

    def test_dangerous_tool_requires_confirmation(self):
        result = validate_tool_request(
            ToolRequest("delete_file", {"path": "/tmp/x.txt"}), self.registry
        )
        self.assertTrue(result.ok)
        self.assertTrue(result.needs_confirmation)
        self.assertTrue(result.needs_permission)

    def test_dangerous_tool_cannot_be_marked_safe_by_requester(self):
        # Even an "ai" requester can't talk its way past risk-derived confirmation.
        result = validate_tool_request(
            ToolRequest("lying_tool", {}, requested_by="ai"), self.registry
        )
        self.assertTrue(result.needs_confirmation)

    def test_invalid_tool_name_rejected(self):
        result = validate_tool_request(ToolRequest("nonexistent_tool", {}), self.registry)
        self.assertFalse(result.ok)
        self.assertIsNotNone(result.error)

    def test_missing_required_argument_rejected(self):
        result = validate_tool_request(ToolRequest("calculator", {}), self.registry)
        self.assertFalse(result.ok)
        self.assertIn("expression", result.error)

    def test_missing_required_argument_for_delete_rejected(self):
        result = validate_tool_request(ToolRequest("delete_file", {}), self.registry)
        self.assertFalse(result.ok)


class TestToolExecutorSafety(unittest.TestCase):
    def setUp(self):
        self.registry = _make_registry()
        self.executor = ToolExecutor(self.registry)

    def test_safe_tool_executes(self):
        result = self.executor.execute("calculator", expression="25 * 4")
        self.assertTrue(result["ok"])
        self.assertEqual(result["result"], 100)

    def test_unknown_tool_returns_clean_error_not_exception(self):
        result = self.executor.execute("nonexistent_tool")
        self.assertFalse(result["ok"])
        self.assertIn("error", result)

    def test_tool_that_raises_is_caught(self):
        registry = ToolRegistry()
        def boom(**kwargs):
            raise RuntimeError("simulated failure")
        registry.register(Tool(
            name="broken", description="", input_schema={}, risk_level="LOW",
            permission_required=False, execute=boom,
        ))
        executor = ToolExecutor(registry)
        result = executor.execute("broken")
        self.assertFalse(result["ok"])
        self.assertIn("simulated failure", result["error"])


if __name__ == "__main__":
    unittest.main()
