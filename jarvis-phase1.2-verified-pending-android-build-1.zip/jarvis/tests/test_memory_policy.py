import os
import tempfile
import unittest

from core.memory_policy import contains_secret, decide_memory_action
from memory.long_term import LongTermMemory, MemoryRejectedError


class TestMemoryDecisionHeuristics(unittest.TestCase):
    def test_explicit_preference_statement_is_flagged(self):
        d = decide_memory_action("My favorite programming language is Python.")
        self.assertTrue(d.should_remember)
        self.assertEqual(d.category, "preference")

    def test_i_prefer_statement_is_flagged(self):
        d = decide_memory_action("I prefer explanations with examples")
        self.assertTrue(d.should_remember)

    def test_identity_statement_is_flagged(self):
        d = decide_memory_action("I live in Coimbatore")
        self.assertTrue(d.should_remember)
        self.assertEqual(d.category, "identity")

    def test_plain_question_is_not_stored(self):
        d = decide_memory_action("What is Python?")
        self.assertFalse(d.should_remember)

    def test_question_without_question_mark_is_not_stored(self):
        d = decide_memory_action("What is the capital of France")
        self.assertFalse(d.should_remember)

    def test_unrelated_statement_is_not_stored(self):
        d = decide_memory_action("The weather looks nice today")
        self.assertFalse(d.should_remember)

    def test_secret_is_never_flagged_even_if_phrased_as_preference(self):
        d = decide_memory_action("My password is hunter2")
        self.assertFalse(d.should_remember)
        self.assertEqual(d.category, "rejected")


class TestSecretDetection(unittest.TestCase):
    def test_password_detected(self):
        self.assertTrue(contains_secret("my password is hunter2"))

    def test_api_key_detected(self):
        self.assertTrue(contains_secret("here's my api key: abc123xyz"))

    def test_sk_style_token_detected(self):
        self.assertTrue(contains_secret("use sk-ABCDEFGHIJ1234567890 for this"))

    def test_normal_sentence_not_flagged(self):
        self.assertFalse(contains_secret("I really like hiking on weekends"))

    def test_credit_card_detected(self):
        self.assertTrue(contains_secret("my credit card number is 4111111111111111"))


class TestLongTermMemorySecretRejection(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.mem = LongTermMemory(os.path.join(self.tmpdir, "mem.db"))

    def tearDown(self):
        self.mem.close()

    def test_explicit_remember_of_secret_is_rejected(self):
        with self.assertRaises(MemoryRejectedError):
            self.mem.remember("my password is hunter2")
        self.assertEqual(self.mem.list_all(), [])

    def test_explicit_remember_of_api_key_is_rejected(self):
        with self.assertRaises(MemoryRejectedError):
            self.mem.remember("my api key is sk-ABCDEFGHIJ1234567890")
        self.assertEqual(self.mem.list_all(), [])

    def test_normal_remember_still_works(self):
        record = self.mem.remember("I prefer simple explanations")
        self.assertIsNotNone(record.id)
        self.assertEqual(len(self.mem.list_all()), 1)

    def test_update_rejects_secret_content(self):
        record = self.mem.remember("harmless fact")
        with self.assertRaises(MemoryRejectedError):
            self.mem.update(record.id, content="my password is hunter2")


if __name__ == "__main__":
    unittest.main()
