import ast
import unittest

from tools.calculator import (
    CalculatorError,
    MAX_EXPONENT,
    MAX_EXPRESSION_LENGTH,
    MAX_INT_LITERAL,
    MAX_NESTING_DEPTH,
    MAX_OPERATIONS,
    _OperationBudget,
    _eval_node,
    run,
    safe_calculate,
)


class TestNormalEngineeringCalculations(unittest.TestCase):
    """These must keep working after hardening — hardening that breaks
    ordinary use is not a successful hardening pass."""

    def test_addition(self):
        self.assertEqual(safe_calculate("2 + 2"), 4)

    def test_multiplication(self):
        self.assertEqual(safe_calculate("25 * 16"), 400)

    def test_division(self):
        self.assertEqual(safe_calculate("100 / 4"), 25.0)

    def test_power(self):
        self.assertEqual(safe_calculate("10 ** 3"), 1000)

    def test_sqrt(self):
        self.assertEqual(safe_calculate("sqrt(25)"), 5.0)

    def test_sin_degrees(self):
        self.assertAlmostEqual(safe_calculate("sin(30)"), 0.5, places=5)

    def test_cos_degrees(self):
        self.assertAlmostEqual(safe_calculate("cos(60)"), 0.5, places=5)

    def test_log10(self):
        self.assertAlmostEqual(safe_calculate("log10(100)"), 2.0)

    def test_reasonable_long_chain_of_additions(self):
        expr = "+".join(["1"] * 100)  # 99 operations, well within limits
        self.assertEqual(safe_calculate(expr), 100)

    def test_reasonable_exponent(self):
        self.assertEqual(safe_calculate("2 ** 10"), 1024)

    def test_moderately_large_but_reasonable_result(self):
        self.assertEqual(safe_calculate("2 ** 100"), 2 ** 100)


class TestHugeExponent(unittest.TestCase):
    def test_huge_exponent_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("2 ** 1000000")

    def test_huge_exponent_rejected_fast(self):
        import time
        start = time.time()
        with self.assertRaises(CalculatorError):
            safe_calculate("2 ** 999999999999")
        self.assertLess(time.time() - start, 1.0)

    def test_exponent_at_limit_boundary_allowed(self):
        # Small base at the exponent boundary should still be computable
        # quickly, since the *estimated result size* check (not just the
        # bare exponent check) is what ultimately gates this.
        try:
            safe_calculate(f"1 ** {MAX_EXPONENT}")
        except CalculatorError:
            self.fail("1 ** MAX_EXPONENT should never be rejected (result is always 1)")

    def test_huge_base_with_moderate_exponent_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("999999999999999999999999999999999999999999999999999999 ** 500")


class TestHugeIntegerLiteral(unittest.TestCase):
    def test_huge_literal_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("9" * 40)

    def test_literal_at_limit_allowed(self):
        try:
            safe_calculate(str(MAX_INT_LITERAL))
        except CalculatorError:
            self.fail("A literal exactly at MAX_INT_LITERAL should be allowed")

    def test_literal_just_over_limit_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate(str(MAX_INT_LITERAL * 10))


class TestDeeplyNestedExpression(unittest.TestCase):
    def test_pathologically_deep_ast_rejected(self):
        node = ast.Constant(value=1)
        for _ in range(MAX_NESTING_DEPTH + 50):
            node = ast.BinOp(left=node, op=ast.Add(), right=ast.Constant(value=1))
        tree = ast.Expression(body=node)
        ast.fix_missing_locations(tree)
        with self.assertRaises(CalculatorError):
            _eval_node(tree, _OperationBudget())

    def test_moderate_depth_within_limit_allowed(self):
        node = ast.Constant(value=1)
        for _ in range(20):
            node = ast.BinOp(left=node, op=ast.Add(), right=ast.Constant(value=1))
        tree = ast.Expression(body=node)
        ast.fix_missing_locations(tree)
        result = _eval_node(tree, _OperationBudget())
        self.assertEqual(result, 21)

    def test_does_not_raise_python_recursion_error(self):
        # Even a deep AST must surface as a clean CalculatorError, never an
        # uncaught RecursionError that could crash JARVIS. (300 levels is
        # already far beyond MAX_NESTING_DEPTH and — this is the point —
        # such a tree could never actually arise from real user input, since
        # MAX_EXPRESSION_LENGTH bounds how deep a parsed string can nest long
        # before safe_calculate ever reaches this function; this test proves
        # the *guard itself* degrades cleanly, using ast helpers that would
        # themselves recurse further than is safe at more extreme depths.)
        node = ast.Constant(value=1)
        for _ in range(300):
            node = ast.BinOp(left=node, op=ast.Add(), right=ast.Constant(value=1))
        tree = ast.Expression(body=node)
        ast.fix_missing_locations(tree)
        try:
            _eval_node(tree, _OperationBudget())
            self.fail("Should have raised CalculatorError")
        except CalculatorError:
            pass  # expected
        except RecursionError:
            self.fail("A pathological expression must never raise a raw RecursionError")


class TestOperationCount(unittest.TestCase):
    def test_many_operations_in_shallow_wide_tree_rejected(self):
        def balanced_sum(n):
            if n == 1:
                return ast.Constant(value=1)
            return ast.BinOp(left=balanced_sum(n // 2), op=ast.Add(),
                              right=balanced_sum(n - n // 2))
        node = balanced_sum(MAX_OPERATIONS + 100)
        tree = ast.Expression(body=node)
        ast.fix_missing_locations(tree)
        with self.assertRaises(CalculatorError):
            _eval_node(tree, _OperationBudget())


class TestExtremelyLongExpression(unittest.TestCase):
    def test_long_expression_rejected(self):
        expr = "1" * (MAX_EXPRESSION_LENGTH + 50)
        with self.assertRaises(CalculatorError):
            safe_calculate(expr)

    def test_expression_at_length_limit_boundary(self):
        # Exactly at the limit should not raise the length error specifically
        # (it may still be invalid syntax, but not for being "too long").
        expr = "1" * MAX_EXPRESSION_LENGTH
        try:
            safe_calculate(expr)
        except CalculatorError as e:
            self.assertNotIn("too long", str(e))


class TestInvalidSyntax(unittest.TestCase):
    def test_incomplete_expression(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("2 +")

    def test_garbage_input(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("!!! not math @@@")

    def test_mismatched_parens(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("(2 + 3")


class TestDivisionByZero(unittest.TestCase):
    def test_division_by_zero(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("5 / 0")

    def test_floor_division_by_zero(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("5 // 0")

    def test_modulus_by_zero(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("5 % 0")


class TestFunctionCallSafety(unittest.TestCase):
    def test_unsupported_function_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("__import__('os').system('ls')")

    def test_arbitrary_function_name_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("open('/etc/passwd')")

    def test_wrong_arg_count_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("sqrt(4, 9)")

    def test_sqrt_of_negative_rejected_cleanly(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("sqrt(-1)")


class TestRunNeverCrashes(unittest.TestCase):
    """The tool-level run() wrapper must always return a dict, never raise."""

    def test_run_returns_error_dict_not_exception(self):
        result = run("2 ** 1000000")
        self.assertFalse(result["ok"])
        self.assertIn("error", result)

    def test_run_returns_ok_dict_for_valid_expression(self):
        result = run("2 + 2")
        self.assertTrue(result["ok"])
        self.assertEqual(result["result"], 4)


if __name__ == "__main__":
    unittest.main()
