import json
import socket
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from providers.base import AIProvider, ProviderResponseError, ProviderUnavailableError
from providers.factory import UnknownProviderError, get_provider, get_provider_from_config
from providers.llamacpp import LlamaCppProvider
from providers.local import LocalAIProvider
from providers.ollama import OllamaProvider
from config.config import JarvisConfig


class TestProviderFactory(unittest.TestCase):
    def test_default_local_provider(self):
        provider = get_provider("local")
        self.assertIsInstance(provider, LocalAIProvider)
        self.assertFalse(provider.is_available())

    def test_unknown_provider_raises(self):
        with self.assertRaises(UnknownProviderError):
            get_provider("some_cloud_vendor")

    def test_ollama_requires_model(self):
        with self.assertRaises(ValueError):
            get_provider("ollama", base_url="http://localhost:11434")

    def test_ollama_constructs_with_model(self):
        provider = get_provider("ollama", model="llama3.2", base_url="http://localhost:11434")
        self.assertIsInstance(provider, OllamaProvider)

    def test_llamacpp_constructs(self):
        provider = get_provider("llamacpp", base_url="http://localhost:8080")
        self.assertIsInstance(provider, LlamaCppProvider)

    def test_config_driven_selection(self):
        cfg = JarvisConfig(ai_provider="ollama", ai_model="llama3.2",
                            ai_base_url="http://localhost:11434")
        provider = get_provider_from_config(cfg)
        self.assertEqual(provider.name, "ollama")


class TestProviderUnavailability(unittest.TestCase):
    """These never require an actual server — every case is either a
    provider deliberately given an unreachable address, or the honest
    'local' placeholder — so the suite runs the same with or without
    network access."""

    def test_local_provider_generate_raises_cleanly(self):
        provider = LocalAIProvider()
        with self.assertRaises(ProviderUnavailableError):
            provider.generate("hello")

    def test_ollama_unreachable_server_is_available_false(self):
        provider = OllamaProvider(model="llama3.2", base_url="http://localhost:1",
                                   request_timeout=1.0)
        self.assertFalse(provider.is_available())

    def test_ollama_unreachable_server_generate_raises_cleanly(self):
        provider = OllamaProvider(model="llama3.2", base_url="http://localhost:1",
                                   request_timeout=1.0)
        with self.assertRaises(ProviderUnavailableError):
            provider.generate("hello")

    def test_llamacpp_unreachable_server_is_available_false(self):
        provider = LlamaCppProvider(base_url="http://localhost:2", request_timeout=1.0)
        self.assertFalse(provider.is_available())

    def test_llamacpp_unreachable_server_generate_raises_cleanly(self):
        provider = LlamaCppProvider(base_url="http://localhost:2", request_timeout=1.0)
        with self.assertRaises(ProviderUnavailableError):
            provider.generate("hello")


class _JsonStubProvider(AIProvider):
    name = "stub"

    def __init__(self, text):
        self.text = text

    def is_available(self):
        return True

    def generate(self, prompt, **kwargs):
        return self.text

    def chat(self, messages, **kwargs):
        return self.text

    def summarize(self, text, **kwargs):
        return self.text

    def classify(self, text, labels, **kwargs):
        return labels[0] if labels else ""


class TestGenerateJsonHelper(unittest.TestCase):
    def test_parses_clean_json(self):
        provider = _JsonStubProvider('{"a": 1, "b": "two"}')
        self.assertEqual(provider.generate_json("prompt"), {"a": 1, "b": "two"})

    def test_salvages_json_wrapped_in_prose(self):
        provider = _JsonStubProvider('Sure, here you go:\n{"a": 1}\nHope that helps!')
        self.assertEqual(provider.generate_json("prompt"), {"a": 1})

    def test_raises_on_non_json(self):
        provider = _JsonStubProvider("not json at all")
        with self.assertRaises(ProviderResponseError):
            provider.generate_json("prompt")


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _StallingHandler(BaseHTTPRequestHandler):
    """Accepts the connection but never writes a response — forces a real
    client-side timeout rather than an instant connection-refused error."""

    def do_GET(self):
        time.sleep(5)  # longer than any test's configured timeout

    def do_POST(self):
        time.sleep(5)

    def log_message(self, *args):
        pass  # keep test output quiet


class _JsonHandler(BaseHTTPRequestHandler):
    """A minimal real HTTP server standing in for Ollama/llama.cpp, so
    provider request/response handling is tested against an actual socket
    instead of only against unreachable addresses."""

    response_body = b'{"response": "Entropy is a measure of disorder."}'
    status_code = 200
    content_type = "application/json"

    def _respond(self):
        self.send_response(self.status_code)
        self.send_header("Content-Type", self.content_type)
        self.end_headers()
        self.wfile.write(self.response_body)

    def do_GET(self):
        self._respond()

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        self.rfile.read(length)  # drain the request body
        self._respond()

    def log_message(self, *args):
        pass


class _RunningServer:
    """Context manager that runs a BaseHTTPRequestHandler on a free local
    port in a background thread, and always shuts it down cleanly."""

    def __init__(self, handler_cls):
        self.handler_cls = handler_cls
        self.port = _free_port()
        self.server = HTTPServer(("127.0.0.1", self.port), handler_cls)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)

    def __enter__(self):
        self.thread.start()
        return f"http://127.0.0.1:{self.port}"

    def __exit__(self, *exc):
        self.server.shutdown()
        self.server.server_close()


class TestProviderAgainstRealLocalServer(unittest.TestCase):
    """Exercises actual HTTP request/response handling — a real socket, real
    JSON parsing, real timeout behavior — without depending on Ollama or
    llama.cpp actually being installed anywhere."""

    def test_successful_generation_ollama_shape(self):
        with _RunningServer(_JsonHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=3.0)
            self.assertTrue(provider.is_available())
            result = provider.generate("What is entropy?")
            self.assertIn("disorder", result)

    def test_successful_generation_llamacpp_shape(self):
        class _LlamaCppJsonHandler(_JsonHandler):
            response_body = b'{"content": "Entropy is a measure of disorder."}'

        with _RunningServer(_LlamaCppJsonHandler) as base_url:
            provider = LlamaCppProvider(base_url=base_url, request_timeout=3.0)
            result = provider.generate("What is entropy?")
            self.assertIn("disorder", result)

    def test_malformed_json_response_raises_provider_unavailable(self):
        class _GarbageHandler(_JsonHandler):
            response_body = b"this is not json at all {{{"

        with _RunningServer(_GarbageHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=3.0)
            with self.assertRaises(ProviderUnavailableError):
                provider.generate("hello")

    def test_http_error_status_raises_provider_unavailable(self):
        class _ServerErrorHandler(_JsonHandler):
            status_code = 500
            response_body = b'{"error": "internal error"}'

        with _RunningServer(_ServerErrorHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=3.0)
            # A 500 still has a JSON body our parser can read; what matters
            # is that no exception escapes uncaught either way.
            try:
                provider.generate("hello")
            except ProviderUnavailableError:
                pass  # acceptable — treated as unavailable

    def test_real_timeout_raises_provider_unavailable(self):
        with _RunningServer(_StallingHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=0.5)
            start = time.time()
            with self.assertRaises(ProviderUnavailableError):
                provider.generate("hello")
            elapsed = time.time() - start
            self.assertLess(elapsed, 3.0, "should time out quickly, not hang")

    def test_real_timeout_is_available_returns_false_quickly(self):
        with _RunningServer(_StallingHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=0.5)
            start = time.time()
            self.assertFalse(provider.is_available())
            self.assertLess(time.time() - start, 3.0)

    def test_multi_turn_chat_against_real_server(self):
        class _ChatHandler(_JsonHandler):
            response_body = b'{"message": {"role": "assistant", "content": "Yes, steam turbines have blades, a rotor, and a casing."}}'

        with _RunningServer(_ChatHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=3.0)
            messages = [
                {"role": "user", "content": "Tell me about steam turbines."},
                {"role": "assistant", "content": "They convert steam energy into rotation."},
                {"role": "user", "content": "What are their main parts?"},
            ]
            result = provider.chat(messages)
            self.assertIn("blades", result)

    def test_system_instruction_reaches_ollama_request_payload(self):
        captured = {}

        class _CapturingHandler(_JsonHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                captured.update(json.loads(self.rfile.read(length)))
                self._respond()

        with _RunningServer(_CapturingHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=3.0)
            provider.generate("hello", system="You are JARVIS, a concise assistant.")
        self.assertEqual(captured.get("system"), "You are JARVIS, a concise assistant.")

    def test_configurable_temperature_and_max_tokens_reach_request_payload(self):
        captured = {}

        class _CapturingHandler(_JsonHandler):
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                captured.update(json.loads(self.rfile.read(length)))
                self._respond()

        with _RunningServer(_CapturingHandler) as base_url:
            provider = OllamaProvider(model="llama3.2", base_url=base_url, request_timeout=3.0)
            provider.generate("hello", temperature=0.2, max_tokens=64)
        self.assertEqual(captured["options"]["temperature"], 0.2)
        self.assertEqual(captured["options"]["num_predict"], 64)

    def test_system_instruction_prepended_to_llamacpp_chat(self):
        captured = {}

        class _CapturingHandler(_JsonHandler):
            response_body = b'{"content": "ok"}'
            def do_POST(self):
                length = int(self.headers.get("Content-Length", 0))
                captured.update(json.loads(self.rfile.read(length)))
                self._respond()

        with _RunningServer(_CapturingHandler) as base_url:
            provider = LlamaCppProvider(base_url=base_url, request_timeout=3.0)
            provider.chat([{"role": "user", "content": "hi"}], system="Be concise.")
        self.assertIn("Be concise.", captured["prompt"])


if __name__ == "__main__":
    unittest.main()
