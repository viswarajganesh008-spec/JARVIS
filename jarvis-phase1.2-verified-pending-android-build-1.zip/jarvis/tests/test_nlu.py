import json
import unittest

from core.intent import IntentType
from core.nlu import classify_with_fallback
from providers.base import AIProvider
from safety.risk_classifier import RiskLevel


class StubProvider(AIProvider):
    """A provider whose generate() output is controlled per-test."""
    name = "stub"

    def __init__(self, response_text="{}", available=True):
        self.response_text = response_text
        self.available = available
        self.calls = 0

    def is_available(self):
        return self.available

    def generate(self, prompt, **kwargs):
        self.calls += 1
        return self.response_text

    def chat(self, messages, **kwargs):
        return self.response_text

    def summarize(self, text, **kwargs):
        return self.response_text

    def classify(self, text, labels, **kwargs):
        return labels[0] if labels else ""


class LyingProvider(StubProvider):
    """Always claims a dangerous action is safe conversation."""
    def __init__(self):
        super().__init__(response_text=json.dumps({
            "intent_type": "CONVERSATION",
            "confidence": 0.99,
            "entities": {},
            "payload": "delete all my files",
            "requires_confirmation": False,
            "risk_level": "LOW",
        }))


class TestRuleBasedConfidence(unittest.TestCase):
    def test_high_confidence_no_fallback_needed(self):
        provider = StubProvider()
        result = classify_with_fallback("calculate 25 * 36", provider=provider,
                                         confidence_threshold=0.55)
        self.assertEqual(result.type, IntentType.CALCULATION)
        self.assertEqual(result.source, "rule_based")
        self.assertEqual(provider.calls, 0)  # never consulted — confidence was high enough

    def test_ambiguous_text_triggers_fallback(self):
        provider = StubProvider(response_text=json.dumps({
            "intent_type": "CONVERSATION", "confidence": 0.8, "entities": {}, "payload": "hi there",
        }))
        result = classify_with_fallback("hi there", provider=provider, confidence_threshold=0.9)
        self.assertEqual(provider.calls, 1)
        self.assertEqual(result.source, "ai_fallback")

    def test_no_provider_falls_back_to_rule_based_result(self):
        result = classify_with_fallback("hi there", provider=None, confidence_threshold=0.99)
        self.assertEqual(result.source, "rule_based")

    def test_unavailable_provider_falls_back_to_rule_based_result(self):
        provider = StubProvider(available=False)
        result = classify_with_fallback("hi there", provider=provider, confidence_threshold=0.99)
        self.assertEqual(result.source, "rule_based")
        self.assertEqual(provider.calls, 0)


class TestMalformedModelOutput(unittest.TestCase):
    def test_non_json_output_falls_back_to_rule_based(self):
        provider = StubProvider(response_text="I think this is conversational, not JSON.")
        result = classify_with_fallback("hi there", provider=provider, confidence_threshold=0.9)
        self.assertEqual(result.source, "rule_based")

    def test_invalid_intent_type_falls_back_to_rule_based(self):
        provider = StubProvider(response_text=json.dumps({
            "intent_type": "MAKE_COFFEE", "confidence": 0.9, "payload": "hi",
        }))
        result = classify_with_fallback("hi there", provider=provider, confidence_threshold=0.9)
        self.assertEqual(result.source, "rule_based")

    def test_missing_confidence_defaults_safely(self):
        provider = StubProvider(response_text=json.dumps({"intent_type": "QUESTION", "payload": "x"}))
        result = classify_with_fallback("what is up with this", provider=provider,
                                         confidence_threshold=0.9)
        self.assertIsInstance(result.confidence, float)


class TestSafetyCannotBeBypassed(unittest.TestCase):
    """Regression coverage for a real bug found during Phase 1.1 development:
    an AI fallback classification that mislabels a HIGH-risk message as
    CONVERSATION (with requires_confirmation=False) must not be trusted —
    risk is authoritative over the model's claimed intent type."""

    def test_lying_provider_cannot_downgrade_dangerous_action(self):
        result = classify_with_fallback("delete all my files", provider=LyingProvider(),
                                         confidence_threshold=0.99)
        self.assertEqual(result.type, IntentType.DANGEROUS_OPERATION)
        self.assertEqual(result.risk_level, RiskLevel.HIGH)
        self.assertTrue(result.needs_confirmation)

    def test_lying_provider_cannot_downgrade_critical_action(self):
        provider = StubProvider(response_text=json.dumps({
            "intent_type": "CONVERSATION", "confidence": 0.99, "entities": {},
            "payload": "perform a factory reset", "requires_confirmation": False,
        }))
        result = classify_with_fallback("perform a factory reset", provider=provider,
                                         confidence_threshold=0.99)
        self.assertEqual(result.type, IntentType.DANGEROUS_OPERATION)
        self.assertEqual(result.risk_level, RiskLevel.CRITICAL)
        self.assertTrue(result.needs_confirmation)

    def test_genuinely_low_risk_message_unaffected(self):
        result = classify_with_fallback("tell me a fun fact", provider=LyingProvider(),
                                         confidence_threshold=0.99)
        self.assertEqual(result.risk_level, RiskLevel.LOW)
        self.assertFalse(result.needs_confirmation)

    def test_model_claimed_values_preserved_only_for_audit_trail(self):
        result = classify_with_fallback("delete all my files", provider=LyingProvider(),
                                         confidence_threshold=0.99)
        # The model's dishonest claim is visible for debugging/audit...
        self.assertIn("model_claimed", result.reasoning_context)
        # ...but never used to set the actual safety fields.
        self.assertTrue(result.needs_confirmation)


class TestSpecExampleSchema(unittest.TestCase):
    """The task brief gave an exact example structured-output shape using
    'intent' (not 'intent_type') and a list of entity strings — confirm the
    classifier accepts that shape as well as its own documented one."""

    def test_spec_example_schema_parses_correctly(self):
        provider = StubProvider(response_text=json.dumps({
            "intent": "KNOWLEDGE_QUERY",
            "confidence": 0.94,
            "entities": ["entropy"],
            "action": None,
            "parameters": {},
        }))
        result = classify_with_fallback("tell me about that", provider=provider,
                                         confidence_threshold=0.99)
        self.assertEqual(result.type, IntentType.KNOWLEDGE_QUERY)
        self.assertEqual(result.confidence, 0.94)
        self.assertEqual(result.entities, {"items": ["entropy"]})
        self.assertEqual(result.payload, "entropy")
        self.assertEqual(result.source, "ai_fallback")

    def test_malformed_tool_style_request_does_not_bypass_intent_validation(self):
        # A model trying to smuggle a tool call through an unrecognized
        # shape must fall back to the rule-based classification, not crash
        # or silently succeed with garbage fields.
        provider = StubProvider(response_text=json.dumps({
            "tool": "delete_file", "arguments": {"path": "/etc/passwd"},
        }))
        result = classify_with_fallback("do something", provider=provider,
                                         confidence_threshold=0.99)
        self.assertEqual(result.source, "rule_based")


if __name__ == "__main__":
    unittest.main()
