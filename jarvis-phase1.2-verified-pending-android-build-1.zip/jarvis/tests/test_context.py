import unittest

from core.context import ContextManager


class TestContextManager(unittest.TestCase):
    def setUp(self):
        self.ctx = ContextManager(max_messages=10)

    def test_question_then_followup_pronoun(self):
        self.ctx.update_from_user_message("Who invented the telephone?")
        self.assertIsNotNone(self.ctx.state.current_subject)
        resolved = self.ctx.resolve_references("When was he born?")
        self.assertNotIn(" he ", f" {resolved} ")

    def test_topic_continuity(self):
        self.ctx.update_from_user_message("Explain entropy")
        topic_after_first = self.ctx.state.current_topic
        self.ctx.update_from_jarvis_message("Entropy is a measure of disorder.")
        self.assertEqual(self.ctx.state.current_topic, topic_after_first)

    def test_it_reference_resolution(self):
        self.ctx.update_from_user_message("Tell me about steam turbines")
        resolved = self.ctx.resolve_references("Explain it simply")
        self.assertNotIn(" it ", f" {resolved} ")

    def test_history_bounded(self):
        for i in range(15):
            self.ctx.update_from_user_message(f"message {i}")
        self.assertLessEqual(len(self.ctx.short_term.turns), 10)

    def test_snapshot_contains_expected_keys(self):
        self.ctx.update_from_user_message("Explain gravity")
        snap = self.ctx.snapshot()
        self.assertIn("current_topic", snap)
        self.assertIn("recent_entities", snap)

    def test_their_reference_resolution(self):
        self.ctx.update_from_user_message("Tell me about steam turbines")
        resolved = self.ctx.resolve_references("What are their main parts?")
        self.assertNotIn(" their ", f" {resolved} ")

    def test_explicit_target_overrides_current_state(self):
        self.ctx.update_from_user_message("Tell me about entropy")
        # Even though current_subject is now "entropy", an explicit target
        # (as the orchestrator passes the *prior* turn's subject) wins.
        resolved = self.ctx.resolve_references("Explain it simply", target="steam turbines")
        self.assertIn("steam turbines", resolved)


class TestPendingTask(unittest.TestCase):
    def setUp(self):
        self.ctx = ContextManager(max_messages=10)

    def test_no_pending_task_initially(self):
        self.assertFalse(self.ctx.has_pending_task())

    def test_start_and_fill_pending_task(self):
        self.ctx.start_pending_task("circle_area", "circle_area", ["radius"])
        self.assertTrue(self.ctx.has_pending_task())
        task = self.ctx.state.pending_task
        self.assertEqual(task.next_missing_slot(), "radius")
        self.ctx.fill_pending_slot("radius", 5.0)
        self.assertTrue(task.is_complete())
        self.assertIsNone(task.next_missing_slot())

    def test_multi_slot_task_tracks_next_missing(self):
        self.ctx.start_pending_task("rectangle_area", "rectangle_area", ["width", "height"])
        task = self.ctx.state.pending_task
        self.assertEqual(task.next_missing_slot(), "width")
        self.ctx.fill_pending_slot("width", 3.0)
        self.assertEqual(task.next_missing_slot(), "height")
        self.ctx.fill_pending_slot("height", 4.0)
        self.assertTrue(task.is_complete())

    def test_clear_pending_task(self):
        self.ctx.start_pending_task("circle_area", "circle_area", ["radius"])
        self.ctx.clear_pending_task()
        self.assertFalse(self.ctx.has_pending_task())

    def test_record_turn_outcome(self):
        self.ctx.record_turn_outcome("QUESTION", "Some answer.")
        snap = self.ctx.snapshot()
        self.assertEqual(snap["previous_intent_type"], "QUESTION")
        self.assertEqual(snap["previous_response"], "Some answer.")


class TestBoundedPromptContext(unittest.TestCase):
    def setUp(self):
        self.ctx = ContextManager(max_messages=20)

    def test_history_is_capped_even_if_more_exists(self):
        for i in range(10):
            self.ctx.update_from_user_message(f"message {i}")
            self.ctx.update_from_jarvis_message(f"reply {i}")
        prompt_ctx = self.ctx.build_prompt_context(max_history_turns=3)
        self.assertLessEqual(len(prompt_ctx["recent_history"]), 3)

    def test_memory_and_knowledge_are_bounded(self):
        many_memories = [f"fact {i}" for i in range(20)]
        many_knowledge = [f"snippet {i}" for i in range(20)]
        prompt_ctx = self.ctx.build_prompt_context(memory_items=many_memories,
                                                     knowledge_snippets=many_knowledge)
        self.assertLessEqual(len(prompt_ctx["relevant_memory"]), 5)
        self.assertLessEqual(len(prompt_ctx["relevant_knowledge"]), 3)


if __name__ == "__main__":
    unittest.main()
