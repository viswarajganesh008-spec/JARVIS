import unittest

from tools.calculator import CalculatorError, safe_calculate


class TestCalculator(unittest.TestCase):
    def test_addition(self):
        self.assertEqual(safe_calculate("2 + 2"), 4)

    def test_multiplication(self):
        self.assertEqual(safe_calculate("25 * 36"), 900)

    def test_division(self):
        self.assertEqual(safe_calculate("10 / 2"), 5.0)

    def test_power(self):
        self.assertEqual(safe_calculate("2 ^ 10".replace("^", "**")), 1024)

    def test_parentheses(self):
        self.assertEqual(safe_calculate("(5 + 3) * 2"), 16)

    def test_negative_values(self):
        self.assertEqual(safe_calculate("-5 + 3"), -2)
        self.assertEqual(safe_calculate("-(2 + 3)"), -5)

    def test_modulus(self):
        self.assertEqual(safe_calculate("10 % 3"), 1)

    def test_division_by_zero(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("5 / 0")

    def test_invalid_expression_rejected(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("2 + ")

    def test_rejects_non_math_code(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("__import__('os').system('ls')")

    def test_rejects_names(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("os.system('ls')")

    def test_empty_expression(self):
        with self.assertRaises(CalculatorError):
            safe_calculate("")


if __name__ == "__main__":
    unittest.main()
