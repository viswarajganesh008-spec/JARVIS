import os
import tempfile
import unittest

from knowledge.ingestion import ingest_directory, ingest_file
from knowledge.search import KnowledgeIndex
from knowledge.verification import verify_and_format


class TestKnowledgeIngestion(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def _write(self, name: str, content: str) -> str:
        path = os.path.join(self.tmpdir, name)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        return path

    def test_import_txt_document(self):
        path = self._write("notes.txt", "Steam turbines convert thermal energy into "
                                          "mechanical work using pressurized steam.")
        doc = ingest_file(path)
        self.assertEqual(doc.name, "notes.txt")
        self.assertTrue(len(doc.chunks) >= 1)
        self.assertIn("steam", doc.chunks[0].text.lower())

    def test_import_markdown_document(self):
        path = self._write("readme.md", "# Entropy\n\nEntropy is a measure of disorder "
                                          "in a thermodynamic system.")
        doc = ingest_file(path)
        self.assertEqual(doc.file_type, "md")

    def test_import_json_document(self):
        path = self._write("data.json", '{"topic": "entropy", "definition": "disorder measure"}')
        doc = ingest_file(path)
        self.assertTrue(any("entropy" in c.text.lower() for c in doc.chunks))

    def test_import_csv_document(self):
        path = self._write("data.csv", "term,definition\nentropy,measure of disorder\n")
        doc = ingest_file(path)
        self.assertTrue(any("entropy" in c.text.lower() for c in doc.chunks))

    def test_ingest_directory_handles_missing_dir(self):
        docs = ingest_directory(os.path.join(self.tmpdir, "does_not_exist"))
        self.assertEqual(docs, [])

    def test_unsupported_extension_raises(self):
        path = self._write("data.exe", "binary-ish content")
        with self.assertRaises(ValueError):
            ingest_file(path)


class TestKnowledgeSearch(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.index_path = os.path.join(self.tmpdir, "index.json")
        self.index = KnowledgeIndex(
            knowledge_directory=os.path.join(self.tmpdir, "kb"),
            index_path=self.index_path,
        )
        self.index.add_document_text(
            "thermo.txt",
            "Entropy is a measure of disorder in a thermodynamic system. "
            "It tends to increase over time in an isolated system.",
        )

    def test_search_returns_relevant_chunk(self):
        results = self.index.search("entropy")
        self.assertTrue(len(results) > 0)
        self.assertIn("entropy", results[0].text.lower())
        self.assertEqual(results[0].doc_name, "thermo.txt")

    def test_search_no_match_returns_empty(self):
        results = self.index.search("photosynthesis chlorophyll")
        self.assertEqual(results, [])

    def test_verification_grounded(self):
        results = self.index.search("entropy disorder")
        verified = verify_and_format(results)
        self.assertTrue(verified.grounded)
        self.assertEqual(verified.source_doc, "thermo.txt")

    def test_verification_ungrounded_when_no_results(self):
        verified = verify_and_format([])
        self.assertFalse(verified.grounded)
        self.assertIsNone(verified.source_doc)


if __name__ == "__main__":
    unittest.main()
