"""
JARVIS Core — Android development bridge entry point.

Run with: python run_api.py
Then point the Android app's dev config at:
    http://10.0.2.2:8765   (Android emulator -> host machine)
    http://<your-lan-ip>:8765   (physical device on the same network)

Override host/port with env vars JARVIS_API_HOST / JARVIS_API_PORT if
needed (e.g. to bind 0.0.0.0 for a physical device on the LAN).
"""

from __future__ import annotations

import logging
import os

from api.server import run

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    host = os.environ.get("JARVIS_API_HOST", "127.0.0.1")
    port = int(os.environ.get("JARVIS_API_PORT", "8765"))
    print(f"JARVIS Android bridge starting on http://{host}:{port}")
    run(host=host, port=port)
