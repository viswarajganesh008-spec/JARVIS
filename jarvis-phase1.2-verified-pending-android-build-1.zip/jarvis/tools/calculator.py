"""
Safe calculator tool.

Deliberately does NOT use eval()/exec() on user input. Instead it
parses the expression into a Python AST and walks it, only allowing a
small, explicit whitelist of numeric operators and math functions.
Anything else (names, arbitrary calls, attribute access, subscripts,
comprehensions, etc.) is rejected before any evaluation happens.

Hardened against resource-exhaustion attacks (Phase 1.1 final
hardening pass): Python integers are arbitrary-precision, so something
syntactically "valid" like `2 ** 9999999999` or a 500-digit literal can
consume unbounded CPU/memory before ever reaching a result. Every limit
below is checked *before* the expensive operation runs, not after —
these are pre-checks, not post-hoc cleanup of a hung process.
"""

from __future__ import annotations

import ast
import math
import operator
from typing import Union

Number = Union[int, float]

# --- Hardening limits ---------------------------------------------------
MAX_EXPRESSION_LENGTH = 300       # characters, checked before parsing
MAX_NESTING_DEPTH = 150           # AST depth, checked while walking — high
                                   # enough that a normal long chain of
                                   # additions ("1+1+1+...") within the
                                   # length limit above is never falsely
                                   # rejected, since Python's left-associative
                                   # parsing makes such chains deeply *nested*
                                   # even though they're computationally cheap
MAX_OPERATIONS = 150              # total BinOp/UnaryOp/Call nodes allowed
MAX_EXPONENT = 1000               # |exponent| ceiling for **
MAX_INT_LITERAL = 10 ** 18        # ceiling for any single numeric literal
MAX_RESULT_BITS = 4096            # ~1233 decimal digits ceiling for int results

_ALLOWED_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.FloorDiv: operator.floordiv,
}

_ALLOWED_UNARYOPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}

# Whitelisted single-argument math functions. Trig functions take/return
# degrees (the convention a simple calculator's users expect), everything
# else matches its math-module namesake.
_ALLOWED_FUNCS = {
    "sqrt": math.sqrt,
    "abs": abs,
    "ceil": math.ceil,
    "floor": math.floor,
    "log": math.log,       # natural log
    "log10": math.log10,
    "log2": math.log2,
    "sin": lambda x: math.sin(math.radians(x)),
    "cos": lambda x: math.cos(math.radians(x)),
    "tan": lambda x: math.tan(math.radians(x)),
    "asin": lambda x: math.degrees(math.asin(x)),
    "acos": lambda x: math.degrees(math.acos(x)),
    "atan": lambda x: math.degrees(math.atan(x)),
}


class CalculatorError(Exception):
    pass


class _OperationBudget:
    """Tracks operation count and nesting depth across one evaluation."""

    __slots__ = ("operations",)

    def __init__(self):
        self.operations = 0

    def charge(self):
        self.operations += 1
        if self.operations > MAX_OPERATIONS:
            raise CalculatorError(
                f"Expression is too complex (over {MAX_OPERATIONS} operations)."
            )


def _check_literal(value: Number) -> None:
    if abs(value) > MAX_INT_LITERAL:
        raise CalculatorError(
            f"Numeric literal is too large (limit is {MAX_INT_LITERAL:.0e})."
        )


def _check_pow_safety(base: Number, exponent: Number) -> None:
    if abs(exponent) > MAX_EXPONENT:
        raise CalculatorError(
            f"Exponent is too large (limit is {MAX_EXPONENT}) — this would take too "
            f"long or use too much memory to compute."
        )
    abs_base = abs(base)
    if abs_base not in (0, 1):
        # Estimate result bit-length as exponent * log2(base) WITHOUT computing
        # the actual power first — this is the check that prevents something
        # like 10**300 ** 900 (a huge base raised to a merely-large-looking
        # exponent) from ever reaching operator.pow.
        try:
            estimated_bits = abs(exponent) * math.log2(abs_base)
        except (ValueError, OverflowError):
            estimated_bits = float("inf")
        if estimated_bits > MAX_RESULT_BITS:
            raise CalculatorError(
                "That result would be far too large to compute "
                f"(estimated over {MAX_RESULT_BITS} bits)."
            )


def _check_result_size(value: Number) -> None:
    if isinstance(value, int) and not isinstance(value, bool):
        if value.bit_length() > MAX_RESULT_BITS:
            raise CalculatorError(
                f"Result is too large (over {MAX_RESULT_BITS} bits)."
            )
    elif isinstance(value, float):
        if not math.isfinite(value):
            raise CalculatorError("Result is not a finite number (overflow or invalid operation).")


def _eval_node(node: ast.AST, budget: _OperationBudget, depth: int = 0) -> Number:
    if depth > MAX_NESTING_DEPTH:
        raise CalculatorError(f"Expression is nested too deeply (limit is {MAX_NESTING_DEPTH}).")

    if isinstance(node, ast.Expression):
        return _eval_node(node.body, budget, depth + 1)

    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            _check_literal(node.value)
            return node.value
        raise CalculatorError(f"Unsupported constant: {node.value!r}")

    if isinstance(node, ast.BinOp):
        budget.charge()
        op_type = type(node.op)
        if op_type not in _ALLOWED_BINOPS:
            raise CalculatorError(f"Operator not allowed: {op_type.__name__}")
        left = _eval_node(node.left, budget, depth + 1)
        right = _eval_node(node.right, budget, depth + 1)
        if op_type in (ast.Div, ast.FloorDiv, ast.Mod) and right == 0:
            raise CalculatorError("Division by zero")
        if op_type is ast.Pow:
            _check_pow_safety(left, right)
        result = _ALLOWED_BINOPS[op_type](left, right)
        _check_result_size(result)
        return result

    if isinstance(node, ast.UnaryOp):
        budget.charge()
        op_type = type(node.op)
        if op_type not in _ALLOWED_UNARYOPS:
            raise CalculatorError(f"Unary operator not allowed: {op_type.__name__}")
        return _ALLOWED_UNARYOPS[op_type](_eval_node(node.operand, budget, depth + 1))

    if isinstance(node, ast.Call):
        budget.charge()
        if not isinstance(node.func, ast.Name) or node.func.id not in _ALLOWED_FUNCS:
            allowed = ", ".join(sorted(_ALLOWED_FUNCS))
            raise CalculatorError(
                f"Unsupported function call. Allowed functions: {allowed}."
            )
        if node.keywords:
            raise CalculatorError("Keyword arguments are not supported.")
        if len(node.args) != 1:
            raise CalculatorError(f"'{node.func.id}' takes exactly one argument.")
        arg = _eval_node(node.args[0], budget, depth + 1)
        try:
            result = _ALLOWED_FUNCS[node.func.id](arg)
        except (ValueError, OverflowError) as e:
            raise CalculatorError(f"'{node.func.id}({arg})' is not computable: {e}")
        _check_result_size(result)
        return result

    raise CalculatorError(f"Unsupported expression element: {type(node).__name__}")


def safe_calculate(expression: str) -> Number:
    """Evaluate a purely arithmetic expression safely.

    Supports: + - * / // % ** parentheses, unary +/-, ints and floats,
    and a whitelist of math functions (sqrt, sin, cos, tan, log, ...).
    Raises CalculatorError on anything else (names, unsupported calls,
    imports, attribute access, etc.), and on anything that would be
    unreasonably expensive to actually compute — see the MAX_* limits
    at the top of this module.
    """
    expression = expression.strip()
    if not expression:
        raise CalculatorError("Empty expression")
    if len(expression) > MAX_EXPRESSION_LENGTH:
        raise CalculatorError(
            f"Expression is too long (limit is {MAX_EXPRESSION_LENGTH} characters)."
        )
    try:
        tree = ast.parse(expression, mode="eval")
    except (SyntaxError, ValueError) as e:
        raise CalculatorError(f"Invalid expression: {e}")
    budget = _OperationBudget()
    result = _eval_node(tree, budget)
    _check_result_size(result)
    return result


CALCULATOR_TOOL_SCHEMA = {
    "name": "calculator",
    "description": "Evaluate a safe arithmetic expression (add, subtract, multiply, "
                    "divide, powers, modulus, parentheses, negative numbers, and "
                    "functions like sqrt/sin/cos/tan/log), within safe resource limits.",
    "input_schema": {"expression": "string"},
    "risk_level": "LOW",
    "permission_required": False,
}


def run(expression: str) -> dict:
    try:
        value = safe_calculate(expression)
        return {"ok": True, "result": value, "expression": expression}
    except CalculatorError as e:
        return {"ok": False, "error": str(e), "expression": expression}
    except RecursionError:
        # Belt-and-braces: MAX_NESTING_DEPTH should catch this first, but a
        # crafted expression must never be able to crash JARVIS via Python's
        # own recursion limit.
        return {"ok": False, "error": "Expression is nested too deeply.", "expression": expression}
