"""
Tool registry.

Every tool the system can call is registered here with metadata:
name, description, input schema, risk level, whether it needs
permission/confirmation, and the function that executes it. Adding a
new tool (file manager, web search, calendar, camera, etc.) later
means registering it here — nothing in core/ needs to change.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional


@dataclass
class Tool:
    name: str
    description: str
    input_schema: Dict[str, Any]
    risk_level: str  # LOW, MEDIUM, HIGH, CRITICAL (see safety/risk_classifier.py;
                      # conceptually SAFE=LOW, EXTERNAL_SIDE_EFFECT=MEDIUM,
                      # DANGEROUS=HIGH/CRITICAL)
    permission_required: bool
    execute: Callable[..., Dict[str, Any]]
    result_format: str = "dict"
    # Explicit per-tool override for whether confirmation is required before
    # execution. None means "derive it from risk_level via
    # safety/risk_classifier.requires_confirmation" (the normal case).
    # A model requesting this tool can never set/override this field — only
    # code registering the tool does, at startup.
    confirmation_required: Optional[bool] = None


class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def list_tools(self) -> Dict[str, Tool]:
        return dict(self._tools)

    def has(self, name: str) -> bool:
        return name in self._tools
