"""
Tool executor.

Deliberately thin: by the time something reaches here, the safety
engine has already classified risk and, if needed, obtained
confirmation. The executor's job is just to call the tool safely and
normalize failures so one broken tool can never crash JARVIS.
"""

from __future__ import annotations

from typing import Any, Dict

from .registry import ToolRegistry


class ToolExecutionError(Exception):
    pass


class ToolExecutor:
    def __init__(self, registry: ToolRegistry):
        self.registry = registry

    def execute(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        tool = self.registry.get(tool_name)
        if not tool:
            return {"ok": False, "error": f"No tool registered named '{tool_name}'."}
        try:
            return tool.execute(**kwargs)
        except Exception as e:  # noqa: BLE001 - we must never let a tool crash JARVIS
            return {"ok": False, "error": f"Tool '{tool_name}' failed: {e}"}
