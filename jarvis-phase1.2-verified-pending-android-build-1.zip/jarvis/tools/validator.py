"""
Tool request validation.

This is the gate between "something (a rule, or an AI provider)
requested a tool" and "the tool executor actually runs it." An AI
provider may propose a tool name and arguments, but it can never
bypass this validator, the risk classifier, or the confirmation
system — see ARCHITECTURE.md's tool flow diagram.

Architecture:

    AI / rules -> tool request -> ToolRequestValidator -> risk
    classifier -> permission check -> confirmation if required ->
    ToolExecutor -> result -> response
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from safety.permissions import permission_required_for
from safety.risk_classifier import RiskLevel, requires_confirmation
from .registry import Tool, ToolRegistry


@dataclass
class ToolRequest:
    tool_name: str
    arguments: Dict[str, Any] = field(default_factory=dict)
    requested_by: str = "rule_based"  # "rule_based" or "ai"


@dataclass
class ValidationResult:
    ok: bool
    tool: Optional[Tool]
    risk_level: Optional[RiskLevel]
    needs_confirmation: bool
    needs_permission: bool
    error: Optional[str] = None


def validate_tool_request(request: ToolRequest, registry: ToolRegistry,
                           confirmation_policy: str = "risky_only") -> ValidationResult:
    tool = registry.get(request.tool_name)
    if tool is None:
        return ValidationResult(
            ok=False, tool=None, risk_level=None, needs_confirmation=False,
            needs_permission=False,
            error=f"No such tool: '{request.tool_name}'.",
        )

    missing = _missing_required_arguments(tool, request.arguments)
    if missing:
        return ValidationResult(
            ok=False, tool=tool, risk_level=None, needs_confirmation=False,
            needs_permission=False,
            error=f"Missing required argument(s) for '{tool.name}': {', '.join(missing)}.",
        )

    try:
        risk = RiskLevel(tool.risk_level)
    except ValueError:
        risk = RiskLevel.HIGH  # unknown risk string -> fail closed, treat as risky

    needs_permission = permission_required_for(risk, tool.permission_required)
    if tool.confirmation_required is not None:
        needs_confirmation = tool.confirmation_required
    else:
        needs_confirmation = requires_confirmation(risk, confirmation_policy)

    # A tool requested by an AI provider is never trusted to self-report as
    # safe — risk/confirmation above are derived purely from the tool's own
    # registered metadata and the deterministic safety rules, never from
    # anything the requester (rule-based or AI) claims about itself.
    return ValidationResult(
        ok=True, tool=tool, risk_level=risk,
        needs_confirmation=needs_confirmation, needs_permission=needs_permission,
    )


def _missing_required_arguments(tool: Tool, arguments: Dict[str, Any]) -> List[str]:
    schema = tool.input_schema or {}
    return [key for key in schema.keys() if key not in arguments]
