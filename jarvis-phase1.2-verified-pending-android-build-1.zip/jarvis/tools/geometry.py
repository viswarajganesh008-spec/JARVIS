"""
Geometry tools.

Deliberately simple — their main purpose in Phase 1.1 is to give the
multi-turn / pending-task mechanism in core/context.py and
core/orchestrator.py something real to demonstrate: "find the area of
a circle" is missing a radius, JARVIS asks for it, the next message
supplies it, and only then does the tool actually run.
"""

from __future__ import annotations

import math
import re
from typing import Dict

GEOMETRY_TOOLS_SCHEMA = {
    "circle_area": {
        "name": "circle_area",
        "description": "Compute the area of a circle given its radius.",
        "input_schema": {"radius": "number"},
        "risk_level": "LOW",
        "permission_required": False,
    },
    "rectangle_area": {
        "name": "rectangle_area",
        "description": "Compute the area of a rectangle given its width and height.",
        "input_schema": {"width": "number", "height": "number"},
        "risk_level": "LOW",
        "permission_required": False,
    },
}

_NUMBER_RE = re.compile(r"-?\d+(?:\.\d+)?")


def extract_number(text: str):
    """Pull the first number out of a slot-filling reply like '5 cm' -> 5.0."""
    m = _NUMBER_RE.search(text)
    if not m:
        return None
    return float(m.group(0))


def circle_area(radius) -> Dict:
    try:
        r = float(radius)
    except (TypeError, ValueError):
        return {"ok": False, "error": f"'{radius}' is not a valid radius."}
    if r < 0:
        return {"ok": False, "error": "Radius can't be negative."}
    return {"ok": True, "result": round(math.pi * r * r, 2), "radius": r}


def rectangle_area(width, height) -> Dict:
    try:
        w, h = float(width), float(height)
    except (TypeError, ValueError):
        return {"ok": False, "error": "Width and height must both be valid numbers."}
    if w < 0 or h < 0:
        return {"ok": False, "error": "Width/height can't be negative."}
    return {"ok": True, "result": round(w * h, 2), "width": w, "height": h}
