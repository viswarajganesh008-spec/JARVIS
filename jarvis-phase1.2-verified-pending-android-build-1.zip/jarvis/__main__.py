"""
Allows `python -m jarvis` (run from the directory *containing* jarvis/)
as an alternative to `cd jarvis && python cli.py`.

The rest of the codebase uses absolute imports (`from core.x import y`,
`from config.config import ...`) that assume the jarvis/ directory
itself is on sys.path — the normal case when you `cd jarvis` first.
Running as `python -m jarvis` from the parent directory doesn't put
jarvis/ itself on sys.path (only its parent is), so this inserts it
explicitly before importing anything else in the package.
"""

import os
import sys

_PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
if _PACKAGE_DIR not in sys.path:
    sys.path.insert(0, _PACKAGE_DIR)

from cli import main  # noqa: E402  (must follow the sys.path fix above)

if __name__ == "__main__":
    main()
