"""
Tests for the Phase 2 planning/execution layer (core/planning.py) and its
integration into JarvisCore (core/orchestrator.py).

Covers, per the Phase 2 spec: single-step tasks, multi-step/dependent
steps, missing-information clarification, tool failure, verification
failure (a tool claiming success with a bad result), retry, cancellation,
timeout, malformed model output, and unavailable tools. Existing
circle/rectangle behavior is re-verified here too (in addition to
tests/test_orchestrator_v1_1.py, which must also stay green) specifically
through the `core.planning` types, not just through JarvisCore's replies.
"""

import json
import math
import os
import shutil
import tempfile
import unittest

from config.config import JarvisConfig
from core import planning
from core.intent import IntentType
from core.orchestrator import JarvisCore
from core.planning import (
    ExecutionState,
    Plan,
    PlanStep,
    Planner,
    ToolResult,
    VerificationResult,
    run_step,
    should_retry,
    verify_tool_result,
)
from providers.base import AIProvider
from tools.registry import Tool
from tools.registry import ToolRegistry


# --------------------------------------------------------------------- #
# Stub providers for the AI-proposed-plan path
# --------------------------------------------------------------------- #

class _JsonPlanProvider(AIProvider):
    """Always available; returns a caller-supplied JSON plan verbatim."""
    name = "json_plan"

    def __init__(self, plan_dict):
        self._plan_dict = plan_dict

    def is_available(self):
        return True

    def generate(self, prompt, **kwargs):
        return json.dumps(self._plan_dict)

    def chat(self, messages, **kwargs):
        return ""

    def summarize(self, text, **kwargs):
        return ""

    def classify(self, text, labels, **kwargs):
        return labels[0] if labels else ""


class _ProseProvider(AIProvider):
    """Available, but never returns JSON — used for malformed-output cases
    and doubles as the 'explain' step's generator (its prose becomes the
    explanation text when used as JarvisCore.provider)."""
    name = "prose"

    def is_available(self):
        return True

    def generate(self, prompt, **kwargs):
        return "This is a plain-language explanation, not JSON."

    def chat(self, messages, **kwargs):
        return ""

    def summarize(self, text, **kwargs):
        return ""

    def classify(self, text, labels, **kwargs):
        return labels[0] if labels else ""


class _UnavailableProvider(AIProvider):
    name = "unavailable"

    def is_available(self):
        return False

    def generate(self, prompt, **kwargs):
        raise AssertionError("should never be called when unavailable")

    def chat(self, messages, **kwargs):
        return ""

    def summarize(self, text, **kwargs):
        return ""

    def classify(self, text, labels, **kwargs):
        return labels[0] if labels else ""


# --------------------------------------------------------------------- #
# Pure unit tests: core/planning.py in isolation (no JarvisCore)
# --------------------------------------------------------------------- #

class TestVerification(unittest.TestCase):
    def test_failed_tool_result_never_verifies(self):
        result = ToolResult(ok=False, error="boom")
        v = verify_tool_result(result)
        self.assertFalse(v.verified)
        self.assertIn("boom", v.reason)

    def test_non_finite_number_fails_verification_even_if_ok(self):
        # A tool that claims success but hands back garbage must not be
        # trusted just because ok=True — this is the "don't blindly claim
        # success" case called out in the Phase 2 spec.
        result = ToolResult(ok=True, value=float("nan"))
        v = verify_tool_result(result)
        self.assertFalse(v.verified)

    def test_normal_numeric_result_verifies(self):
        result = ToolResult(ok=True, value=78.54)
        v = verify_tool_result(result)
        self.assertTrue(v.verified)

    def test_non_numeric_result_verifies_by_default(self):
        result = ToolResult(ok=True, value="some text")
        self.assertTrue(verify_tool_result(result).verified)


class TestShouldRetry(unittest.TestCase):
    def test_failed_step_under_budget_should_retry(self):
        step = PlanStep(step_id="s1", description="d", tool_name="t", max_retries=1)
        step.state = ExecutionState.FAILED
        self.assertTrue(should_retry(step))

    def test_failed_step_over_budget_should_not_retry(self):
        step = PlanStep(step_id="s1", description="d", tool_name="t", max_retries=1, retries_done=1)
        step.state = ExecutionState.FAILED
        self.assertFalse(should_retry(step))

    def test_completed_step_should_not_retry(self):
        step = PlanStep(step_id="s1", description="d", tool_name="t")
        step.state = ExecutionState.COMPLETED
        self.assertFalse(should_retry(step))


class TestRunStep(unittest.TestCase):
    def test_tool_step_success(self):
        step = PlanStep(step_id="s1", description="d", tool_name="add",
                         required_slots=["a"], collected={"a": 2})
        run_step(step, execute_tool=lambda name, args: {"ok": True, "result": args["a"] + 1})
        self.assertEqual(step.state, ExecutionState.COMPLETED)
        self.assertEqual(step.result.value, 3)
        self.assertTrue(step.verification.verified)

    def test_tool_step_failure_is_not_reported_as_success(self):
        step = PlanStep(step_id="s1", description="d", tool_name="broken")
        run_step(step, execute_tool=lambda name, args: {"ok": False, "error": "it broke"})
        self.assertEqual(step.state, ExecutionState.FAILED)
        self.assertFalse(step.verification.verified)

    def test_tool_step_timeout_classified_distinctly(self):
        step = PlanStep(step_id="s1", description="d", tool_name="slow")
        run_step(step, execute_tool=lambda name, args: {"ok": False, "error": "Operation timed out"})
        self.assertEqual(step.state, ExecutionState.TIMED_OUT)

    def test_explain_step_uses_previous_value(self):
        step = PlanStep(step_id="s2", description="explain", kind="explain")
        run_step(step, explain_fn=lambda value: f"the value was {value}", previous_value=42)
        self.assertEqual(step.state, ExecutionState.COMPLETED)
        self.assertIn("42", step.result.value)

    def test_explain_step_survives_a_crashing_explainer(self):
        step = PlanStep(step_id="s2", description="explain", kind="explain")

        def _boom(value):
            raise RuntimeError("explainer bug")

        run_step(step, explain_fn=_boom, previous_value=1)
        self.assertEqual(step.state, ExecutionState.COMPLETED)  # never crashes the plan
        self.assertTrue(step.result.ok)


class TestPlannerDeterministicTemplates(unittest.TestCase):
    def setUp(self):
        self.registry = ToolRegistry()
        self.registry.register(Tool(
            name="circle_area", description="d", input_schema={"radius": "number"},
            risk_level="LOW", permission_required=False,
            execute=lambda radius: {"ok": True, "result": round(math.pi * radius * radius, 2)},
        ))
        self.planner = Planner(self.registry)

    def test_single_step_plan_with_slot_already_given(self):
        plan = self.planner.build_plan("what is the area of a circle with radius 5")
        self.assertIsNotNone(plan)
        self.assertEqual(len(plan.steps), 1)
        self.assertEqual(plan.steps[0].collected.get("radius"), 5.0)
        self.assertTrue(plan.steps[0].is_ready())

    def test_missing_slot_plan_needs_clarification(self):
        plan = self.planner.build_plan("find the area of a circle")
        self.assertIsNotNone(plan)
        self.assertFalse(plan.steps[0].is_ready())
        self.assertEqual(plan.steps[0].next_missing_slot(), "radius")

    def test_compound_request_adds_dependent_explain_step(self):
        plan = self.planner.build_plan(
            "Calculate the area of a circle with radius 5 and explain the result simply.")
        self.assertEqual(len(plan.steps), 2)
        self.assertEqual(plan.steps[0].kind, "tool")
        self.assertEqual(plan.steps[1].kind, "explain")
        self.assertIn("step_1", plan.steps[1].depends_on)

    def test_no_template_and_no_provider_yields_no_plan(self):
        plan = self.planner.build_plan("what's the weather like today")
        self.assertIsNone(plan)


class TestPlannerAIProposedPlans(unittest.TestCase):
    def setUp(self):
        self.registry = ToolRegistry()
        self.registry.register(Tool(
            name="lookup_thing", description="d", input_schema={"query": "string"},
            risk_level="LOW", permission_required=False,
            execute=lambda query: {"ok": True, "result": f"info about {query}"},
        ))
        self.planner = Planner(self.registry)

    def test_valid_ai_plan_is_accepted(self):
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "lookup_thing", "description": "look it up",
             "arguments": {"query": "gizmo"}},
        ]})
        plan = self.planner.build_plan("look up the gizmo", IntentType.QUESTION, provider=provider)
        self.assertIsNotNone(plan)
        self.assertEqual(plan.source, "ai")
        self.assertEqual(plan.steps[0].tool_name, "lookup_thing")
        self.assertEqual(plan.steps[0].collected.get("query"), "gizmo")

    def test_malformed_json_output_yields_no_plan(self):
        provider = _ProseProvider()
        plan = self.planner.build_plan("look up the gizmo", IntentType.QUESTION, provider=provider)
        self.assertIsNone(plan)

    def test_unavailable_tool_proposed_rejects_whole_plan(self):
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "totally_made_up_tool", "description": "x", "arguments": {}},
        ]})
        plan = self.planner.build_plan("do the thing", IntentType.QUESTION, provider=provider)
        self.assertIsNone(plan)

    def test_provider_unavailable_yields_no_plan_without_calling_generate(self):
        provider = _UnavailableProvider()
        plan = self.planner.build_plan("do the thing", IntentType.QUESTION, provider=provider)
        self.assertIsNone(plan)  # would raise in generate() if it were called

    def test_disallowed_intent_type_never_attempts_ai_plan(self):
        # CONVERSATION is deliberately excluded from the AI-plan gate so
        # ordinary chat is never at risk of being hijacked by a spurious
        # model-proposed plan.
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "lookup_thing", "description": "x", "arguments": {"query": "y"}},
        ]})
        plan = self.planner.build_plan("just chatting", IntentType.CONVERSATION, provider=provider)
        self.assertIsNone(plan)

    def test_empty_steps_list_yields_no_plan(self):
        provider = _JsonPlanProvider({"steps": []})
        plan = self.planner.build_plan("do the thing", IntentType.QUESTION, provider=provider)
        self.assertIsNone(plan)


# --------------------------------------------------------------------- #
# Integration tests through JarvisCore.process()
# --------------------------------------------------------------------- #

class _PlanIntegrationBase(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.config = JarvisConfig(
            memory_db_path=os.path.join(self.tmpdir, "memory.db"),
            knowledge_directory=os.path.join(self.tmpdir, "kb"),
            knowledge_index_path=os.path.join(self.tmpdir, "index.json"),
            log_file=os.path.join(self.tmpdir, "jarvis.log"),
        )
        self.jarvis = JarvisCore(self.config)

    def tearDown(self):
        self.jarvis.close()
        shutil.rmtree(self.tmpdir, ignore_errors=True)


class TestCompoundCalculateAndExplain(_PlanIntegrationBase):
    """The Phase 2 spec's own worked example."""

    def test_single_turn_calculate_and_explain(self):
        reply = self.jarvis.process(
            "Calculate the area of a circle with radius 5 and explain the result simply.")
        self.assertIn("78.5", reply)
        # No AI provider configured by default -> honest fallback wording,
        # never a fabricated explanation.
        self.assertIn("no AI-generated explanation", reply)
        # And the plan must not be left dangling waiting for more input.
        self.assertFalse(self.jarvis.context.has_pending_task())

    def test_explanation_uses_real_provider_when_available(self):
        self.jarvis.provider = _ProseProvider()
        reply = self.jarvis.process(
            "Calculate the area of a circle with radius 4 and explain the result simply.")
        self.assertIn("50.2", reply)  # pi * 4^2 ~= 50.27
        self.assertIn("plain-language explanation", reply)


class TestPlanDrivenToolFailureAndRetry(_PlanIntegrationBase):
    def _register_flaky_tool(self, behaviors):
        """behaviors: list of dict results returned on successive calls."""
        calls = {"n": 0}

        def _execute(**kwargs):
            i = min(calls["n"], len(behaviors) - 1)
            calls["n"] += 1
            return behaviors[i]

        self.jarvis.tools.register(Tool(
            name="flaky_tool", description="A tool that may fail.",
            input_schema={}, risk_level="LOW", permission_required=False,
            execute=_execute,
        ))
        return calls

    def test_tool_failure_does_not_claim_success(self):
        self._register_flaky_tool([{"ok": False, "error": "permanently broken"}])
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "flaky_tool", "description": "run diagnostic", "arguments": {}},
        ]})
        self.jarvis.provider = provider
        reply = self.jarvis.process("What is the status of the flaky diagnostic tool")
        self.assertNotIn("Done", reply)
        self.assertTrue("couldn't" in reply.lower() or "error" in reply.lower()
                         or "broken" in reply.lower())

    def test_verification_failure_on_bad_result_does_not_claim_success(self):
        # ok=True but a non-finite number -> verification must still reject it.
        self._register_flaky_tool([{"ok": True, "result": float("nan")}])
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "flaky_tool", "description": "run diagnostic", "arguments": {}},
        ]})
        self.jarvis.provider = provider
        reply = self.jarvis.process("What is the status of the flaky diagnostic tool")
        self.assertNotIn("Done", reply)
        self.assertIn("couldn't", reply.lower())

    def test_transient_failure_recovers_via_bounded_retry(self):
        calls = self._register_flaky_tool([
            {"ok": False, "error": "temporary timeout"},
            {"ok": True, "result": 99},
        ])
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "flaky_tool", "description": "run diagnostic", "arguments": {}},
        ]})
        self.jarvis.provider = provider
        reply = self.jarvis.process("What is the status of the flaky diagnostic tool")
        self.assertEqual(calls["n"], 2)  # first attempt + exactly one retry
        self.assertIn("99", reply)

    def test_timeout_without_recovery_is_reported_honestly(self):
        self._register_flaky_tool([
            {"ok": False, "error": "Operation timed out"},
            {"ok": False, "error": "Operation timed out"},
        ])
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "flaky_tool", "description": "run diagnostic", "arguments": {}},
        ]})
        self.jarvis.provider = provider
        reply = self.jarvis.process("What is the status of the flaky diagnostic tool")
        self.assertNotIn("Done", reply)


class TestPlanCancellationAndClarification(_PlanIntegrationBase):
    def test_multi_step_plan_can_be_cancelled_mid_flow(self):
        reply1 = self.jarvis.process("find the area of a rectangle")
        self.assertIn("width", reply1.lower())
        reply2 = self.jarvis.process("cancel")
        self.assertIn("cancel", reply2.lower())
        self.assertFalse(self.jarvis.context.has_pending_task())

    def test_dependent_explain_step_only_runs_after_calculation_completes(self):
        reply1 = self.jarvis.process("find the area of a circle and explain the result simply")
        self.assertIn("radius", reply1.lower())
        reply2 = self.jarvis.process("5")
        self.assertIn("78.5", reply2)


class TestUnsafeToolStillGatedThroughPlanner(_PlanIntegrationBase):
    """The model may propose a plan step; it still can never skip
    validation/risk/confirmation — same guarantee as
    tests/test_orchestrator_v1_1.py::TestModelCannotExecuteToolsDirectly,
    exercised here via the planner path specifically."""

    def test_high_risk_tool_proposed_by_ai_plan_is_refused_not_executed(self):
        self.jarvis.tools.register(Tool(
            name="wipe_disk", description="Simulated destructive tool.",
            input_schema={}, risk_level="CRITICAL", permission_required=True,
            execute=lambda: {"ok": True, "result": "disk wiped"},
        ))
        provider = _JsonPlanProvider({"steps": [
            {"tool_name": "wipe_disk", "description": "wipe the disk", "arguments": {}},
        ]})
        self.jarvis.provider = provider
        reply = self.jarvis.process("What is the status of the disk wipe utility")
        self.assertNotIn("disk wiped", reply.lower())
        self.assertTrue("confirmation" in reply.lower() or "couldn't" in reply.lower())


if __name__ == "__main__":
    unittest.main()
