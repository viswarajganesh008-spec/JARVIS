"""
Planning / Task-Execution layer (Phase 2).

Generalizes what used to be two hardcoded multi-turn flows in
core/orchestrator.py (circle area, rectangle area) into a reusable
pipeline:

    NATURAL REQUEST -> INTENT -> TASK -> PLAN -> PLAN STEPS ->
    TOOL SELECTION -> SAFETY CHECK -> EXECUTION -> VERIFICATION ->
    RETRY/CORRECTION -> RESPONSE

This module owns the *data structures* (`Task`, `Plan`, `PlanStep`,
`ToolCall`, `ToolResult`, `VerificationResult`, `ExecutionState`) and
the *planning*/*verification* logic. It deliberately does NOT own
execution safety: `run_step()` below never calls a tool directly —
it only calls the `execute_tool` callback its caller supplies.
core/orchestrator.py wires that callback to `JarvisCore._execute_tool_safely`,
the one method allowed to touch tools/executor.py. That keeps the
architecture's central invariant true for planner-driven execution
too: **the AI model may propose a plan; it can never make a step
execute without going through the existing
validator -> risk classifier -> confirmation pipeline** (see
ARCHITECTURE.md's "Model output safety" section, which this module
does not change or bypass).

Two ways a Plan gets built, tried in this order:

  1. **Deterministic templates** (`_TASK_TEMPLATES`) — no AI provider
     needed, always available, fully test-covered. This is what
     powers the (now generalized) circle/rectangle flows. Adding a
     new deterministic multi-step task is a new `TaskTemplate` entry,
     not new orchestrator branching — this is what makes the planner
     general rather than "hardcoded around calculator/geometry
     examples."
  2. **AI-proposed plan** — tried only if no template matched. A
     configured, available AI provider may propose an ordered list of
     steps as JSON. Every proposed tool name is checked against the
     real tool registry and every argument against that tool's own
     input schema before a `PlanStep` is ever built; an unknown tool,
     invalid JSON, a non-dict argument bag, or any provider exception
     simply means no AI-sourced plan is built — the caller falls back
     to whatever handling it already had (see
     `core/orchestrator.py::_maybe_start_plan`). This is what makes
     the architecture model-independent: swapping providers changes
     what plans get *proposed*, never what's allowed to *execute*.

Known, documented limitations (same honest-about-heuristics spirit as
core/context.py): slot values are extracted from raw text with a
plain "first N numbers in reading order" heuristic
(`_extract_numbers`), not real NLU/entity linking, and the "should we
add an explanation step" check is a small regex
(`_EXPLAIN_RE`), not intent understanding. Both are real, working
approximations — good enough to generalize the two existing flows and
the brief's worked example — not a claim of general natural-language
task decomposition.
"""

from __future__ import annotations

import math
import re
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from core.intent import IntentType
from providers.base import AIProvider, ProviderResponseError, ProviderUnavailableError
from tools.registry import ToolRegistry

# --------------------------------------------------------------------- #
# Core structured types
# --------------------------------------------------------------------- #


class ExecutionState(str, Enum):
    """Where a Plan or PlanStep currently stands.

    PENDING             -> created, not yet started
    AWAITING_INPUT      -> a tool step is missing one or more required slots
    RUNNING             -> a step's tool call (or explanation) is in flight
    RETRYING            -> a failed/timed-out step is being retried once
    COMPLETED           -> finished successfully and verified
    FAILED              -> tool reported failure, or verification rejected the result
    TIMED_OUT           -> tool reported a timeout-shaped failure
    CANCELLED           -> the user cancelled the task/plan
    """
    PENDING = "PENDING"
    AWAITING_INPUT = "AWAITING_INPUT"
    RUNNING = "RUNNING"
    RETRYING = "RETRYING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    TIMED_OUT = "TIMED_OUT"
    CANCELLED = "CANCELLED"


@dataclass
class ToolCall:
    """A proposed (not yet validated/executed) call to a named tool.

    Mirrors tools/validator.py's `ToolRequest` shape deliberately —
    `requested_by` is recorded for audit only and, exactly as in
    `ToolRequest`, never influences whether the call is allowed to run.
    """
    tool_name: str
    arguments: Dict[str, Any] = field(default_factory=dict)
    requested_by: str = "planner"


@dataclass
class ToolResult:
    """The outcome of actually running a ToolCall (or of an explain step)."""
    ok: bool
    value: Any = None
    error: Optional[str] = None

    @classmethod
    def from_executor_dict(cls, raw: Dict[str, Any]) -> "ToolResult":
        """Build a ToolResult from whatever tools/executor.py's
        `ToolExecutor.execute()` (via `JarvisCore._execute_tool_safely`)
        returned — always a `{"ok": bool, ...}` dict, never a raised
        exception (see ARCHITECTURE.md's failure-handling table)."""
        if raw.get("ok"):
            return cls(ok=True, value=raw.get("result"))
        return cls(ok=False, error=raw.get("error", "unknown error"))


@dataclass
class VerificationResult:
    """Whether a ToolResult is actually good enough to report as success.

    This is what stops JARVIS from "blindly claiming success" — a tool
    can return `ok: True` and still fail verification (e.g. a
    non-finite number), and `ok: False` always fails verification.
    """
    verified: bool
    reason: str = ""
    confidence: float = 1.0


@dataclass
class PlanStep:
    """One step of a Plan.

    kind="tool"    -> calls a registered tool once its required_slots
                       are all present in `collected`.
    kind="explain" -> produces a plain-language explanation of a prior
                       step's result; never touches the tool registry.
    """
    step_id: str
    description: str
    tool_name: str = ""
    kind: str = "tool"  # "tool" | "explain"
    required_slots: List[str] = field(default_factory=list)
    collected: Dict[str, Any] = field(default_factory=dict)
    depends_on: List[str] = field(default_factory=list)
    state: ExecutionState = ExecutionState.PENDING
    result: Optional[ToolResult] = None
    verification: Optional[VerificationResult] = None
    retries_done: int = 0
    max_retries: int = 1

    def next_missing_slot(self) -> Optional[str]:
        for slot in self.required_slots:
            if slot not in self.collected:
                return slot
        return None

    def is_ready(self) -> bool:
        return self.next_missing_slot() is None


@dataclass
class Plan:
    """An ordered sequence of PlanSteps working toward one goal."""
    plan_id: str
    goal: str
    steps: List[PlanStep]
    state: ExecutionState = ExecutionState.PENDING
    current_step_index: int = 0
    source: str = "template"  # "template" | "ai"

    def current_step(self) -> Optional[PlanStep]:
        if 0 <= self.current_step_index < len(self.steps):
            return self.steps[self.current_step_index]
        return None

    def is_finished(self) -> bool:
        return self.state in (
            ExecutionState.COMPLETED, ExecutionState.FAILED,
            ExecutionState.CANCELLED, ExecutionState.TIMED_OUT,
        )


@dataclass
class Task:
    """The top-level unit of work a user request becomes.

    Thin by design: `JarvisCore` currently drives execution directly
    off `task.plan` turn by turn (see core/orchestrator.py), so `Task`
    mainly exists as the named container the brief asks for and as a
    stable place to hang task-level metadata (id, original request
    text) that isn't really a property of any one step.
    """
    task_id: str
    description: str
    raw_text: str
    plan: Plan
    state: ExecutionState = ExecutionState.PENDING


def should_retry(step: PlanStep) -> bool:
    """Bounded, honest retry policy: at most `step.max_retries` attempts,
    and only for a step that actually failed or timed out. Retrying a
    step whose failure came from a bad/unverifiable result generally
    won't produce a different outcome on the same input — this is a
    real (if simple) retry-once safety net for transient-shaped
    failures, not a self-healing system."""
    return step.state in (ExecutionState.FAILED, ExecutionState.TIMED_OUT) \
        and step.retries_done < step.max_retries


def verify_tool_result(result: ToolResult) -> VerificationResult:
    """Decide whether a ToolResult is good enough to report as success.

    This is the "does not blindly claim success" gate: `ok: False`
    always fails; a numeric `ok: True` result that isn't finite
    (NaN/inf, or something a broken/malicious tool fabricated) also
    fails, even though the tool itself claimed success.
    """
    if not result.ok:
        return VerificationResult(verified=False, reason=result.error or "tool did not report success")
    value = result.value
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if not math.isfinite(value):
            return VerificationResult(verified=False, reason="result is not a finite number")
    return VerificationResult(verified=True, reason="tool reported success")


def run_step(step: PlanStep,
             execute_tool: Optional[Callable[[str, Dict[str, Any]], Dict[str, Any]]] = None,
             explain_fn: Optional[Callable[[Any], str]] = None,
             previous_value: Any = None) -> None:
    """Execute exactly one ready step in place (mutates `step`).

    Does not decide retries or advance the plan — `core/orchestrator.py`
    owns that loop, since only it knows how to talk to the user between
    turns (asking for a missing slot, a cancellation, etc.).
    """
    step.state = ExecutionState.RUNNING
    if step.kind == "tool":
        if execute_tool is None:
            step.result = ToolResult(ok=False, error="no tool executor available")
            step.verification = VerificationResult(verified=False, reason="no executor")
            step.state = ExecutionState.FAILED
            return
        raw = execute_tool(step.tool_name, step.collected)
        result = ToolResult.from_executor_dict(raw)
        step.result = result
        step.verification = verify_tool_result(result)
        if step.verification.verified:
            step.state = ExecutionState.COMPLETED
        else:
            err = (result.error or "").lower()
            if "timeout" in err or "timed out" in err:
                step.state = ExecutionState.TIMED_OUT
            else:
                step.state = ExecutionState.FAILED
    else:  # "explain"
        text = ""
        try:
            if explain_fn is not None:
                text = explain_fn(previous_value) or ""
        except Exception as e:  # noqa: BLE001 - an explanation step must never crash the plan
            text = f"(no explanation available: {e})"
        step.result = ToolResult(ok=True, value=text)
        step.verification = VerificationResult(verified=True, reason="explanation generated")
        step.state = ExecutionState.COMPLETED


# --------------------------------------------------------------------- #
# Deterministic templates (generalizes the old circle/rectangle special-casing)
# --------------------------------------------------------------------- #

_NUMBER_RE = re.compile(r"-?\d+(?:\.\d+)?")
_EXPLAIN_RE = re.compile(r"\band (then )?explain\b|\bexplain (the|that|it|this)\b", re.IGNORECASE)

_AI_PLAN_ALLOWED_INTENTS = {
    IntentType.KNOWLEDGE_QUERY, IntentType.QUESTION,
    IntentType.TOOL_OPERATION, IntentType.UNKNOWN,
}


def _extract_numbers(text: str) -> List[float]:
    return [float(n) for n in _NUMBER_RE.findall(text)]


@dataclass
class TaskTemplate:
    name: str
    tool_name: str
    slot_names: List[str]
    matches: Callable[[str], bool]
    description: str


def _is_circle_area(text: str) -> bool:
    return "circle" in text and "area" in text


def _is_rectangle_area(text: str) -> bool:
    return "rectangle" in text and "area" in text


_TASK_TEMPLATES: List[TaskTemplate] = [
    TaskTemplate("circle_area", "circle_area", ["radius"], _is_circle_area, "area of the circle"),
    TaskTemplate("rectangle_area", "rectangle_area", ["width", "height"], _is_rectangle_area,
                 "area of the rectangle"),
]


# --------------------------------------------------------------------- #
# Planner
# --------------------------------------------------------------------- #

class Planner:
    """Builds a Plan for a natural-language request. See module docstring
    for the two-tier (template, then AI) strategy."""

    def __init__(self, registry: ToolRegistry):
        self.registry = registry

    def build_plan(self, raw_text: str, intent_type: Optional[IntentType] = None,
                    provider: Optional[AIProvider] = None) -> Optional[Plan]:
        text = raw_text.lower()
        template = self._match_template(text)
        if template is not None:
            return self._build_from_template(template, raw_text, text)
        if intent_type in _AI_PLAN_ALLOWED_INTENTS:
            return self._build_ai_plan(raw_text, provider)
        return None

    # -- deterministic path -------------------------------------------------
    def _match_template(self, text: str) -> Optional[TaskTemplate]:
        for template in _TASK_TEMPLATES:
            if template.matches(text):
                return template
        return None

    def _build_from_template(self, template: TaskTemplate, raw_text: str, text: str) -> Plan:
        numbers = _extract_numbers(raw_text)
        collected = {}
        for slot, value in zip(template.slot_names, numbers):
            collected[slot] = value
        step = PlanStep(
            step_id="step_1",
            description=template.description,
            tool_name=template.tool_name,
            kind="tool",
            required_slots=list(template.slot_names),
            collected=collected,
        )
        steps = [step]
        if _EXPLAIN_RE.search(text):
            steps.append(PlanStep(
                step_id="step_2",
                description=f"explain the {template.description} result",
                kind="explain",
                depends_on=["step_1"],
            ))
        return Plan(plan_id=str(uuid.uuid4()), goal=template.description, steps=steps,
                    source="template")

    # -- AI-proposed path -----------------------------------------------------
    def _build_ai_plan(self, raw_text: str, provider: Optional[AIProvider]) -> Optional[Plan]:
        if provider is None:
            return None
        try:
            if not provider.is_available():
                return None
        except Exception:  # noqa: BLE001 - a misbehaving provider must not crash planning
            return None

        available_tools = ", ".join(sorted(self.registry.list_tools().keys())) or "(none registered)"
        prompt = (
            "You are a planning module for an assistant. Given the user's request, "
            "propose an ORDERED JSON plan of the steps needed to satisfy it. Use only "
            f"these exact tool names where a tool call is needed: {available_tools}. "
            "Use an empty tool_name for a pure explanation/summary step. "
            'Return ONLY JSON, no prose, in the shape: {"steps": '
            '[{"tool_name": "<name or empty>", "description": "<short description>", '
            '"arguments": {"<arg>": <value>, ...}}]}. '
            f"Request: {raw_text}"
        )
        try:
            parsed = provider.generate_json(prompt)
        except (ProviderUnavailableError, ProviderResponseError):
            return None
        except Exception:  # noqa: BLE001 - a provider bug must not crash planning
            return None

        if not isinstance(parsed, dict):
            return None
        raw_steps = parsed.get("steps")
        if not isinstance(raw_steps, list) or not raw_steps:
            return None

        steps: List[PlanStep] = []
        for i, raw_step in enumerate(raw_steps, start=1):
            if not isinstance(raw_step, dict):
                return None
            tool_name = raw_step.get("tool_name") or ""
            description = str(raw_step.get("description") or tool_name or f"step {i}")
            arguments = raw_step.get("arguments")
            if arguments is None:
                arguments = {}
            if not isinstance(arguments, dict):
                return None
            depends_on = [f"step_{i - 1}"] if i > 1 else []

            if tool_name:
                # Fail closed: a tool the model invented (or misspelled) does
                # not get a PlanStep — the whole AI-sourced plan is rejected
                # rather than silently dropping a step (see "unavailable
                # tools" in the module docstring / test suite).
                if not self.registry.has(tool_name):
                    return None
                tool = self.registry.get(tool_name)
                required = list((tool.input_schema or {}).keys())
                collected = {k: v for k, v in arguments.items() if k in required}
                steps.append(PlanStep(
                    step_id=f"step_{i}", description=description, tool_name=tool_name,
                    kind="tool", required_slots=required, collected=collected,
                    depends_on=depends_on,
                ))
            else:
                steps.append(PlanStep(
                    step_id=f"step_{i}", description=description, kind="explain",
                    depends_on=depends_on,
                ))
        return Plan(plan_id=str(uuid.uuid4()), goal=raw_text, steps=steps, source="ai")
