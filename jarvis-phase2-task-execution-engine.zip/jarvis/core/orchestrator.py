"""
JarvisCore — the orchestrator.

    User -> Interface -> JarvisCore -> Context + Memory -> Intent
    Understanding -> Reasoning -> Knowledge / Tools -> Safety ->
    Local AI Model (optional) -> Response -> Memory

This module is the only place that wires the other layers together.
Every layer (context, intent/nlu, reasoning, memory, knowledge, tools,
safety, providers) can be tested and reasoned about independently;
JarvisCore just calls them in order. See ARCHITECTURE.md for the full
turn-by-turn request lifecycle.

The AI model (providers/) is one component JARVIS *may* consult — for
ambiguous intent classification and for open-ended generation grounded
in retrieved knowledge — never the thing JARVIS *is*. Every safety
decision is made by deterministic code, never by the model.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from config.config import JarvisConfig
from core import planning
from core import response as R
from core.context import ContextManager
from core.intent import IntentType
from core.memory_policy import decide_memory_action
from core.nlu import StructuredIntent, classify_with_fallback
from core.planning import Plan, PlanStep
from core.reasoning import decide
from knowledge.search import KnowledgeIndex
from knowledge.verification import verify_and_format
from memory.long_term import LongTermMemory, MemoryRejectedError
from providers.base import AIProvider, ProviderUnavailableError
from providers.factory import UnknownProviderError, get_provider_from_config
from safety.confirmation import ConfirmationManager, ConfirmationResult
from tools.calculator import CALCULATOR_TOOL_SCHEMA
from tools.calculator import run as run_calculator
from tools.executor import ToolExecutor
from tools.geometry import GEOMETRY_TOOLS_SCHEMA, circle_area, extract_number, rectangle_area
from tools.registry import Tool, ToolRegistry
from tools.validator import ToolRequest, validate_tool_request

_AMBIGUOUS_TARGETS = {"it", "that", "this", "them"}


def _configure_logging(cfg: JarvisConfig) -> logging.Logger:
    os.makedirs(os.path.dirname(cfg.log_file) or ".", exist_ok=True)
    logger = logging.getLogger("jarvis")
    logger.setLevel(getattr(logging, cfg.logging_level.upper(), logging.INFO))
    if not logger.handlers:
        handler = logging.FileHandler(cfg.log_file, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
        logger.addHandler(handler)
    return logger


def _build_provider(config: JarvisConfig, logger: logging.Logger) -> AIProvider:
    """Construct the configured provider; fall back to 'local' on any
    *configuration* error so a typo or an unwritten provider integration
    never prevents JARVIS from starting."""
    try:
        return get_provider_from_config(config)
    except (UnknownProviderError, ValueError) as e:
        logger.warning("provider_config_error provider=%s error=%s falling_back=local",
                        config.ai_provider, e)
        from providers.local import LocalAIProvider
        return LocalAIProvider()


class JarvisCore:
    def __init__(self, config: Optional[JarvisConfig] = None):
        self.config = config or JarvisConfig.load()
        self.logger = _configure_logging(self.config)

        self.context = ContextManager(max_messages=self.config.max_context_messages)
        self.memory = LongTermMemory(self.config.memory_db_path) if self.config.memory_enabled else None
        self.knowledge = KnowledgeIndex(self.config.knowledge_directory, self.config.knowledge_index_path)
        self.confirmation = ConfirmationManager()
        self.provider = _build_provider(self.config, self.logger)

        self.tools = ToolRegistry()
        self._register_default_tools()
        self.executor = ToolExecutor(self.tools)
        # Phase 2: general planner (core/planning.py). Holds only the tool
        # registry, never a provider reference directly — `self.provider`
        # can be swapped after construction (tests do this routinely), so
        # it's passed into build_plan() at call time instead of captured
        # here, to avoid the planner silently using a stale provider.
        self.planner = planning.Planner(self.tools)

        self._prior_target: Optional[str] = None

    def _register_default_tools(self) -> None:
        self.tools.register(Tool(
            name="calculator",
            description=CALCULATOR_TOOL_SCHEMA["description"],
            input_schema=CALCULATOR_TOOL_SCHEMA["input_schema"],
            risk_level=CALCULATOR_TOOL_SCHEMA["risk_level"],
            permission_required=CALCULATOR_TOOL_SCHEMA["permission_required"],
            execute=lambda expression: run_calculator(expression),
        ))
        self.tools.register(Tool(
            name="circle_area",
            description=GEOMETRY_TOOLS_SCHEMA["circle_area"]["description"],
            input_schema=GEOMETRY_TOOLS_SCHEMA["circle_area"]["input_schema"],
            risk_level=GEOMETRY_TOOLS_SCHEMA["circle_area"]["risk_level"],
            permission_required=GEOMETRY_TOOLS_SCHEMA["circle_area"]["permission_required"],
            execute=lambda radius: circle_area(radius),
        ))
        self.tools.register(Tool(
            name="rectangle_area",
            description=GEOMETRY_TOOLS_SCHEMA["rectangle_area"]["description"],
            input_schema=GEOMETRY_TOOLS_SCHEMA["rectangle_area"]["input_schema"],
            risk_level=GEOMETRY_TOOLS_SCHEMA["rectangle_area"]["risk_level"],
            permission_required=GEOMETRY_TOOLS_SCHEMA["rectangle_area"]["permission_required"],
            execute=lambda width, height: rectangle_area(width, height),
        ))

    # ------------------------------------------------------------------ #
    # Main entry point
    # ------------------------------------------------------------------ #
    def process(self, user_text: str) -> str:
        self.logger.info("user_request=%r", user_text)

        # 1. A pending confirmation always takes priority — it must not be lost.
        if self.confirmation.is_waiting():
            return self._handle_pending_confirmation(user_text)

        # 2. A pending multi-turn task (e.g. "find the area of a circle" ->
        #    waiting on a radius) takes priority over fresh intent classification.
        #    General Plans (Phase 2 planner, core/planning.py) are checked
        #    first; the legacy single-tool PendingTask mechanism is kept for
        #    ContextManager API/back-compat (tests/test_context.py) but
        #    nothing in this file creates one anymore — see
        #    `_maybe_start_plan` below, which replaced the old hardcoded
        #    circle/rectangle special-casing.
        if self.context.has_pending_plan():
            reply = self._continue_pending_plan(user_text)
            if reply is not None:
                self.context.update_from_jarvis_message(reply)
                return reply
        elif self.context.has_pending_task():
            reply = self._continue_pending_task(user_text)
            if reply is not None:
                self.context.update_from_jarvis_message(reply)
                return reply

        # 3. Capture the subject/topic as it stood *before* this message, so
        #    follow-up pronoun resolution ("he", "it") refers to what the
        #    previous turn was about — not something re-derived from the
        #    pronoun-bearing message itself.
        self._prior_target = self.context.state.current_subject or self.context.state.current_topic
        self.context.update_from_user_message(user_text)

        # 4. Structured intent understanding: rule-based first, AI fallback
        #    only if confidence is low and a provider is actually available.
        #    Risk/confirmation are always finalized deterministically inside
        #    classify_with_fallback — never trusted from the AI's own output.
        structured = classify_with_fallback(
            user_text,
            provider=self.provider,
            confidence_threshold=self.config.nlu_confidence_threshold,
            confirmation_policy=self.config.confirmation_policy,
            context_snapshot=self.context.snapshot(),
        )
        self.logger.info("intent=%s confidence=%.2f source=%s risk=%s",
                          structured.type.value, structured.confidence,
                          structured.source, structured.risk_level.value)

        # 5. Ambiguous tool target ("open it" with no resolvable referent) ->
        #    ask for clarification instead of guessing.
        clarification = self._check_ambiguous_target(structured)
        if clarification is not None:
            self.context.update_from_jarvis_message(clarification)
            return clarification

        # 6. Task/plan detection (Phase 2 planner). Deterministic templates
        #    (e.g. circle/rectangle area) are tried first and need no AI
        #    provider; for other request shapes, an available provider may
        #    PROPOSE an ordered tool plan, which is still validated
        #    tool-by-tool through the existing safety pipeline
        #    (_execute_tool_safely) before anything executes — see
        #    core/planning.py's module docstring.
        plan_prompt = self._maybe_start_plan(structured, user_text)
        if plan_prompt is not None:
            self.context.update_from_jarvis_message(plan_prompt)
            return plan_prompt

        decision = decide(structured, self.config.confirmation_policy)

        if decision.needs_confirmation:
            prompt = self.confirmation.request(
                description=decision.description,
                risk_level=decision.risk_level,
                tool_name=None,
                tool_kwargs={"intent_type": structured.type.value, "payload": structured.payload},
            )
            self.logger.info("safety_decision=WAITING_FOR_CONFIRMATION action=%r",
                              decision.description)
            self.context.update_from_jarvis_message(prompt)
            return prompt

        handler = getattr(self, decision.handler, self.handle_unknown)
        try:
            reply = handler(structured.payload, structured)
        except Exception as e:  # noqa: BLE001 - one failing handler must not crash JARVIS
            self.logger.exception("handler_error handler=%s", decision.handler)
            reply = f"I ran into a problem handling that: {e}"

        # 7. Memory intelligence: even outside an explicit "remember" command,
        #    a clear personal-fact statement gets quietly stored.
        self._maybe_auto_remember(user_text, structured)

        self.context.update_from_jarvis_message(reply)
        self.context.record_turn_outcome(structured.type.value, reply)
        return reply

    # ------------------------------------------------------------------ #
    # Confirmation state handling
    # ------------------------------------------------------------------ #
    def _handle_pending_confirmation(self, user_text: str) -> str:
        result = self.confirmation.respond(user_text)
        pending = self.confirmation.pending
        if result == ConfirmationResult.AMBIGUOUS:
            return R.confirmation_ambiguous()

        if result == ConfirmationResult.CANCELLED:
            self.confirmation.resolve()
            reply = R.action_cancelled()
            self.context.update_from_jarvis_message(reply)
            return reply

        # CONFIRMED
        self.logger.info("safety_decision=EXECUTE action=%r", pending.description if pending else None)
        self.confirmation.resolve()
        # No tool that can actually delete files, change system settings, or
        # move money is wired up — dangerous actions are acknowledged as
        # simulated after confirmation, by design (see README limitations).
        reply = R.action_executed(f"(simulated) {pending.description}" if pending else "action completed")
        self.context.update_from_jarvis_message(reply)
        return reply

    # ------------------------------------------------------------------ #
    # Unified, validated tool execution path
    # ------------------------------------------------------------------ #
    def _execute_tool_safely(self, tool_name: str, requested_by: str = "rule_based",
                              **kwargs) -> dict:
        """The ONLY path any code in JarvisCore uses to actually run a tool.

        Every call — whether triggered by a deterministic rule, a completed
        multi-turn task, or (in principle) an AI provider proposing a tool —
        goes through tools/validator.py first. The validator re-derives risk
        and confirmation-requirement from the tool's own registered
        metadata; `requested_by` is recorded for audit purposes only and
        never influences the outcome (see tools/validator.py's docstring
        and tests/test_tools_validation.py::test_dangerous_tool_cannot_be_marked_safe_by_requester
        for the property this guarantees). A tool request needing
        confirmation is never executed here — the caller must go through
        the normal ConfirmationManager flow instead; this method only
        executes tools that validate as not requiring it.
        """
        validation = validate_tool_request(
            ToolRequest(tool_name, kwargs, requested_by=requested_by),
            self.tools, self.config.confirmation_policy,
        )
        if not validation.ok:
            self.logger.info("tool_request_rejected tool=%s requested_by=%s error=%s",
                              tool_name, requested_by, validation.error)
            return {"ok": False, "error": validation.error}
        if validation.needs_confirmation:
            # Defense in depth: nothing currently routes a confirmation
            # -requiring tool through this method (dangerous actions are
            # gated earlier, at the intent level, before any tool is
            # touched) — but if that ever changes, refusing here rather
            # than executing is the safe default.
            self.logger.warning("tool_request_blocked_pending_confirmation tool=%s", tool_name)
            return {"ok": False, "error": f"'{tool_name}' requires confirmation before it can run."}
        return self.executor.execute(tool_name, **kwargs)

    # ------------------------------------------------------------------ #
    # Phase 2: general planner-driven task handling (core/planning.py)
    #
    # This replaced the old hardcoded circle/rectangle special-casing
    # (`_maybe_start_pending_task`) with a template-driven Planner, so a
    # new deterministic multi-step task is a new TaskTemplate entry in
    # core/planning.py, not new branching here. `_continue_pending_task`
    # below (operating on ContextManager's older single-tool PendingTask)
    # is kept only for API/back-compat with direct ContextManager users —
    # nothing in this class creates a bare PendingTask anymore.
    # ------------------------------------------------------------------ #
    def _maybe_start_plan(self, structured: StructuredIntent, user_text: str) -> Optional[str]:
        plan = self.planner.build_plan(user_text, structured.type, provider=self.provider)
        if plan is None:
            return None
        self.context.start_pending_plan(plan)
        return self._advance_plan(plan)

    def _continue_pending_plan(self, user_text: str) -> Optional[str]:
        plan = self.context.get_pending_plan()
        if plan is None:
            return None
        low = user_text.strip().lower()
        if low in ("cancel", "stop", "never mind", "forget it"):
            plan.state = planning.ExecutionState.CANCELLED
            self.context.clear_pending_plan()
            return R.task_cancelled()

        step = plan.current_step()
        if step is None:
            self.context.clear_pending_plan()
            return R.tool_failed("plan", "no active step")

        if step.kind == "tool" and not step.is_ready():
            slot = step.next_missing_slot()
            value = extract_number(user_text)
            if value is None:
                return f"I need a number for the {slot}. What is the {slot}?"
            step.collected[slot] = value

        return self._advance_plan(plan)

    def _advance_plan(self, plan: Plan) -> str:
        """Run the plan forward until it needs user input or finishes.

        A single call may run several steps back-to-back (e.g. a
        calculate-then-explain request where every slot was already given
        in the original message) — see core/planning.py's module docstring
        for the worked example this generalizes.
        """
        while True:
            step = plan.current_step()
            if step is None:
                plan.state = planning.ExecutionState.COMPLETED
                self.context.clear_pending_plan()
                return self._final_plan_response(plan)

            if step.kind == "tool":
                if not step.is_ready():
                    slot = step.next_missing_slot()
                    return R.task_ask_for_slot(plan.goal, slot)

                planning.run_step(step, execute_tool=self._plan_execute_tool)

                if planning.should_retry(step):
                    step.retries_done += 1
                    planning.run_step(step, execute_tool=self._plan_execute_tool)

                if step.state in (planning.ExecutionState.FAILED, planning.ExecutionState.TIMED_OUT):
                    plan.state = step.state
                    self.context.clear_pending_plan()
                    reason = step.result.error if step.result else "unknown error"
                    return R.tool_failed(step.tool_name or plan.goal, reason)

                plan.current_step_index += 1
                continue

            # kind == "explain"
            previous_value = self._plan_previous_value(plan, step)
            planning.run_step(
                step,
                explain_fn=lambda value: self._explain_result(plan, value),
                previous_value=previous_value,
            )
            plan.current_step_index += 1

    def _plan_execute_tool(self, tool_name: str, arguments: dict) -> dict:
        """The ONLY function the planner is given to actually run a tool —
        wired straight to `_execute_tool_safely`, so plan-driven execution
        gets exactly the same validator/risk/confirmation guarantees as
        every other tool call in this class (see that method's docstring).
        """
        return self._execute_tool_safely(tool_name, requested_by="planner", **arguments)

    def _plan_previous_value(self, plan: Plan, step: PlanStep):
        idx = plan.steps.index(step)
        if idx == 0:
            return None
        prev = plan.steps[idx - 1]
        return prev.result.value if prev.result else None

    def _explain_result(self, plan: Plan, value) -> str:
        if self._provider_ready():
            try:
                prompt = (
                    f"In one or two simple, plain-language sentences, explain what a "
                    f"result of {value} means for '{plan.goal}', for someone with no "
                    f"technical background."
                )
                explanation = self.provider.generate(prompt)
                if explanation and explanation.strip():
                    return explanation.strip()
            except ProviderUnavailableError as e:
                self.logger.info("provider_unavailable_during_plan_explanation error=%s", e)
        return R.plan_explanation_fallback(plan.goal, value)

    def _final_plan_response(self, plan: Plan) -> str:
        tool_steps = [s for s in plan.steps if s.kind == "tool"]
        explain_steps = [s for s in plan.steps if s.kind == "explain"]
        if not tool_steps:
            return R.tool_failed(plan.goal, "the plan had no executable step")
        last_tool = tool_steps[-1]
        value = last_tool.result.value if last_tool.result else None
        base = R.task_result(plan.goal, value)
        if explain_steps and explain_steps[-1].result and explain_steps[-1].result.ok:
            return f"{base} {explain_steps[-1].result.value}"
        return base

    # ------------------------------------------------------------------ #
    # Legacy single-tool pending task handling (ContextManager back-compat)
    # ------------------------------------------------------------------ #
    def _continue_pending_task(self, user_text: str) -> Optional[str]:
        low = user_text.strip().lower()
        if low in ("cancel", "stop", "never mind", "forget it"):
            self.context.clear_pending_task()
            return R.task_cancelled()

        task = self.context.state.pending_task
        slot = task.next_missing_slot()
        value = extract_number(user_text)
        if value is None:
            return f"I need a number for the {slot}. What is the {slot}?"
        self.context.fill_pending_slot(slot, value)

        next_slot = task.next_missing_slot()
        if next_slot:
            return R.task_ask_for_slot(task.task_name.replace("_", " "), next_slot)

        # All slots collected — validate + execute through the normal tool path.
        result = self._execute_tool_safely(task.tool_name, requested_by="rule_based",
                                            **task.collected)
        description = task.task_name.replace("_", " ")
        self.context.clear_pending_task()
        if result.get("ok"):
            return R.task_result(description, result["result"])
        return R.tool_failed(task.tool_name, result.get("error", "unknown error"))

    # ------------------------------------------------------------------ #
    # Ambiguous-reference guard
    # ------------------------------------------------------------------ #
    def _check_ambiguous_target(self, structured: StructuredIntent) -> Optional[str]:
        if structured.type != IntentType.TOOL_OPERATION:
            return None
        target = structured.payload.strip().lower()
        # A bare pronoun target for an "open X" style command is ambiguous
        # regardless of unrelated conversational context — resolving "it" to
        # whatever topic was last discussed and trying to "open" that isn't
        # a safe guess (see requirement: never silently pick something).
        if target in _AMBIGUOUS_TARGETS:
            return R.ambiguous_open_target()
        return None

    # ------------------------------------------------------------------ #
    # Memory intelligence
    # ------------------------------------------------------------------ #
    def _maybe_auto_remember(self, user_text: str, structured: StructuredIntent) -> None:
        if not self.memory:
            return
        if structured.type in (IntentType.MEMORY_REMEMBER, IntentType.MEMORY_FORGET,
                                IntentType.MEMORY_RETRIEVE, IntentType.MEMORY_LIST):
            return  # already handled explicitly
        decision = decide_memory_action(user_text)
        if decision.should_remember:
            try:
                self.memory.remember(decision.content, category=decision.category,
                                      importance=decision.importance,
                                      confidence=decision.confidence, source="auto")
                self.logger.info("memory_auto_stored category=%s confidence=%.2f",
                                  decision.category, decision.confidence)
            except MemoryRejectedError as e:
                self.logger.info("memory_auto_store_rejected reason=%s", e)

    # ------------------------------------------------------------------ #
    # Intent handlers
    # ------------------------------------------------------------------ #
    def handle_calculation(self, expression: str, intent) -> str:
        result = self._execute_tool_safely("calculator", requested_by="rule_based",
                                            expression=expression)
        self.context.short_term.add_tool_result("calculator", result)
        if result.get("ok"):
            return R.calculation_result(expression, result["result"])
        return R.calculation_error(expression, result.get("error", "unknown error"))

    def handle_memory_remember(self, content: str, intent) -> str:
        if not self.memory:
            return "Memory is currently disabled in configuration."
        try:
            self.memory.remember(content, source="user")
        except MemoryRejectedError as e:
            return R.memory_rejected(str(e))
        return R.memory_saved(content)

    def handle_memory_retrieve(self, query: str, intent) -> str:
        if not self.memory:
            return "Memory is currently disabled in configuration."
        if not query:
            items = self.memory.list_all()
            return R.memory_list(items)
        items = self.memory.retrieve(query)
        return R.memory_retrieved(items)

    def handle_memory_list(self, _payload: str, intent) -> str:
        if not self.memory:
            return "Memory is currently disabled in configuration."
        return R.memory_list(self.memory.list_all())

    def handle_memory_forget(self, query: str, intent) -> str:
        if not self.memory:
            return "Memory is currently disabled in configuration."
        count = self.memory.forget(query)
        return R.memory_forgotten(count, query)

    def handle_knowledge_query(self, query: str, intent) -> str:
        resolved_query = self.context.resolve_references(query, target=self._prior_target)
        return self._answer_from_knowledge_or_model(resolved_query)

    def handle_tool_operation(self, tool_query: str, intent) -> str:
        # "open calculator" etc. Only the calculator/geometry tools are truly
        # wired up; anything else is honestly reported as not yet supported.
        normalized = tool_query.strip().lower()
        if "calculator" in normalized:
            return "Calculator is ready — send me an expression like 'calculate 25 * 36'."
        return R.tool_not_found(tool_query)

    def handle_dangerous_operation(self, payload: str, intent) -> str:
        # Reached only if it somehow didn't require confirmation (e.g. policy="never"
        # with a MEDIUM-risk action) — HIGH/CRITICAL are always gated upstream,
        # regardless of what any AI-fallback classification claimed.
        return R.action_executed(f"(simulated) {payload}")

    def handle_question(self, text: str, intent) -> str:
        resolved_text = self.context.resolve_references(text, target=self._prior_target)
        return self._answer_from_knowledge_or_model(resolved_text, original_question=text)

    def handle_conversation(self, text: str, intent) -> str:
        if self._provider_ready():
            try:
                prompt_ctx = self.context.build_prompt_context()
                return self.provider.generate(self._build_conversation_prompt(text, prompt_ctx))
            except ProviderUnavailableError as e:
                self.logger.info("provider_unavailable_during_conversation error=%s", e)
                return R.provider_unavailable(str(e))
        return R.generic_no_ai_provider()

    def handle_unknown(self, _payload: str, intent) -> str:
        return R.unknown_command()

    # ------------------------------------------------------------------ #
    # Shared knowledge + reasoning pipeline
    # ------------------------------------------------------------------ #
    def _answer_from_knowledge_or_model(self, query: str, original_question: str = "") -> str:
        """Question -> retrieval -> verification -> reasoning -> answer.

        Distinguishes three cases in the reply itself:
          - grounded in a local document, answered deterministically
            ("According to X: ...")
          - grounded in a local document, but reasoned over/rephrased by
            the AI provider when one is available ("Based on X: ...")
          - no local knowledge at all: the AI provider's own knowledge is
            used if available, clearly not attributed to a source; if no
            provider is available, JARVIS says so instead of guessing.
        """
        results = self.knowledge.search(query)
        verified = verify_and_format(results)

        if verified.grounded:
            if self._provider_ready():
                try:
                    prompt = (
                        f"Using ONLY the following source passage, answer the question "
                        f"simply and conversationally. Do not add facts that aren't in "
                        f"the passage.\n\nSource ({verified.source_doc}): {verified.text}\n\n"
                        f"Question: {original_question or query}\nAnswer:"
                    )
                    reasoned = self.provider.generate(prompt)
                    if reasoned.strip():
                        return R.knowledge_reasoned_answer(verified.source_doc, reasoned.strip())
                except ProviderUnavailableError:
                    pass  # fall through to the deterministic, still-grounded answer
            return R.knowledge_answer(verified.source_doc, verified.text)

        if self._provider_ready():
            try:
                return self.provider.generate(original_question or query)
            except ProviderUnavailableError as e:
                self.logger.info("provider_unavailable_during_question error=%s", e)
                return R.provider_unavailable(str(e))
        return R.knowledge_unavailable()

    def _provider_ready(self) -> bool:
        try:
            return self.provider.is_available()
        except Exception:  # noqa: BLE001 - a misbehaving provider must not crash JARVIS
            return False

    def _build_conversation_prompt(self, text: str, prompt_ctx: dict) -> str:
        history_lines = [f"{t['role']}: {t['text']}" for t in prompt_ctx.get("recent_history", [])]
        history_block = "\n".join(history_lines[-5:])
        return (
            f"You are JARVIS, a helpful, concise assistant. Recent conversation:\n"
            f"{history_block}\n\nUser: {text}\nJARVIS:"
        )

    def close(self) -> None:
        if self.memory:
            self.memory.close()
